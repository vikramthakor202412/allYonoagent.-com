<?php
ini_set('max_execution_time', '60');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Disclaimer - IndYonoGames</title>
<link rel="canonical" href="disclaimer.php" />
<meta name="description" content="Disclaimer - Yono Apps (Read Carefully)" />
<meta content='Disclaimer - Yono Apps' name='keywords'/>
<meta content='Disclaimer - Yono Apps' name='title'/>
<meta property="og:image" content="logo.jpg"/>
<meta property="og:url" content="disclaimer.php"/>
<meta property="og:title" content="Disclaimer - IndYonoGames"/>
<meta property="og:description" content="Disclaimer - Yono Apps"/>
<meta name="og:site_name" content="IndYonoGames"/>
<meta property="og:type" content="website" />
<meta property="og:locale" content="en_IN" />
<link rel="icon" type="image/png" sizes="32x32" href="logo.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="logo.jpg">
<meta name="msapplication-TileColor" content="#0a0a0f">
<meta name="theme-color" content="#c9922a">
<meta name="robots" content="index, follow"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<script>
function toggleMenu() {
  var x = document.getElementById("menuContainer");
  x.style.display = x.style.display === "block" ? "none" : "block";
}
function shareContent() {
  var metaElement = document.querySelector("meta[name=description]");
  var metaDescription = metaElement ? metaElement.getAttribute("content") : '';
  var shareText = document.title + "\n\n" + "indyonogames.com" + (metaDescription ? " - " + metaDescription : '') + "\n" + "» ";
  if (navigator.share) {
    navigator.share({ title: document.title, text: shareText, url: window.location.href }).catch(console.error);
  } else {
    alert('Web Share API is not supported in your browser.');
  }
}
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.question8262').forEach(function(question) {
    question.addEventListener('click', function() {
      question.nextElementSibling.classList.toggle('show');
    });
  });
});
</script>
<style>
:root {
    --bg-primary: #0a0a0f;
    --bg-secondary: #13131e;
    --bg-card: #1a1a2e;
    --text-primary: #f0ead6;
    --text-secondary: #9a8f7a;
    --accent-primary: #c9922a;
    --accent-secondary: #e8b84b;
    --accent-hover: #f5d17a;
    --accent-glow: rgba(201,146,42,0.35);
    --border-color: rgba(201,146,42,0.2);
    --shadow-color: rgba(0,0,0,0.7);
    --gradient-bg: linear-gradient(135deg, #b07d1e 0%, #e8b84b 50%, #c9922a 100%);
    --gradient-card: linear-gradient(145deg, #1a1a2e 0%, #13131e 100%);
    --green: #22c55e;
    --red: #f87171;
}
body {
    background: var(--bg-primary);
    color: var(--text-primary);
    font-family: 'Nunito', Arial, sans-serif;
    margin: 0; padding: 0;
    animation: fadeIn 0.8s ease-in-out;
}
body::before {
    content: '';
    position: fixed; inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none; z-index: 0; opacity: 0.4;
}
@keyframes fadeIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }

/* ── HEADER ── */
.header {
    background: linear-gradient(135deg, #0d0d1a 0%, #1a1408 50%, #0d0d1a 100%);
    border-bottom: 2px solid var(--accent-primary);
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.8);
    position: relative; z-index: 100;
}
.logo-top { width: 35px; height: auto; border-radius: 8px; }
.telegram-top { width: 54px; height: auto; }
.header-text {
    flex-grow: 1; margin: 0 8px; text-align: left;
    font-weight: 700; font-size: 22px;
    font-family: 'Cinzel', serif;
    color: var(--accent-secondary) !important;
    text-shadow: 0 0 20px rgba(232,184,75,0.4);
    letter-spacing: 0.5px;
    text-decoration: none;
}
.icon {
    display: block; text-align: right;
    padding: 2px 6px; color: #fff;
    font-size: 18px; font-weight: 700; cursor: pointer;
}

/* ── MENU ── */
.menu-container {
    display: none;
    background: linear-gradient(135deg, #0d0d1a 0%, #1a1408 100%);
    padding: 16px;
    border-bottom: 1px solid var(--border-color);
    position: relative; z-index: 99;
}
.menu-row { display: flex; justify-content: space-around; flex-wrap: wrap; gap: 6px; }
.menu-item {
    background: linear-gradient(135deg, rgba(201,146,42,0.2) 0%, rgba(232,184,75,0.1) 100%);
    border: 1px solid var(--border-color);
    color: var(--accent-secondary);
    padding: 8px 14px; margin: 4px;
    display: inline-block; width: 28%;
    border-radius: 10px;
    font-family: 'Nunito', sans-serif;
    font-weight: 700; font-size: 11px;
    text-decoration: none; text-align: center;
    transition: all 0.25s ease;
}
.menu-item:hover { background: rgba(201,146,42,0.3); color: var(--accent-hover); transform: translateY(-2px); }

/* ── NAVBAR ── */
.navbar {
    display: flex; justify-content: center; flex-wrap: nowrap;
    background: linear-gradient(90deg, #0d0d1a 0%, #1a1408 50%, #0d0d1a 100%);
    border-top: 1px solid rgba(201,146,42,0.2);
    border-bottom: 1px solid rgba(201,146,42,0.2);
    overflow: hidden;
    position: relative; z-index: 98;
}
.navbar a {
    white-space: nowrap; float: left;
    color: var(--text-secondary);
    padding: 6px 8px; font-size: 11px !important;
    font-weight: 700; font-family: 'Nunito', sans-serif;
    border-right: 1px solid rgba(201,146,42,0.15);
    text-decoration: none; transition: all 0.2s ease;
}
.navbar a:last-child { border-right: none; }
.navbar a.active, .navbar a:hover {
    background: linear-gradient(135deg, rgba(201,146,42,0.25) 0%, rgba(232,184,75,0.12) 100%);
    color: var(--accent-secondary) !important;
}

/* ── PAGE WRAPPER ── */
.page-content {
    max-width: 860px;
    margin: 0 auto;
    padding: 16px 14px 30px;
    position: relative; z-index: 1;
}

/* ── HEADINGS ── */
h2 {
    color: #1a0e00 !important;
    background: var(--gradient-bg);
    border-radius: 10px;
    font-size: 18px;
    text-align: center;
    padding: 10px 20px;
    border: 2px solid rgba(255,255,255,0.15);
    font-family: 'Cinzel', serif;
    letter-spacing: 0.3px;
    margin: 16px 0 8px;
    box-shadow: 0 4px 16px rgba(201,146,42,0.4);
}
h2.relatedapps {
    color: #1a0e00 !important;
    background: var(--gradient-bg);
    border-radius: 10px;
    font-size: 20px;
    text-align: center;
    padding: 10px 20px;
    border: 2px solid rgba(255,255,255,0.15);
    margin: 16px 0 8px;
}
h3 {
    color: var(--accent-secondary);
    font-family: 'Cinzel', serif;
    font-size: 16px;
    padding: 8px 12px;
    border-left: 3px solid var(--accent-primary);
    background: rgba(201,146,42,0.08);
    border-radius: 0 8px 8px 0;
    margin: 14px 0 6px;
}
h3.hindi-translate {
    border-radius: 4px;
    font-size: 18px;
    text-align: center;
    color: #00308f;
    padding: 5px 25px;
    background: linear-gradient(to bottom, #f93, #fff 50%, #138808);
    border: 3px solid #00308f;
    font-family: 'Nunito', sans-serif;
}

/* ── BODY TEXT ── */
p {
    color: var(--text-primary);
    font-size: 14px;
    line-height: 1.7;
    padding: 8px 4px;
    font-family: 'Nunito', sans-serif;
}
p strong { color: var(--accent-secondary); }
p a { color: var(--accent-primary); text-decoration: underline; }
ol, ul { padding-left: 20px; }
li {
    color: var(--text-primary);
    font-size: 14px;
    line-height: 1.7;
    padding: 4px 0;
    font-family: 'Nunito', sans-serif;
}
li strong { color: var(--accent-secondary); }

/* ── DISCLAIMER BOX ── */
.red-disclaimer-box {
    background: var(--bg-card);
    border: 1.5px solid rgba(248,113,113,0.5);
    padding: 14px;
    margin: 16px 0;
    border-radius: 10px;
    color: var(--text-primary);
    font-size: 12px;
    line-height: 1.6;
    box-shadow: 0 4px 16px rgba(239,68,68,0.1);
}
.red-disclaimer-box b { color: var(--accent-secondary); }
.red-disclaimer-box a { color: var(--accent-primary); }
.centerio { text-align: center; font-weight: 800; font-size: 15px; color: var(--accent-secondary); text-decoration: underline; margin-bottom: 6px; }
.centerio1 { font-weight: 700; font-size: 12px; color: var(--red); }

/* ── BANNER IMAGE ── */
.page-content > img:first-child {
    width: 100%; border-radius: 12px;
    border: 1px solid var(--border-color);
    margin-bottom: 8px;
    box-shadow: 0 6px 20px var(--shadow-color);
}

/* ── FOOTER ── */
footer { position: relative; z-index: 1; }
.group-card, .group-card1 {
    display: flex; align-items: center;
    justify-content: space-between;
    padding: 12px 14px; margin-bottom: 0;
    border: 1px solid var(--border-color);
    border-radius: 0; overflow: hidden;
}
.group-card {
    background: linear-gradient(135deg, rgba(0,79,122,0.2) 0%, rgba(0,79,122,0.05) 100%);
    animation: telegram-border-animation 1s infinite;
}
.group-card1 {
    background: linear-gradient(135deg, rgba(43,122,64,0.2) 0%, rgba(43,122,64,0.05) 100%);
    animation: telegram-border-animation 1s infinite;
}
@keyframes telegram-border-animation {
    0%,100% { border-color: var(--border-color); }
    50% { border-color: var(--accent-primary); }
}
.join-text { margin-left: 10px; font-weight: 700; color: #7dd3fc; font-size: .9rem; }
.join-text1 { margin-left: 10px; font-weight: 700; color: #86efac; font-size: 1rem; }
.icon-telegram { font-size: 24px; color: #7dd3fc; }
.icon-telegram1 { font-size: 24px; color: #86efac; }
.seoquake-nofollow {
    display: inline-flex; align-items: center; justify-content: center;
    font-size: .9rem; font-weight: 700; text-decoration: none;
    padding: 8px 18px; border-radius: 8px; flex-shrink: 0;
    transition: all .3s ease-in-out; color: #fff !important;
}
.telegram-card .seoquake-nofollow { background: #004f7a; }
.telegram-card1 .seoquake-nofollow { background: var(--gradient-bg); color: #1a0e00 !important; }
.seoquake-nofollow:hover { transform: scale(1.05); filter: brightness(1.1); }
.main-background {
    background: linear-gradient(to top, #0a0a0f 0%, #1a1408 100%);
    color: var(--text-primary);
    border-top: 2px solid var(--accent-primary);
    padding: 16px 12px;
}
.center-text { font-size: .95rem; font-weight: 700; line-height: 2; text-align: center; }
.small-center-text { font-size: .75rem; font-weight: 700; line-height: 1.8; text-align: center; }
.link-style { color: var(--accent-secondary); text-decoration: underline; }
.footer-link { color: var(--accent-secondary); text-decoration: none; }
.mr193 { font-size: 14px; font-weight: 700; color: var(--green); text-align: center; padding: 10px; }

/* ── FAQ ── */
.container8262 { max-width: 700px; margin: 16px auto; padding: 10px; }
.faq-item { margin-bottom: 12px; }
.question8262 {
    font-size: 14px; color: #1a0e00;
    background: var(--gradient-bg);
    padding: 10px 28px 10px 12px;
    border-radius: 8px; margin-bottom: 0;
    position: relative; cursor: pointer;
    font-weight: 800; font-family: 'Nunito', sans-serif;
    box-shadow: 0 3px 10px rgba(201,146,42,0.3);
    transition: filter 0.2s;
}
.question8262:hover { filter: brightness(1.05); }
.question8262::after { content: "+"; position: absolute; top: 50%; right: 10px; transform: translateY(-50%); font-weight: 900; font-size: 16px; }
.question8262::before { content: "Q. " attr(data-question-number) ": "; font-weight: 900; }
.answer8262 {
    font-size: 13px; color: var(--text-primary);
    padding: 12px 14px; border-radius: 0 0 8px 8px;
    display: none;
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-top: none;
}
.answer8262::before { content: "Answer. "; font-weight: 700; color: var(--accent-secondary); }
.answer8262.show { display: block; }

/* ── BACK TO TOP ── */
.back-to-top {
    position: fixed; bottom: 20px; right: 14px; z-index: 8999;
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--gradient-bg); border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 6px 20px rgba(201,146,42,0.55);
    opacity: 0; pointer-events: none;
    transform: translateY(20px) scale(0.8);
    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.back-to-top.visible { opacity: 1; pointer-events: auto; transform: translateY(0) scale(1); }
.back-to-top i { color: #1a0e00; font-size: 1.05rem; }

img { max-width: 100%; height: auto; }
table, td, th { border: 1px solid var(--border-color); padding: 6px; color: var(--text-primary); }
th { background: rgba(201,146,42,0.15); color: var(--accent-secondary); font-weight: 700; }
tr:nth-child(even) { background: rgba(201,146,42,0.04); }
table { border-collapse: collapse; width: 100%; }
a { -webkit-tap-highlight-color: transparent; color: var(--accent-primary); }
</style>
</head>
<body>

<div class="header">
  <a href="index.php"><img style="border-radius:10px" class="logo-top" src="logo.jpg" alt="IndYonoGames Logo"></a>
  <a href="index.php" style="text-decoration:none;"><div class="header-text">IndYonoGames</div></a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer">
    <img class="telegram-top" src="telegram-join-button.png" alt="Telegram"></a>
  <div class="icon" onclick="toggleMenu()">&#9776; Menu</div>
</div>

<div class="menu-container" id="menuContainer">
  <div class="menu-row">
    <a href="index.php" class="menu-item"><i class="fa-solid fa-house"></i> Home</a>
    <a href="about-us.php" class="menu-item"><i class="fa-solid fa-clipboard-user"></i> About</a>
    <a href="contact-us.php" class="menu-item"><i class="fa-solid fa-envelope-circle-check"></i> Contact</a>
  </div>
  <div class="menu-row">
    <a href="privacy-policy.php" class="menu-item"><i class="fa-solid fa-shield-halved"></i> Privacy Policy</a>
    <a href="terms-and-conditions.php" class="menu-item"><i class="fa-solid fa-circle-exclamation"></i> Terms &amp; Conditions</a>
    <a href="disclaimer.php" class="menu-item"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
  </div>
</div>

<div class="navbar">
  <a href="index.php"><i class="fa-solid fa-house"></i> Home</a>
  <a href="about-us.php"><i class="fa-solid fa-address-book"></i> About</a>
  <a href="contact-us.php"><i class="fa-solid fa-envelope"></i> Contact Us</a>
  <a href="disclaimer.php" class="active"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-telegram"></i> Join Telegram</a>
</div>
<!-- header end -->

<div class="page-content">

<img src="https://AllYonoStore.com/img/disclaimer-notice.webp" alt="Yono Apps Disclaimer"/>

<h2 class="relatedapps">Comprehensive Disclaimer for IndYonoGames</h2>

<p><strong>Welcome to IndYonoGames</strong><br>This extensive disclaimer applies to all users of the IndYonoGames website and the wide array of applications ("Apps") available on it. Our platform includes diverse apps such as Poker, Rummy, Ludo, fantasy sports, investment apps, and trading apps. By accessing Yono Apps, you acknowledge and agree to the terms outlined in this disclaimer.</p>

<p><strong>Understanding the Scope of Our Platform</strong><br>IndYonoGames serves as a digital distribution platform for various third-party applications. Our role is limited to providing access to these apps. We do not develop, modify, or have any control over the content and functionality of these apps.</p>

<h2>User Responsibility and Financial Risk</h2>
<ol>
<li><strong>Risk of Financial Activities</strong>: The Apps, particularly those involving financial transactions like betting games or investment platforms, may carry inherent risks including the potential for significant financial loss. You are solely responsible for any financial outcomes resulting from your use of these Apps.</li>
<li><strong>Informed Decision-Making</strong>: We strongly encourage you to thoroughly research and understand each App, especially those involving financial risks, before participation. This includes seeking advice from financial experts or professionals as needed.</li>
<li><strong>No Endorsement of Financial Strategies</strong>: Our platform does not endorse any specific financial strategies, nor do we guarantee their success. Decisions made based on any App's content are solely your responsibility.</li>
</ol>

<h2>Legal Age and Compliance</h2>
<ol>
<li><strong>Age Restrictions</strong>: Some Apps, particularly those involving gambling or financial investments, are designed for use by individuals above a certain age (usually 18 or 21 years). You must comply with these age restrictions.</li>
<li><strong>Compliance with Local Laws</strong>: It is your responsibility to ensure that the use of any App complies with local laws and regulations. This includes understanding legal constraints related to gambling, investments, and other financial activities.</li>
</ol>

<h2>Critical Review of App-Specific Terms</h2>
<ol>
<li><strong>User Due Diligence</strong>: Before signing up, registering, or engaging with any App on our platform, it is crucial that you thoroughly review and understand that App's specific Terms and Conditions, disclaimers, and privacy policies.</li>
<li><strong>No Responsibility for Discrepancies</strong>: We are not responsible for any discrepancies or misunderstandings resulting from the App's terms, conditions, or policies.</li>
</ol>

<p><strong>No Liability for Losses</strong><br>Yono Apps shall not be liable for any direct, indirect, incidental, consequential, or punitive damages, including financial losses, resulting from the use or inability to use any App listed on our website. Your engagement with these Apps is entirely at your own risk and discretion.</p>

<h2>Awareness of Addiction Risks</h2>
<p>Risk of Addiction: Certain apps, especially games and those involving gambling or trading, can be addictive. We encourage responsible use of these apps and awareness of the potential for addictive behavior. Seeking Help: If you or someone you know is struggling with addiction related to these apps, we advise seeking professional help.</p>

<h2>Additional Disclaimers</h2>
<ul>
<li><strong>Variability in App Functionality</strong>: The functionality and content of the Apps may change over time, and we do not guarantee their consistency or availability.</li>
<li><strong>Non-Endorsement of App Content</strong>: Display of an App on our platform does not constitute an endorsement of its content or functionality.</li>
<li><strong>No Financial or Legal Advice</strong>: Yono Apps does not provide financial, legal, or investment advice. Any information obtained from our platform should not be treated as professional advice.</li>
</ul>

<p><strong>Changes and Amendments</strong><br>We reserve the right to modify this disclaimer at any time. Such changes will be effective immediately upon posting on our website. It is your responsibility to regularly review this disclaimer.</p>

<h3>Disclaimer for Rummy Apps on Yono Apps</h3>
<p><strong>General Notice</strong>: This is a brief and partial disclaimer. For full details, refer to the specific Rummy app's own disclaimer. Rummy games are intended for users aged 18+ and involve elements of skill and chance. Play at your own risk and ensure compliance with local gambling laws. Adding money to these games is done at the user's own risk.</p>

<h3>Disclaimer for Ludo Apps on Yono Apps</h3>
<p><strong>General Notice</strong>: This disclaimer is concise and may not cover all aspects. Review the full disclaimer in the specific Ludo app. Ludo apps are for entertainment and suitable for users 18+. Play responsibly and at your own risk. Any financial transactions within the app are the responsibility of the user.</p>

<h3>Disclaimer for Investment Apps on Yono Apps</h3>
<p><strong>General Notice</strong>: This disclaimer is partial. For complete information, review the specific investment app's disclaimer. Investment apps are for users aged 18+ and involve financial risks, including potential loss of capital. Decisions should be made based on personal financial situations. Any investments are made at the user's own risk.</p>

<h3>Disclaimer for Fantasy Sports Apps on Yono Apps</h3>
<p><strong>General Notice</strong>: This is a summarized disclaimer. Refer to the full disclaimer in each Fantasy Sports app for comprehensive details. These apps are intended for users aged 18+ and involve an element of financial risk. There is no guarantee of winning, and losses incurred are the user's responsibility. Play and engage in financial transactions at your own risk.</p>

<h3>Disclaimer for Other Earning Apps on Yono Apps</h3>
<p><strong>General Notice</strong>: This is an abbreviated disclaimer. Consult the full disclaimer in each earning app for more details. These apps are suitable for users aged 18+ and may offer potential income opportunities with no guaranteed earnings. Any financial involvement or transactions within these apps are entirely at the user's risk.</p>

<h3>General Disclaimer for Third-Party Apps on Yono Apps</h3>
<p><strong>Notice of Non-Affiliation and Disclaimer:</strong> Yono Apps does not operate, control, or manage any of the applications (Apps) listed on our platform, including Rummy, Ludo, Fantasy Sports, Investment Apps, Trading Apps, and other earning apps. These Apps are developed, owned, and operated by independent third parties.</p>

<p><strong>Third-Party Apps:</strong> Each App available through Yono Apps is the sole responsibility of the respective third-party developers or companies. Yono Apps acts as a platform to provide access to these Apps but is not involved in their operation or management.</p>

<p><strong>User Discretion and Responsibility:</strong> Users are advised that any interaction, financial transaction, or participation in activities within these Apps is conducted at their own risk. Yono Apps does not endorse or assume responsibility for the functionality, content, or any aspect of these third-party Apps.</p>

<p><strong>Age Restriction and Risk Acknowledgment</strong>: The Apps listed on our platform are intended for users aged 18+ and may involve various levels of risk, including financial risk. Users should play, invest, or engage in these Apps at their own discretion and risk.</p>

<p><strong>Independent App Disclaimers</strong>: We strongly recommend that users review and understand the full disclaimer, terms and conditions, and privacy policy of each App they intend to use. The brief disclaimers provided here on Yono Apps are not exhaustive and may not encapsulate all the terms of use and risks associated with each App.</p>

<p><strong>No Liability</strong>: Yono Apps assumes no liability for any losses, damages, or issues arising from the use of these third-party Apps. Our role is limited to providing a platform for accessing these Apps, and we are not responsible for their operation, content, or any outcomes from their use.</p>

<p><strong>Notice of Regional Legal Restrictions</strong>: Users are hereby informed that certain applications (Apps) available on Yono Apps, such as Rummy, Poker, and Fantasy Sports, may be subject to legal restrictions in certain states within India.</p>

<p>By using Yono Apps, users acknowledge and agree to this general disclaimer, affirming their understanding that the Apps are managed by respective third-party entities and that all interactions with these Apps are at their own risk and responsibility.</p>

<div class="red-disclaimer-box">
  <div class="centerio"><i class="fa-solid fa-triangle-exclamation"></i> Important Notice</div>
  <p><b>indyonogames.com</b> doesn't run or operate the apps listed here. The <b>rummy app</b> can be addictive and risky financially, so use them carefully. Only for <b>18+ people</b>.</p>
  <p>Please read our <b><a href="disclaimer.php">Disclaimer page</a></b> and the specific disclaimer for each app.</p>
  <p><b class="centerio1">Alert:</b> <b>Rummy</b>, a skill-based game, is banned by the government in <b>Andhra Pradesh, Sikkim, Nagaland, Assam, Arunachal Pradesh, Tamil Nadu, Odisha, and Telangana</b>.</p>
</div>

<p class="mr193">Thanks For Reading Till...</p>

</div><!-- /page-content -->

<footer>
  <div class="group-card telegram-card">
    <span style="display:flex;align-items:center;">
      <i class="fab fa-telegram icon-telegram"></i>
      <span class="join-text">Join Our Telegram Channel</span>
    </span>
    <a class="seoquake-nofollow" href="https://t.me/+FG0xq_lZH88zODI1" rel="nofollow noopener noreferrer" target="_blank">
      <i class="fab fa-telegram"></i> Join Now
    </a>
  </div>
  <div class="main-background">
    <div class="group-card1 telegram-card1">
      <span style="display:flex;align-items:center;">
        <span onclick="shareContent()" class="join-text1" style="cursor:pointer;">
          <i class="fa-solid fa-square-share-nodes"></i> Share With Friends!
        </span>
      </span>
      <a class="seoquake-nofollow" onclick="shareContent()" style="cursor:pointer;">
        <i class="fa-solid fa-share-from-square"></i> Click Here To Share
      </a>
    </div>
    <div class="center-text">
      <a class="link-style" href="about-us.php">About Us</a> &nbsp;&nbsp;
      <a class="link-style" href="disclaimer.php">Disclaimer</a> &nbsp;&nbsp;
      <a class="link-style" href="contact-us.php">Contact Us</a><br>
      <a class="link-style" href="privacy-policy.php">Privacy Policy</a> &nbsp;&nbsp;
      <a class="link-style" href="terms-and-conditions.php">Terms &amp; Conditions</a>
    </div>
    <br>
    <div class="small-center-text">
      <span><h1 style="font-size:14px;font-family:'Cinzel',serif;color:var(--accent-secondary);">Join Our Telegram:</h1></span>
      <a class="footer-link" href="https://t.me/+FG0xq_lZH88zODI1" target="_blank">
        <strong style="color:var(--accent-primary);font-size:16px;">Click Here</strong>
      </a><br><br>
      Copyright &copy; 2024 <a href="index.php" style="color:var(--accent-secondary);"><strong>indyonogames.com</strong></a> All Rights Reserved
    </div>
  </div>
</footer>

<button class="back-to-top" id="backToTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" aria-label="Back to top">
  <i class="fa-solid fa-chevron-up"></i>
</button>

<script>
(function(){
  var btn = document.getElementById('backToTop');
  if(!btn) return;
  window.addEventListener('scroll', function(){
    btn.classList.toggle('visible', window.scrollY > 300);
  }, {passive:true});
})();
</script>

</body>
</html>
