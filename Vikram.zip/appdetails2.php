<?php
$nid=$_GET["!"];
$json = file_get_contents("alldetails2/$nid.json"); $json = json_decode($json, true); $name= htmlspecialchars($json['name']);   $imglink= htmlspecialchars($json['imglink']);   $mwith= htmlspecialchars($json['mwith']);   $tdown= htmlspecialchars($json['tdown']);   $signbo= htmlspecialchars($json['signbo']);   $bonus=$signbo;
        
        $applink= htmlspecialchars($json['applink']);  $bigimglink= htmlspecialchars($json['bigimglink']);   $chanidv= htmlspecialchars($json['chanidv']);  $gameidff= htmlspecialchars($json['gameidff']);   $madd= htmlspecialchars($json['madd']);   $refperapro= htmlspecialchars($json['refperapro']);  $refcoms= htmlspecialchars($json['refcoms']);  
  $rgegg="alldetails/wmaupchanl.json";   $wch=file_get_contents($rgegg);
                          
                          $rgeggrge="alldetails/maupchanl.json";  
                          $mch=file_get_contents($rgeggrge);
                          
                          $rgeggrgergg="alldetails/upchanl.json";  
                          $uch=file_get_contents($rgeggrgergg);
                          
                          $rgeggrgergggr="alldetails/chanl.json";  
                          $rch=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/1websitelink.json";  
                          $weblink=file_get_contents($rgeggrgergggr); 
                          


?>

<!DOCTYPE html>
<html lang="hi">
<head>
    <base href="https://earn-pay.in/1opapps/"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $name ?> APK Download {2024} Get Bonus ₹<?php echo $$signbo ?> Instantly| All Rummy App</title>
    <meta name="description" content="<?php echo $name ?> Apk Download Get Bonus ₹51 Free for Account Creation in <?php echo $name ?> Application, <?php echo $name ?> App, <?php echo $name ?> App Link, <?php echo $name ?>, Palms Rummy, <?php echo $name ?> Game Download, <?php echo $name ?> Teen Patti APK Download" />
    <meta content='<?php echo $name ?>, <?php echo $name ?> Mod Apk, <?php echo $name ?> <?php echo $$mwith ?> Bonus, <?php echo $name ?> 51 Bonus, <?php echo $name ?> App Link, <?php echo $name ?> App, <?php echo $name ?> Apk, Rummy Bash Apk, <?php echo $name ?> App Download, New <?php echo $name ?>, <?php echo $name ?> Download, <?php echo $name ?> Apk Download, Palms Teen Patti, <?php echo $name ?> Download App, Palms Rummy Download, Palms Rummy' name='keywords' />
    <meta name="og:name" content="<?php echo $name ?>  APK" />
    <meta property="og:title" content="<?php echo $name ?> APK Download {2024} Get Bonus ₹<?php echo $mwithdrawal ?> Instantly" />
    <meta property="og:description" content="<?php echo $name ?> Apk Download Get Bonus ₹51 Free for Account Creation in <?php echo $name ?> Application, <?php echo $name ?> App, <?php echo $name ?> App Link, <?php echo $name ?>, Palms Rummy, <?php echo $name ?> Game Download, <?php echo $name ?> Teen Patti APK Downloadैश मिलता है।" />
    <meta property="og:image" content="kr/assets/site/IMG_20240510_181753_821.webp" />
    <link href="https://TrickyRummy.in" />
    <meta content='<?php echo $name ?> APK Download {2024} Get Bonus ₹<?php echo $mwithdrawal ?> Instantly' name='title' />
    <link rel="apple-touch-icon" sizes="57x57" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="60x60" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="72x72" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="76x76" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="114x114" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="120x120" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="144x144" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="152x152" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="apple-touch-icon" sizes="180x180" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="icon" type="image/png" sizes="192x192"  href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="icon" type="image/png" sizes="32x32" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="shortcut icon" href="/kr/assets/site/IMG_20240510_181753_821.webp" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="96x96" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <link rel="icon" type="image/png" sizes="16x16" href="/kr/assets/site/IMG_20240510_181753_821.webp">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/kr/assets/site/IMG_20240510_181753_821.webp">
    <meta name="theme-color" content="#ffffff">
    <meta property="og:url" content="https://trickyrummy.in/app/rummy-palms" />
    <meta name="robots" content="index, follow"/>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="application" />
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in//allrummyappslink_files/index.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in//allrummyappslink_files/style.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in//allrummyappslink_files/allrummyappslink_header.css">
    <script src="https://trickyrummy.in//allrummyappslink_files/main.js" type="text/javascript"></script>
    <script src="https://trickyrummy.in//allrummyappslink_files/vungopro.min.js" type="text/javascript"></script> 
    <script src="https://trickyrummy.in//allrummyappslink_files/index.js" type="text/javascript"></script>

	<!--<link rel="stylesheet" href="css/style.css">-->
	<!--<script type="text/javascript" src="js/download.js"></script>-->
    <!--
    <style>
        .allrummyappslink_Slider{
        	border: 1px dashed #d60000;
        	background-color: #fff200;
        	font-family: Sofia,sans-serif;
        	font-variant: small-caps;
        }
        .allrummyappslink_Slider .AllRummyApps_ticker {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }
        .allrummyappslink_Slider .AllRummyApps_ticker .news {
            width: 80%;
        	margin: -2rem 0 -2rem 0;
        }
        .allrummyappslink_Slider .AllRummyApps_ticker .title {
            width: 20%;
        	font-size: .3rem;
            text-align: center;
            background: transparent;
            color: #0013a4;
        }
        
        .allrummyappslink_Slider .AllRummyApps_ticker .title p {
            font-size: .2rem;
        	line-height: .4rem;
        	font-weight: bold;
        }
        .allrummyappslink_Slider .AllRummyApps_ticker .news marquee {
            font-size: .2rem;
        	color: black;
            font-weight: 600;
        	padding-top: .18rem;
        	line-height: .4rem;
        }
    </style>
    -->
</head>

<body>
	<div class="wrap">
		<header class="green_bg flex">
    <div class="flex flex_grow">
       <span><a href="index"><img class="txt flex_grow" src="<?php echo $mch  ;?>" alt="All Rummy Apps"></a> </span></p>
    </div>
    <div class="share-link" onclick="openLink(7)" title="Share this post link">
        <img src="https://trickyrummy.in/allrummyappslink_img/20231106_193029%20(1).webp" alt="All Rummy App" style="
        height: .55rem;
        margin-top: auto;
        margin-bottom: auto;
        ">
    </div>
    <div class="menu">
       <a onclick="headerNav()"><span class="fa fa-th-list"></span> Menu</a>
    </div>
    <div class="headerNav hide" id="headerNav">
       <ul class="flex">
         <li><a href="index"><i class="fa">&#xf015;</i>Home</a></li>
         <li><a href="about-us"><i class="fa">&#xf007;</i>About</a></li>
         <li><a href="contact-us"><i class="fa">&#xf095;</i>Contact</a></li>
         <li><a href="privacy-policy"><i class="fa">&#xf132;</i>Privacy</a></li>
         <li><a href="terms-and-conditions"><i class="fa">&#xf2bb;</i>T&C</a></li>
         <li><a href="all-rummy-games"><i class='fa'>&#xf02c;</i>Links</a></li>
       </ul>
       <div class="mask"></div>
     </div>
 </header>
 <nav class="nav_bar">
    <ul>
       <li class="current"><a href="index">Home</a></li>
       <li class=""><a href="about-us">About</a></li>
       <li class=""><a href="contact-us">Contact</a></li>
       <li class=""><a href="privacy-policy">Privacy</a></li>
       <li class=""><a href="all-rummy-games">Links</a></li>
    </ul>
 </nav>
 <h1 style="display: none;">All Rummy App</h1>	
	<img class="bg" style="min-height: 100vh;" src="<?php echo $bigimglink ?>" onclick="krh('<?php echo $applink ?>')" alt="<?php echo $name ?>  APK">		

		
			
		
		         	
		 <!-- <div class="allrummyappslink_Slider">-->
			<!--<div class="AllRummyApps_ticker">-->
			<!--  <div class="title"><p>About :-</p></div>-->
			<!--  <div class="news">-->
			<!--	<marquee>-->
			<!--	<p>इसके अंदर खाता बनाना बहुत ही आसान है, आपके पास एक चालू मोबाइल नंबर होना चाहिए, जिससे आपको ₹15 का बोनस मिलेगा। -->
			<!--		और इस एप्लिकेशन के नवीनतम अपडेट के साथ, इसके रेफर प्रोग्राम में काफी अच्छा सुधार हुआ है, जिसकी मदद से आप अपने दोस्तों को आमंत्रित करके भी काफी अच्छी राशि कमा सकते हैं।-->
			<!--		<?php echo $name ?>, <?php echo $name ?> Mod Apk, <?php echo $name ?> <?php echo $mwithdrawal ?> Bonus, <?php echo $name ?> 51 Bonus, <?php echo $name ?> App Link, <?php echo $name ?> App, <?php echo $name ?> Apk, Rummy Bash Apk, <?php echo $name ?> App Download, New <?php echo $name ?>, <?php echo $name ?> Download, <?php echo $name ?> Apk Download, Palms Teen Patti, <?php echo $name ?> Download App, Palms Rummy Download, Palms Rummy-->
			<!--	</p>-->
			<!--	</marquee>-->
			<!--  </div>-->
			<!--  </div>-->
		 <!-- </div>-->
	
			  
		<div class="telegram">
		<a href="<?php echo $rch ?>" target="_blank"><p><i class="fa">&#xf2c6;</i> Join Telegram For Prediction</p></a>
		</div>
	
	
		<div class="App_Recomended"> 
			<h2><i class="fa">&#xf265;</i> Tranding Rummy Apps <i class="fa">&#xf265;</i></h2>
		</div>
	
		<div class="LootEarning_Com tab_box">
			<div class="tab_cont">
			   <div class="sub_box ">
				  <ul>
				 <div id="gy"><?php echo $result2 ?>   </div>
			   </div>
			</div>
		</div>
	
		<div class="Dont_Copy_AllRummyApp_Com"> 
			<h2>About <?php echo $name ?>  App !</h2>
			<p>इस <b><?php echo $name ?> </b> एप्लीकेशन के अंदर आप लोगों को अकाउंट बनाने पर ₹<?php echo $bonus ?> का बोनस मिलता है तथा यह एप्लीकेशन काफी ज्यादा अच्छा है और इसके अंदर आप लोगों को निकासी मिलने की ज्यादा संभावना है। </p>
		 
			<img class="logo" src="<?php echo $imglink ?>" alt="<?php echo $name ?>  Logo - All Rummy App">
	  
			<p>इसमें <b>Refer & Earn</b> कार्यक्रम दिया गया है, जिसमें प्रत्येक रेफर पर तो बोनस मिलता है और साथ मे <b> <?php echo $refcoms ?>%</b> का लाइव टाइम कमीशन भी प्राप्त किया जा सकता है, साथ ही इसमें <b><?php echo $refperapro?>%</b> का एफिलिएट प्रोग्राम भी दिया गया है। जिससे आपकी एक्स्ट्रा इंकम Generate होती हैं।</p>
			
			<h3><?php echo $name ?>  App Info </h3>
			<p>जिस ऐप्प आप कमाई करने वाले हैं, तो अगर आप इस ऐप के सभी प्रोग्राम को जानना चाहते हैं, तो आप इस <b>Article</b> को पूरा पढ़ सकते हैं, जिससे आपको इस गेम के सभी प्रोग्राम के बारे में पता चल जाएगा।</p>
			 <table>
			   <tr>
				  <th><u>Sr.</u></th>
				  <th><u>Title</u></th>
				  <th><u>Details</u></th>
			   </tr>
	  
			   <tr>
				  <td>1.</td>
				  <td>App Name :-</th>
				  <td><?php echo $name ?> </td>
			   </tr>
	  
			   <tr>
				  <td>2.</td>
				  <td>Sign-Up Bonus :-</th>
				  <td>Rs. <?php echo $signbo ?></td>
			   </tr>
	  
			   <tr>
				  <td>3.</td>
				  <td>Min.Withdrawal :-</th>
				  <td>Rs. <?php echo $mwith ?>/-</td>
			   </tr>
			       <td>4.</td>
				   <td>Official Website :-</th>
				   <td><a href="/"><u><?php echo $weblink ?></u></a></td>
				</tr>
	                   </table>
			
			 <p>यह एप्लीकेशन <b>Online</b> पैसे कमाने का एक शानदार तरीका हो सकता है, क्योंकि इस एप्लीकेशन के जरिए आप घर बैठे पैसे कमा सकते हैं, वह भी अपने मोबाइल फोन का उपयोग करके, जो आप लोगों के लिए बहुत अच्छा साबित हो सकता है। इस एप्लीकेशन का नाम <b><?php echo $name ?>  APK</b> है जिसमें आप ऑनलाइन कमाई कर सकेंगे। केवल 18 वर्ष+ आयु का उपयोग करें।</p>
	  
			 <h2>FAQ's <?php echo $name ?> </h2>		
		 
			 <h3>Q.1. <?php echo $name ?>  में कितना बोनस मिलता है?</h3>
			 <p><strong>Ans.</strong> <?php echo $name ?>  में आपको ₹<?php echo $mwith ?> रुपए का बोनस मिलता है।</p>
			 <h3>Q.2. <?php echo $name ?>  Apk में निकासी कितना है?</h3>
			 <p><strong>Ans.</strong> <?php echo $name ?>  में न्यूनतम निकासी ₹<?php echo $mwith ?> रुपये है।</p>
			 <h3>Q.3. <?php echo $name ?>  में न्यूनतम निकासी क्या है?</h3>
			 <p><strong>Ans.</strong> <?php echo $name ?>  में न्यूनतम ऐड कैश ₹<?php echo $madd ?> रुपये है।</p>
			   
		 </div>
		</div>
		<div class="allrummyappslink_Slider">
            <div class="AllRummyApps_ticker">
               <div class="title">
               <p>Tag's:-</p>
               </div>
  <div class="news">
                  <marquee>
                     <p>
                        If You People Download <?php echo $name ?> Application, Then You People Get To See A Very Good Bonus Program In It, As Well As A Very Minimum Withdrawal Option, Through Which You Can Transfer Your Amount To The Bank Account. <strong style="color: rgb(8, 0, 255);">Keywords :-</strong> <?php echo $name ?>, <?php echo $name ?> Mod Apk, <?php echo $name ?> <?php echo $mwith ?> Bonus, <?php echo $name ?> <?php echo $bonus ?>  Bonus, <?php echo $name ?> App Link, <?php echo $name ?> App, <?php echo $name ?> Apk, <?php echo $name ?> Apk, <?php echo $name ?> App Download, New <?php echo $name ?>, <?php echo $name ?> Download, <?php echo $name ?> Apk Download, <?php echo $name ?> , <?php echo $name ?> Download App, <?php echo $name ?> Download, <?php echo $name ?>                     </p>
                  </marquee>
               </div>
            </div>
         </div>
        
<div class="AllRummyApps-footer">
    <div class="devider"></div>
    <div class="links">
        <a href="about-us" class="border"><i class="fa fa-user-o">&nbsp;</i> About Us</a>
        <a href="contact-us" class="border"><i class="fa fa-phone">&nbsp;</i>Contact Us</a>
        <a href="privacy-policy" class="border"><i class="fa fa-shield">&nbsp;</i>Privacy Policy</a>
        <a href="terms-and-conditions" class="border"><i class="fa fa-vcard-o">&nbsp;</i> Terms & Conditions</a>
        <a href="disclaimer"><i class="fa fa-exclamation-triangle">&nbsp;</i>Disclaimer</a>
        <div class="devider"></div>
    </div>
    <p>Copyright © <a href="/" style="color: white;"><strong><?php echo $weblink ?></strong></a> All Rights Reserved</p>
</div>
 
<!--<script src="/allrummyappslink_files/share.js" type="text/javascript"></script>-->	
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  // Set the interval to 100 milliseconds
  setInterval(function() {
    $.ajax({
      url: "allapps.php?jj=6&hh=3",
      success: function(data) {
        // Update the HTML content of the element with ID 'gy'
        $("#gy").html(data);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Log any error that occurs during the request
        console.error("AJAX request failed: " + textStatus, errorThrown);
      }
    });
  }, 1000); // Interval set to 100 milliseconds
</script>
<script>
            function copyText(text, callback) {
                var tag = document.createElement('input');
                tag.setAttribute('id', 'kr_input');
                tag.value = text;
                document.getElementsByTagName('body')[0].appendChild(tag);
                document.getElementById('kr_input').select();
                document.execCommand('copy');
                document.getElementById('kr_input').remove();
                if (callback) {
                    callback(text);
                }
            }

            function krh(kr){
                

                    let copyObj = '{"from_gameid":"<?php echo $gameidff ?>","channelCode":"<?php echo $chanidv ?>"}';
                    let copyStr = copyObj; //JSON.stringify(copyObj);
                    
                    copyText(copyStr, function() {
                        console.log('Copy Success', copyStr);
                    });
                                    window.location.href = kr;
            }
        </script>
          

	</body>
	</html>
	