<?php
ini_set('max_execution_time','600');
ini_set('memory_limit','512M');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");

// POSITIONS
$main_positions=file_exists(__DIR__.'/alldetails/main_positions.json')?json_decode(file_get_contents(__DIR__.'/alldetails/main_positions.json'),true):[];

// INDEX TAGS
$index_tags_file=__DIR__.'/alldetails/index_tags.json';
$index_tags_cfg=file_exists($index_tags_file)?json_decode(file_get_contents($index_tags_file),true):[];
$index_tags_label=htmlspecialchars($index_tags_cfg['label']??'Tags:');
$index_tags_raw=$index_tags_cfg['tags']??'Yono Apps, yono rummy, yono arcade, yono 777, yono vip list, all yono apk, all new yono app, rummy, new rummy yono app, yono app india, 51 bonus, 500 bonus yono apps, Yono Apps telegram, yono promocode, promo code, bonus code';
$index_tags_items=array_filter(array_map('trim',explode(',',$index_tags_raw)));

// HOMEPAGE SEO META
$homepage_seo_file=__DIR__.'/alldetails/homepage_seo.json';
$homepage_seo=file_exists($homepage_seo_file)?json_decode(file_get_contents($homepage_seo_file),true):[];
$hp_meta_title   = trim($homepage_seo['meta_title']   ?? 'IndYonoGames - Download All ₹51 To ₹500 Bonus App And New Yono Rummy Apps');
$hp_meta_desc    = trim($homepage_seo['meta_desc']    ?? 'IndYonoGames - Download All Yono Rummy App And Get ₹500 To ₹1500 Sign Up Bonus With Minimum Withdrawal In ₹100 Each Yono App | Yono Rummy | Yono App | Yono Games');
$hp_content_title= trim($homepage_seo['content_title']?? 'IndYonoGames — India\'s Biggest Yono App Downloading Platform');
$hp_content_body = trim($homepage_seo['content_body'] ?? 'IndYonoGames is a trusted platform where players can discover a huge collection of real money gaming apps in one place. From exciting rummy tables to slot spins and bingo fun, enjoy popular categories like Rummy, Slots, Bingo, Arcade, and Spin games with daily bonuses and big rewards. Download & get ₹500 to ₹1500 Sign Up Bonus with minimum withdrawal in ₹100 on each Yono App including Yono Rummy, Yono 777, Yono VIP, Yono Slots, Yono Arcade and many more.');

// Build tag pills HTML
$tags_pills_html='';
foreach($index_tags_items as $tag){
  if(trim($tag)==='')continue;
  $tags_pills_html.='<span class="tag-pill"><i class="fa-solid fa-hashtag" aria-hidden="true"></i>'.htmlspecialchars(trim($tag)).'</span>';
}

// NEW APPS 1-5
function buildNewApp($file){
  if(!file_exists($file))return"<li class='no-apps-msg'><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3></li>";
  $d=json_decode(file_get_contents($file),true);
  $img=htmlspecialchars($d['imglink']??'');$mwith=htmlspecialchars($d['mwith']??'');
  $bonus=htmlspecialchars($d['signbo']??'');$nidd=htmlspecialchars($d['nid']??'');
  $display_name=htmlspecialchars($d['display_name']??$d['name']??'');
  $folder_name=htmlspecialchars($d['folder_name']??$d['name']??'');
  $tag_text=!empty($d['tag_text'])?htmlspecialchars($d['tag_text']):'';
  $tag_color=!empty($d['tag_color'])?htmlspecialchars($d['tag_color']):'#e3232c';
  if(!$nidd)return"<li class='no-apps-msg'><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3></li>";
  $show_name=$display_name?:htmlspecialchars($d['name']??'');
  $link_name=$folder_name?:htmlspecialchars($d['name']??'');
  $fv='<li class="app-item">
    <div class="app-icon-wrap">
    <img src="'.$img.'" alt="'.$show_name.' App Icon" class="app-icon" loading="lazy" decoding="async" width="66" height="66"/>';
  if($tag_text)$fv.='<span class="corner-tag" style="background:'.$tag_color.';">'.$tag_text.'</span>';
  $fv.='</div>
    <div class="app-details">
    <h6 class="app-title">'.$show_name.'</h6>
    <span class="bonus-amount"><i class="fa-solid fa-gift" aria-hidden="true"></i> Sign Up Bonus &#8377;'.$bonus.'</span>
    <span class="withdrawal-amount"><i class="fa-solid fa-building-columns" aria-hidden="true"></i> Min. Withdrawal &#8377;'.$mwith.'</span>
    </div>
    <div class="app-actions">
    <a href="'.htmlspecialchars($link_name).'" aria-label="Download '.$show_name.'"><button class="dl-btn"><i class="fa-solid fa-download" aria-hidden="true"></i> Download</button></a>
    </div>
  </li>';
  return $fv;
}
$new1=buildNewApp("new/1.json");$new2=buildNewApp("new/2.json");
$new3=buildNewApp("new/3.json");$new4=buildNewApp("new/4.json");$new5=buildNewApp("new/5.json");

// ALL APPS
$result2='';
$txn="allappss.json";
if(file_exists($txn)){
  $file=file_get_contents($txn);$pro=explode(";'",$file);$entries=[];
  foreach($pro as $entry){$json=json_decode($entry,true);if(json_last_error()===JSON_ERROR_NONE&&isset($json['nid']))$entries[]=$json;}
  usort($entries,function($a,$b)use($main_positions){$pA=$main_positions[$a['nid']]??999;$pB=$main_positions[$b['nid']]??999;return $pA===$pB?$a['nid']<=>$b['nid']:$pA<=>$pB;});
  foreach($entries as $json){
    $nid=htmlspecialchars($json['nid']);
    if(!file_exists("alldetails/$nid.json"))continue;
    $j=json_decode(file_get_contents("alldetails/$nid.json"),true);
    $img=htmlspecialchars($j['imglink']??'');$mwith=htmlspecialchars($j['mwith']??'');
    $bonus=htmlspecialchars($j['signbo']??'');$nidd=htmlspecialchars($j['nid']??'');
    $display_name=htmlspecialchars($j['display_name']??$j['name']??'');
    $folder_name=htmlspecialchars($j['folder_name']??$j['name']??'');
    $tag_text=!empty($j['tag_text'])?htmlspecialchars($j['tag_text']):'';
    $tag_color=!empty($j['tag_color'])?htmlspecialchars($j['tag_color']):'#e3232c';
    if(!$nidd)continue;
    $show_name=$display_name?:htmlspecialchars($j['name']??'');
    $link_name=$folder_name?:htmlspecialchars($j['name']??'');
    $fv='<li class="app-item" data-nid="'.$nidd.'">
      <div class="app-icon-wrap">
      <img src="'.$img.'" alt="'.$show_name.' App Icon" class="app-icon" loading="lazy" decoding="async" width="66" height="66"/>';
    if($tag_text)$fv.='<span class="corner-tag" style="background:'.$tag_color.';">'.$tag_text.'</span>';
    $fv.='</div>
      <div class="app-details">
      <h6 class="app-title">'.$show_name.'</h6>
      <span class="bonus-amount"><i class="fa-solid fa-gift" aria-hidden="true"></i> Sign Up Bonus &#8377;'.$bonus.'</span>
      <span class="withdrawal-amount"><i class="fa-solid fa-building-columns" aria-hidden="true"></i> Min. Withdrawal &#8377;'.$mwith.'</span>
      </div>
      <div class="app-actions">
      <a href="'.$link_name.'/" aria-label="Download '.$show_name.'"><button class="dl-btn"><i class="fa-solid fa-download" aria-hidden="true"></i> Download</button></a>
      </div>
    </li>';
    $result2.=$fv;
  }
}else{$result2="<li class='no-apps-msg'><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3></li>";}

// UPCOMING APPS
$upcomingAppsHtml='';
if(file_exists("allappss4.json")){
  $entries=explode(";'",file_get_contents("allappss4.json"));$seenNids=[];
  foreach($entries as $entry){
    $entry=trim($entry);if(empty($entry))continue;
    $json=json_decode($entry,true);if(!$json||!isset($json['nid']))continue;
    $nid=htmlspecialchars($json['nid']);if(in_array($nid,$seenNids))continue;$seenNids[]=$nid;
    $df="alldetails4/d{$nid}.json";if(!file_exists($df))continue;
    $d=json_decode(file_get_contents($df),true);if(!$d)continue;
    $img=htmlspecialchars($d['imglink']??'');$mwith=htmlspecialchars($d['mwith']??'');
    $bonus=htmlspecialchars($d['signbo']??'');
    $display_name=htmlspecialchars($d['display_name']??$d['name']??'');
    $launch=htmlspecialchars($d['launch_date']??'');
    $tag_text=!empty($d['tag_text'])?htmlspecialchars($d['tag_text']):'';
    $tag_color=!empty($d['tag_color'])?htmlspecialchars($d['tag_color']):'#e3232c';
    if(empty($launch))continue;
    $show_name=$display_name?:htmlspecialchars($d['name']??'');
    $fv='<li class="app-item">
      <div class="app-icon-wrap">
      <img src="'.$img.'" alt="'.$show_name.' App Icon" class="app-icon" loading="lazy" decoding="async" width="66" height="66"/>';
    if($tag_text)$fv.='<span class="corner-tag" style="background:'.$tag_color.';">'.$tag_text.'</span>';
    $fv.='</div>
      <div class="app-details">
      <h6 class="app-title">'.$show_name.'</h6>
      <span class="bonus-amount"><i class="fa-solid fa-gift" aria-hidden="true"></i> Sign Up Bonus &#8377;'.$bonus.'</span>
      <span class="withdrawal-amount"><i class="fa-solid fa-building-columns" aria-hidden="true"></i> Min. Withdrawal &#8377;'.$mwith.'</span>
      <div class="countdown-container" data-launch="'.$launch.'"><div class="countdown" id="countdown-'.$nid.'">Calculating...</div></div>
      </div>
    </li>';
    $upcomingAppsHtml.=$fv;
  }
}
if(empty($upcomingAppsHtml))$upcomingAppsHtml='<li class="no-apps-msg"><h3>NO UPCOMING APPS RIGHT NOW!</h3></li>';

// SITE SETTINGS
$site_cfg=file_exists(__DIR__.'/alldetails/site_settings.json')?json_decode(file_get_contents(__DIR__.'/alldetails/site_settings.json'),true):[];
$apps_listed=htmlspecialchars($site_cfg['apps_listed']??'50+');
$tg_url=htmlspecialchars($site_cfg['telegram_url']??'https://t.me/+FG0xq_lZH88zODI1');
$wa_url=htmlspecialchars($site_cfg['whatsapp_url']??'https://whatsapp.com/channel/0029Vae5jzD9hXFAbkOIkS0s');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title><?php echo htmlspecialchars($hp_meta_title); ?></title>
<link rel="canonical" href="https://indyonogames.com/"/>
<meta name="description" content="<?php echo htmlspecialchars($hp_meta_desc); ?>"/>
<meta name="keywords" content="Yono Apps, yono rummy, yono arcade, yono 777, yono vip list, all yono apk, new yono app, rummy, yono app india"/>
<meta property="og:image" content="https://indyonogames.com/logo.jpg"/>
<meta property="og:url" content="https://indyonogames.com"/>
<meta property="og:title" content="<?php echo htmlspecialchars($hp_meta_title); ?>"/>
<meta property="og:type" content="website"/>
<meta name="robots" content="index, follow"/>
<meta name="theme-color" content="#e3232c">
<script type="application/ld+json">{"@context":"https://schema.org/","@type":"WebSite","name":"IndYonoGames","url":"https://indyonogames.com"}</script>
<!-- GTM -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../www.googletagmanager.com/gtm5445.php'+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-57BVT9NQ');</script>
<!-- Font Awesome -->
<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"></noscript>
<link rel="icon" type="image/png" href="logo.jpg">
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
/* ─── RESET & BASE ───────────────────────────────────────────── */
html{scroll-behavior:smooth;-webkit-overflow-scrolling:touch;text-size-adjust:100%;-webkit-text-size-adjust:100%;}
:root{
  --bg:#fff;--text:#1a0505;--text2:#7a3333;
  --red:#e3232c;--red2:#c0392b;--green:#16a34a;
  --glow:rgba(227,35,44,.18);--border:rgba(227,35,44,.18);
  --grad:linear-gradient(135deg,#c0392b 0%,#e3232c 50%,#ff4757 100%);
}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'Nunito',Arial,sans-serif;-webkit-font-smoothing:antialiased;}
a{text-decoration:none;-webkit-tap-highlight-color:transparent;color:inherit;}
img{max-width:100%;height:auto;display:block;}

/* ─── TYPEWRITER ─────────────────────────────────────────────── */
.typewriter-bar{background:linear-gradient(135deg,rgba(227,35,44,.09),rgba(192,57,43,.03));border-bottom:1px solid var(--border);padding:9px 16px;text-align:center;min-height:38px;display:flex;align-items:center;justify-content:center;}
.typewriter-text{font-size:13px;font-weight:700;color:var(--red);letter-spacing:.3px;}
.typewriter-cursor{display:inline-block;width:2px;height:14px;background:var(--red);margin-left:2px;vertical-align:middle;animation:blink .7s step-end infinite;}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}

/* ─── SOCIAL PROOF ───────────────────────────────────────────── */
.social-proof-bar{display:flex;align-items:stretch;background:var(--bg);border-bottom:2px solid var(--border);}
.sp-item{display:flex;align-items:center;gap:6px;padding:10px 8px;border-right:1px solid var(--border);flex:1;justify-content:center;min-width:0;}
.sp-item:last-child{border-right:none;}
.sp-icon{font-size:1.1rem;flex-shrink:0;}
.sp-icon.gold{color:var(--red);}.sp-icon.green{color:var(--green);}.sp-icon.blue{color:var(--red);}
.sp-text{display:flex;flex-direction:column;min-width:0;}
.sp-num{font-size:13px;font-weight:900;color:var(--text);font-family:'Cinzel',serif;line-height:1.2;white-space:nowrap;}
.sp-label{font-size:9px;color:var(--text2);font-weight:700;text-transform:uppercase;letter-spacing:.4px;margin-top:1px;white-space:nowrap;}

/* ─── FOMO TOAST ─────────────────────────────────────────────── */
.fomo-toast{position:fixed;bottom:90px;left:12px;z-index:9500;background:#fff;border:1px solid var(--border);border-radius:14px;padding:10px 14px;display:flex;align-items:center;gap:10px;max-width:min(262px,calc(100vw - 24px));pointer-events:none;transform:translateX(-130%);transition:transform .4s cubic-bezier(.34,1.56,.64,1);will-change:transform;box-shadow:0 4px 20px rgba(227,35,44,.15);}
.fomo-toast.show{transform:translateX(0);}
.fomo-avatar{width:36px;height:36px;border-radius:10px;background:var(--grad);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:17px;}
.fomo-body{min-width:0;flex:1;}
.fomo-name{font-size:12px;font-weight:800;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.fomo-action{font-size:11px;color:var(--text2);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.fomo-time{font-size:10px;color:var(--red);font-weight:700;margin-top:2px;}
.fomo-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;flex-shrink:0;}

/* ─── HEADER ─────────────────────────────────────────────────── */
.header{background:linear-gradient(135deg,#b71c1c 0%,#e3232c 50%,#ff4757 100%);border-bottom:3px solid #b71c1c;color:#fff;display:flex;justify-content:space-between;align-items:center;padding:8px 12px;box-shadow:0 3px 14px rgba(227,35,44,.35);}
.logo-top{width:35px;height:35px;border-radius:10px;border:2px solid rgba(255,255,255,.5);flex-shrink:0;}
.telegram-top{width:54px;height:auto;flex-shrink:0;}
.header-text{flex-grow:1;margin:0 8px;font-weight:800;font-size:clamp(18px,5vw,22px);font-family:'Cinzel',serif;color:#fff;letter-spacing:.5px;text-shadow:0 1px 4px rgba(0,0,0,.3);}
.menu-icon{display:block;text-align:right;padding:6px 8px;color:#fff;font-size:15px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;touch-action:manipulation;user-select:none;}
.menu-container{display:none;background:linear-gradient(135deg,#b71c1c,#c0392b);padding:16px;border-bottom:1px solid rgba(255,255,255,.2);}
.menu-item{background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);color:#fff;padding:8px 14px;margin:4px;display:inline-block;border-radius:10px;font-family:'Nunito',sans-serif;font-weight:700;font-size:11px;}
.menu-item:hover{background:rgba(255,255,255,.28);}
.menu-row{display:flex;justify-content:space-around;flex-wrap:wrap;}

/* ─── NAVBAR ─────────────────────────────────────────────────── */
.navbar{display:flex;justify-content:center;flex-wrap:nowrap;border-bottom:2px solid rgba(227,35,44,.25);overflow-x:auto;overflow-y:hidden;background:linear-gradient(90deg,#fff5f5,#fff,#fff5f5);-webkit-overflow-scrolling:touch;scrollbar-width:none;}
.navbar::-webkit-scrollbar{display:none;}
.navbar a{white-space:nowrap;color:var(--text2);padding:7px 10px;border-right:1px solid rgba(227,35,44,.12);font-size:12px;font-weight:700;display:inline-flex;align-items:center;gap:4px;flex-shrink:0;}
.navbar a:last-child{border-right:none;}
.navbar a.active,.navbar a:hover{background:rgba(227,35,44,.10);color:var(--red);}

/* ─── BANNER ─────────────────────────────────────────────────── */
.banner-img{width:100%;height:auto;display:block;}

/* ─── LIVE BAR ───────────────────────────────────────────────── */
.live-bar{display:flex;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,rgba(34,197,94,.08),rgba(16,185,129,.04));border:1px solid rgba(34,197,94,.20);border-radius:12px;margin:8px 12px 0;padding:9px 16px;flex-wrap:wrap;gap:8px;}
.live-dot{width:10px;height:10px;border-radius:50%;background:#22c55e;flex-shrink:0;}
.live-label{font-size:12px;color:#16a34a;font-weight:700;text-transform:uppercase;letter-spacing:.6px;}
.live-count{font-size:18px;font-weight:900;color:#16a34a;font-family:'Cinzel',serif;min-width:48px;text-align:center;}
.live-suffix{font-size:12px;color:var(--text2);font-weight:600;}

/* ─── SEARCH ─────────────────────────────────────────────────── */
.search-wrap{max-width:380px;margin:16px auto;padding:0 14px;}
.search-inner{position:relative;}
#searchInput{width:100%;padding:12px 48px 12px 18px;font-size:15px;font-weight:600;font-family:'Nunito',sans-serif;color:var(--text);background:#fff;border:1.5px solid var(--border);border-radius:999px;outline:none;transition:border-color .2s;box-sizing:border-box;-webkit-appearance:none;appearance:none;}
#searchInput::placeholder{color:var(--text2);opacity:.85;}
#searchInput:focus{border-color:var(--red);box-shadow:0 0 0 3px var(--glow);}
.search-icon{position:absolute;right:16px;top:50%;transform:translateY(-50%);font-size:1.1rem;color:var(--red);pointer-events:none;}

/* ─── TABS ───────────────────────────────────────────────────── */
.tabs-wrap{touch-action:pan-y;position:relative;}
.tabs{display:flex;justify-content:center;margin:18px auto 12px;background:#fff5f5;border-radius:18px;padding:5px;border:1px solid var(--border);max-width:min(400px,calc(100% - 28px));}
.tab{flex:1;padding:10px 8px;margin:0 3px;font-weight:700;font-size:clamp(12px,3.5vw,14px);font-family:'Nunito',sans-serif;color:var(--text2);background:transparent;border:none;border-radius:13px;cursor:pointer;transition:background .18s,color .18s;touch-action:manipulation;white-space:nowrap;}
.tab:hover{color:var(--red);background:rgba(227,35,44,.08);}
.tab.active{background:var(--grad);color:#fff;font-weight:800;box-shadow:0 4px 12px rgba(227,35,44,.35);}
.tab-content{display:none;}
.tab-content.active{display:block;}

/* ─── APP CARDS ──────────────────────────────────────────────── */
.app-list{list-style:none;counter-reset:app-counter;padding:6px;margin:0;}
.no-apps-msg{padding:24px;text-align:center;color:var(--text2);}
.app-item{display:flex;align-items:center;background:#fff;border:1px solid var(--border);border-radius:14px;margin-bottom:8px;padding:8px 10px;position:relative;overflow:hidden;box-shadow:0 1px 6px rgba(227,35,44,.06);}
.app-item::before{counter-increment:app-counter;content:counter(app-counter)".";font-weight:bold;font-size:.9em;margin-right:4px;color:#ccc;flex-shrink:0;}
.app-item::after{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--grad);border-radius:14px 0 0 14px;}
.app-icon-wrap{position:relative;display:inline-block;flex-shrink:0;}
.app-icon{width:66px;height:66px;border-radius:14px;object-fit:cover;border:2px solid var(--border);}
.app-details{flex-grow:1;margin-left:10px;min-width:0;}
.app-title{font-family:'Nunito',sans-serif;font-size:.95em;font-weight:800;margin:0 0 4px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.bonus-amount{display:block;color:var(--red);font-size:11.5px;font-weight:700;}
.withdrawal-amount{display:block;color:var(--green);font-size:11.5px;font-weight:700;}
.app-actions{display:flex;flex-direction:column;align-items:center;gap:4px;flex-shrink:0;margin-left:6px;}
.dl-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;font-size:13px;font-weight:800;font-family:'Nunito',sans-serif;color:#fff;background:var(--grad);border:none;border-radius:50px;cursor:pointer;white-space:nowrap;box-shadow:0 4px 12px rgba(227,35,44,.38);touch-action:manipulation;}
.corner-tag{position:absolute;top:-9px;right:-8px;z-index:13;pointer-events:none;white-space:nowrap;font-family:'Nunito',sans-serif;font-size:9px;font-weight:900;letter-spacing:.6px;text-transform:uppercase;color:#fff;line-height:1;padding:3px 7px 4px;border-radius:6px 6px 6px 2px;min-width:38px;text-align:center;}

/* ─── COUNTDOWN ──────────────────────────────────────────────── */
.countdown-container{text-align:center;margin:10px 0 6px;font-weight:700;}
.countdown{background:#fff5f5;color:var(--text);padding:8px 14px;border-radius:12px;font-size:.95rem;display:inline-block;min-width:200px;border:1px solid var(--border);}
.countdown.expired{background:var(--grad);color:#fff;}

/* ─── COPY TOAST ─────────────────────────────────────────────── */
.copy-toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(16px);background:var(--red);color:#fff;font-weight:700;padding:10px 22px;border-radius:999px;font-size:13px;z-index:99999;opacity:0;transition:opacity .28s,transform .28s;pointer-events:none;white-space:nowrap;}
.copy-toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

/* ─── DISCLAIMER ─────────────────────────────────────────────── */
.disclaimer{background:#fff5f5;border:1.5px solid rgba(227,35,44,.35);padding:12px;margin:10px;color:var(--text);border-radius:10px;font-size:14px;line-height:1.6;}
.disclaimer-title{text-align:center;font-weight:700;font-size:15px;color:var(--text);text-decoration:underline;margin-bottom:6px;}

/* ─── HP META BLOCK ──────────────────────────────────────────── */
.hp-meta-block{margin:0 10px 14px;border:2px solid var(--border);border-left:5px solid var(--red);border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 3px 16px rgba(227,35,44,.08);}
.hp-meta-header{display:flex;align-items:flex-start;gap:10px;padding:13px 15px 11px;background:linear-gradient(100deg,#fff5f5,#fff);border-bottom:1.5px solid rgba(227,35,44,.12);}
.hp-meta-icon{width:32px;height:32px;border-radius:9px;background:var(--grad);display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;box-shadow:0 2px 8px rgba(227,35,44,.28);}
.hp-meta-icon i{color:#fff;font-size:.75rem;}
.hp-meta-h1{font-size:.88rem;font-weight:900;color:var(--text);line-height:1.4;margin:0;}
.hp-meta-desc{display:inline-flex;align-items:center;gap:5px;margin-top:5px;font-size:.7rem;font-weight:700;color:var(--text2);background:rgba(227,35,44,.06);border:1px solid rgba(227,35,44,.14);border-radius:6px;padding:3px 9px;}
.hp-meta-desc i{color:var(--red);font-size:.65rem;}
.hp-meta-body{padding:13px 15px;}
.hp-meta-text{font-size:.76rem;color:#555;line-height:1.85;margin:0;background:#fafafa;border:1px solid rgba(227,35,44,.08);border-radius:10px;padding:12px 14px;}

/* ─── BOTTOM INFO BLOCKS ─────────────────────────────────────── */
.bi-block{margin:0 10px 14px;border:1.5px solid rgba(227,35,44,.2);border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 2px 12px rgba(227,35,44,.07);}
.bi-header{display:flex;align-items:center;gap:10px;padding:11px 15px;background:linear-gradient(100deg,#fff5f5,#fff);border-bottom:1.5px solid rgba(227,35,44,.12);}
.bi-icon{width:30px;height:30px;border-radius:8px;background:var(--grad);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.bi-icon i{color:#fff;font-size:.75rem;}
.bi-h2{font-size:.83rem;font-weight:900;color:var(--text);margin:0;line-height:1.4;}
.bi-body{padding:12px 15px;}
.bi-text{font-size:.75rem;color:#555;line-height:1.8;margin:0;background:#fafafa;border:1px solid rgba(227,35,44,.08);border-radius:9px;padding:11px 13px;}

/* ─── TAGS BELT ──────────────────────────────────────────────── */
.tags-section{border-top:2px dashed var(--red);border-bottom:2px dashed var(--red);background:#fff0f0;display:flex;align-items:stretch;overflow:hidden;}
.tags-label{flex-shrink:0;background:var(--grad);color:#fff;font-size:10px;font-weight:900;letter-spacing:.8px;text-transform:uppercase;padding:10px 14px;display:flex;align-items:center;gap:5px;white-space:nowrap;border-right:2px solid rgba(255,255,255,.3);z-index:2;}
.tags-track{flex:1;min-width:0;overflow:hidden;position:relative;}
.tags-track::before,.tags-track::after{content:'';position:absolute;top:0;bottom:0;width:30px;z-index:1;pointer-events:none;}
.tags-track::before{left:0;background:linear-gradient(to right,#fff0f0,transparent);}
.tags-track::after{right:0;background:linear-gradient(to left,#fff0f0,transparent);}
.tags-belt{display:inline-flex;align-items:center;gap:10px;padding:8px 16px;white-space:nowrap;animation:beltScroll 28s linear infinite;will-change:transform;}
.tags-belt:hover{animation-play-state:paused;}
@keyframes beltScroll{0%{transform:translateX(0);}100%{transform:translateX(var(--belt-half,-50%));}}
.tag-pill{display:inline-flex;align-items:center;gap:5px;background:#fff;border:1.5px solid rgba(227,35,44,.25);border-radius:999px;padding:5px 14px;font-size:12px;font-weight:700;color:var(--red);white-space:nowrap;flex-shrink:0;user-select:none;box-shadow:0 1px 4px rgba(227,35,44,.08);}
.tag-pill i{font-size:9px;opacity:.55;}

/* ─── FOOTER / SOCIAL LINKS ──────────────────────────────────── */
.main-bg{background:linear-gradient(to top,#fff5f5,#fff);color:var(--text);border-top:3px solid var(--red);}
.center-text,.small-center-text{text-align:center;line-height:1.5;}
.center-text{font-size:1rem;font-weight:700;padding:8px;}.small-center-text{font-size:.7rem;font-weight:700;padding:8px;}
.link-style,.footer-link{color:var(--red);text-decoration:underline;}
.group-card,.group-card1{margin-bottom:20px;position:relative;align-items:center;padding:8px;overflow:hidden;border-radius:5px;}
.group-card{border:2px solid transparent;background:#fff0f0;display:flex;justify-content:space-between;align-items:center;}
.group-card1{border:2px solid transparent;background:#fff5f5;display:flex;justify-content:space-between;align-items:center;}
.join-text{margin-left:10px;font-weight:700;color:#b71c1c;font-size:.9rem;}
.join-text1{margin-left:10px;font-weight:700;color:#c0392b;font-size:1rem;}
.icon-tg{font-size:24px;color:#b71c1c;}.icon-tg1{font-size:24px;color:#c0392b;}
.join-btn{display:inline-flex;align-items:center;justify-content:center;font-weight:bold;font-size:1rem;text-decoration:none;padding:10px 20px;border-radius:5px;flex-shrink:0;color:#fff;cursor:pointer;border:none;font-family:'Nunito',sans-serif;touch-action:manipulation;}
.telegram-card .join-btn{background:#b71c1c;}
.telegram-card1 .join-btn{background:#c0392b;}
@keyframes tba{0%,100%{border-color:transparent}50%{border-color:#b71c1c}}
.telegram-card{animation:tba 1s infinite;}
@keyframes tba1{0%,100%{border-color:transparent}50%{border-color:#c0392b}}
.telegram-card1{animation:tba1 1s infinite;}
/* Side fixed buttons */
.side-tg,.side-wa{position:fixed;top:0;bottom:0;margin:auto;width:6.5rem;height:3rem;z-index:999;pointer-events:auto;}
.side-tg{right:-9.5%;margin-bottom:17rem;margin-top:17rem;}
.side-wa{right:-8.8%;margin-bottom:14.7rem;margin-top:14.7rem;}
.side-tg img{width:63%;}.side-wa img{width:68%;}

/* ─── SKELETON ───────────────────────────────────────────────── */
@keyframes shimmer{0%{background-position:-600px 0}100%{background-position:600px 0}}
.sk-item{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--border);border-radius:14px;margin-bottom:8px;padding:10px 12px;}
.sk-shine{background:linear-gradient(90deg,#fff5f5 0%,rgba(227,35,44,.06) 40%,#fff5f5 80%);background-size:600px 100%;animation:shimmer 1.6s infinite linear;border-radius:8px;}
.sk-icon{width:66px;height:66px;border-radius:14px;flex-shrink:0;}
.sk-lines{flex:1;display:flex;flex-direction:column;gap:8px;}
.sk-line{height:13px;}.sk-line.w80{width:80%;}.sk-line.w55{width:55%;}.sk-line.w40{width:40%;}
.sk-btn{width:82px;height:36px;border-radius:50px;flex-shrink:0;}

/* ─── RESPONSIVE FIXES ───────────────────────────────────────── */
@media(max-width:360px){
  .sp-num{font-size:11px;}
  .sp-label{font-size:8px;}
  .app-icon{width:56px;height:56px;}
  .dl-btn{padding:7px 10px;font-size:12px;}
  .header-text{font-size:17px;}
  .tab{font-size:11px;padding:8px 4px;}
}
@media(max-width:320px){
  .app-details{margin-left:6px;}
  .app-title{font-size:.85em;}
  .corner-tag{font-size:8px;padding:2px 5px 3px;}
}
@media(min-width:600px){
  .app-list{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px;}
  .app-item{margin-bottom:0;}
}
@media(min-width:960px){
  .app-list{grid-template-columns:1fr 1fr 1fr;}
}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
</style>
</head>
<body>
<noscript><iframe src="https://www.googletagmanager.com/ns.php?id=GTM-57BVT9NQ" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<!-- HEADER -->
<header class="header">
  <a href="index.php" aria-label="IndYonoGames Home"><img class="logo-top" src="logo.jpg" alt="Yono Apps Logo" width="35" height="35"></a>
  <a href="index.php" aria-label="IndYonoGames"><div class="header-text">IndYonoGames</div></a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer" aria-label="Join Telegram"><img class="telegram-top" src="telegram-join-button.png" alt="Join Telegram" width="54" height="32" loading="lazy"></a>
  <div class="menu-icon" onclick="toggleMenu()" role="button" tabindex="0" aria-label="Open menu" aria-expanded="false" id="menuBtn">&#9776; Menu</div>
</header>

<!-- MENU -->
<nav class="menu-container" id="menuContainer" aria-label="Site navigation">
  <div class="menu-row">
    <a href="index.php" class="menu-item"><i class="fa-solid fa-house" aria-hidden="true"></i> Home</a>
    <a href="about-us.php" class="menu-item"><i class="fa-solid fa-clipboard-user" aria-hidden="true"></i> About</a>
    <a href="contact-us.php" class="menu-item"><i class="fa-solid fa-envelope-circle-check" aria-hidden="true"></i> Contact</a>
  </div>
  <div class="menu-row">
    <a href="privacy-policy.php" class="menu-item"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Privacy Policy</a>
    <a href="terms-and-conditions.php" class="menu-item"><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Terms &amp; Conditions</a>
    <a href="disclaimer.php" class="menu-item"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Disclaimer</a>
  </div>
</nav>

<!-- NAVBAR -->
<nav class="navbar" aria-label="Quick navigation">
  <a href="index.php" class="active"><i class="fa-solid fa-house" aria-hidden="true"></i> Home</a>
  <a href="about-us.php"><i class="fa-solid fa-address-book" aria-hidden="true"></i> About</a>
  <a href="contact-us.php"><i class="fa-solid fa-envelope" aria-hidden="true"></i> Contact Us</a>
  <a href="disclaimer.php"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Disclaimer</a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-telegram" aria-hidden="true"></i> Join Telegram</a>
</nav>

<!-- BANNER -->
<img src="banner.jpg" alt="Yono Apps — Download Rummy &amp; Gaming Apps with Big Bonuses" class="banner-img" width="800" height="200" loading="eager" fetchpriority="high"/>

<!-- SOCIAL PROOF -->
<div class="social-proof-bar" role="region" aria-label="Site statistics">
  <div class="sp-item"><i class="fa-solid fa-users sp-icon green" aria-hidden="true"></i><div class="sp-text"><div class="sp-num">10,000+</div><div class="sp-label">Happy Users</div></div></div>
  <div class="sp-item"><i class="fa-solid fa-indian-rupee-sign sp-icon gold" aria-hidden="true"></i><div class="sp-text"><div class="sp-num">&#8377;50 Lakh+</div><div class="sp-label">Bonuses Claimed</div></div></div>
  <div class="sp-item"><i class="fa-solid fa-shield-halved sp-icon blue" aria-hidden="true"></i><div class="sp-text"><div class="sp-num">100% Safe</div><div class="sp-label">Verified Apps</div></div></div>
</div>

<!-- COPY TOAST -->
<div class="copy-toast" id="copyToast" role="alert" aria-live="assertive">&#10003; Copied!</div>

<!-- FOMO TOAST -->
<div class="fomo-toast" id="fomoToast" aria-live="polite" aria-atomic="true">
  <div class="fomo-avatar" id="fomoAvatar" aria-hidden="true">&#127918;</div>
  <div class="fomo-body">
    <div class="fomo-name" id="fomoName">Rahul from Delhi</div>
    <div class="fomo-action" id="fomoAction">just downloaded an app</div>
    <div class="fomo-time" id="fomoTime">Just now</div>
  </div>
  <div class="fomo-dot" aria-hidden="true"></div>
</div>

<!-- TABS + SEARCH + APP LISTS -->
<main>
<div class="tabs-wrap" id="tabsWrap">
  <div class="tabs" role="tablist" aria-label="App categories">
    <button id="allTab" class="tab active" onclick="showTab('all')" role="tab" aria-selected="true" aria-controls="all">All Apps</button>
    <button id="newTab" class="tab" onclick="showTab('new')" role="tab" aria-selected="false" aria-controls="new">New Apps</button>
    <button id="upcomingTab" class="tab" onclick="showTab('upcoming')" role="tab" aria-selected="false" aria-controls="upcoming">Upcoming</button>
  </div>

  <div class="search-wrap">
    <div class="search-inner">
      <label for="searchInput" class="sr-only">Search apps</label>
      <input type="search" id="searchInput" placeholder="Search Yono, Rummy, Joy, 51 Bonus..." autocomplete="off" spellcheck="false">
      <i class="fas fa-search search-icon" aria-hidden="true"></i>
    </div>
  </div>

  <!-- SKELETON LOADER -->
  <div id="skelOverlay" style="padding:6px;" aria-hidden="true">
    <?php for($s=0;$s<6;$s++): ?>
    <div class="sk-item"><div class="sk-icon sk-shine"></div><div class="sk-lines"><div class="sk-line sk-shine w80"></div><div class="sk-line sk-shine w55"></div><div class="sk-line sk-shine w40"></div></div><div class="sk-btn sk-shine"></div></div>
    <?php endfor; ?>
  </div>

  <div id="all" class="tab-content active" role="tabpanel" aria-labelledby="allTab" style="visibility:hidden;">
    <ul class="app-list"><?php echo $result2; ?></ul>
  </div>
  <div id="new" class="tab-content" role="tabpanel" aria-labelledby="newTab">
    <ul class="app-list"><?php echo $new1.$new2.$new3.$new4.$new5; ?></ul>
  </div>
  <div id="upcoming" class="tab-content" role="tabpanel" aria-labelledby="upcomingTab">
    <ul class="app-list"><?php echo $upcomingAppsHtml; ?></ul>
  </div>
</div>

<!-- HP META BLOCK -->
<div class="hp-meta-block">
  <div class="hp-meta-header">
    <div class="hp-meta-icon"><i class="fa-solid fa-magnifying-glass-chart" aria-hidden="true"></i></div>
    <div>
      <h1 class="hp-meta-h1"><?php echo htmlspecialchars($hp_content_title); ?></h1>
      <div class="hp-meta-desc">
        <i class="fa-solid fa-circle-info" aria-hidden="true"></i>
        <?php echo htmlspecialchars($hp_meta_desc); ?>
      </div>
    </div>
  </div>
  <div class="hp-meta-body">
    <p class="hp-meta-text"><?php echo nl2br(htmlspecialchars($hp_content_body)); ?></p>
  </div>
</div>

<!-- DISCLAIMER -->
<div class="disclaimer" role="note">
  <div class="disclaimer-title"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Important Notice</div>
  <p><b>indyonogames.com</b> does not run or operate the apps listed here. Rummy apps can be addictive and financially risky. Only for <b>18+</b>.</p>
  <p>Please read our <b><a href="disclaimer.php">Disclaimer page</a></b> and the specific disclaimer for each app.</p>
  <p><b>Alert:</b> Rummy is banned in <b>Andhra Pradesh, Sikkim, Nagaland, Assam, Arunachal Pradesh, Tamil Nadu, Odisha, and Telangana</b>.</p>
</div>

<!-- TAGS BELT -->
<div class="tags-section" aria-label="Related tags">
  <div class="tags-label"><i class="fa-solid fa-tags" aria-hidden="true"></i><?php echo $index_tags_label; ?></div>
  <div class="tags-track">
    <div class="tags-belt" id="tagsBelt" aria-hidden="true"><?php echo $tags_pills_html; ?></div>
  </div>
</div>

<!-- BOTTOM INFO BLOCKS -->
<div class="bi-block">
  <div class="bi-header"><div class="bi-icon"><i class="fa-solid fa-crown" aria-hidden="true"></i></div><h2 class="bi-h2">Yono Rummy APK &mdash; IndYonoGames</h2></div>
  <div class="bi-body"><p class="bi-text"><strong>Yono Rummy</strong> is India's most popular Rummy APK. Download and get a bonus every day — new players enjoy a special &#8377;68 sign-up bonus. Join with top Rummy APK and take advantage of limited-time bonus offers available for all users. Smooth gameplay, fast withdrawals, and 24/7 support make Yono Rummy the No.1 choice for rummy lovers across India.</p></div>
</div>
<div class="bi-block">
  <div class="bi-header"><div class="bi-icon"><i class="fa-solid fa-gem" aria-hidden="true"></i></div><h2 class="bi-h2">Yono VIP APK &mdash; IndYonoGames</h2></div>
  <div class="bi-body"><p class="bi-text"><strong>Yono VIP</strong> is the best earning APK — download today and enjoy bonuses available 24 hours a day, 7 days a week. Play Slots, Poker, Rummy, and Skill Games exclusively on Yono VIP. It is the best APK for players who want premium gaming with higher rewards and lightning-fast payouts.</p></div>
</div>
<div class="bi-block">
  <div class="bi-header"><div class="bi-icon"><i class="fa-solid fa-gamepad" aria-hidden="true"></i></div><h2 class="bi-h2">Yono Games APK &mdash; IndYonoGames</h2></div>
  <div class="bi-body"><p class="bi-text"><strong>Yono Games</strong> APK download is free — India's No.1 Games Top APK. Play Slots Machine games for a smooth gaming experience with fast withdrawals. Join Yono Games and get a &#8377;89 bonus instantly. Enjoy a wide range of exciting games and earn real money every day on the go.</p></div>
</div>
<div class="bi-block">
  <div class="bi-header"><div class="bi-icon"><i class="fa-solid fa-list-check" aria-hidden="true"></i></div><h2 class="bi-h2">IndYonoGames List 2026 &mdash; Latest Yono Games, Slots, Bingo, Rummy &amp; More</h2></div>
  <div class="bi-body"><p class="bi-text"><strong>IndYonoGames 2026</strong> — World No.1 APK download today. Show your gaming power and make money daily with free promo codes. Download All Yono Rummy App and get &#8377;500 to &#8377;1500 Sign Up Bonus with minimum withdrawal in &#8377;100 on each Yono App. Includes: <strong>Yono Rummy | Rummy Ludo | Rummy77 | Hindi 777 | ABC Rummy | Yono VIP | OK Rummy | Yes Spin | India Slots | Yono 777 | Yono Games | 91 Club | Rumble Rummy | Ind Slots | INR Rummy | Joy Rummy | Rummy 888</strong> and all Yono Games. Download &amp; get sign-up bonus &#8377;551&#8211;789 free in 2026 — complete Yono Rummy list on IndYonoGames.</p></div>
</div>

<!-- SIDE BUTTONS -->
<div class="side-tg"><a href="<?php echo $tg_url; ?>" rel="nofollow noopener noreferrer" target="_blank" aria-label="Join Telegram"><img src="telegram-join-button.png" alt="Telegram" width="42" loading="lazy"/></a></div>
<div class="side-wa"><a href="<?php echo $wa_url; ?>" rel="nofollow noopener noreferrer" target="_blank" aria-label="Join WhatsApp"><img src="whatsapp-channnel.webp" alt="WhatsApp" width="46" loading="lazy"/></a></div>
</main>

<!-- FOOTER -->
<footer>
  <div class="group-card telegram-card" style="margin:10px;">
    <span style="display:flex;align-items:center;"><i class="fab fa-telegram icon-tg" aria-hidden="true"></i><span class="join-text">Join Our Telegram Channel</span></span>
    <a class="join-btn" href="<?php echo $tg_url; ?>" rel="nofollow noopener noreferrer" target="_blank" aria-label="Join Telegram"><i class="fab fa-telegram" aria-hidden="true"></i> Join Now</a>
  </div>
  <div class="main-bg" style="padding:10px 10px 0;">
    <div class="group-card1 telegram-card1">
      <span style="display:flex;align-items:center;"><span onclick="shareContent()" class="join-text1" style="cursor:pointer;"><i class="fa-solid fa-square-share-nodes" aria-hidden="true"></i> Share With Friends!</span></span>
      <button class="join-btn" onclick="shareContent()" style="background:#c0392b;" aria-label="Share this site"><i class="fa-solid fa-share-from-square" aria-hidden="true"></i> Click Here To Share</button>
    </div>
    <div class="center-text">
      <a class="link-style" href="about-us.php">About Us</a> &nbsp;&nbsp;
      <a class="link-style" href="disclaimer.php">Disclaimer</a> &nbsp;&nbsp;
      <a class="link-style" href="contact-us.php">Contact Us</a><br>
      <a class="link-style" href="privacy-policy.php">Privacy Policy</a> &nbsp;&nbsp;
      <a class="link-style" href="terms-and-conditions.php">Terms &amp; Conditions</a>
    </div>
    <div class="small-center-text">
      <strong>Join Our Telegram:</strong><br>
      <a class="footer-link" href="<?php echo $tg_url; ?>" target="_blank" rel="noopener noreferrer">Click Here</a><br><br>
      Copyright &copy; 2024 <a href="index.php" style="color:var(--red);"><strong>indyonogames.com</strong></a> All Rights Reserved
    </div>
  </div>
</footer>

<script>
/* ─── TAGS BELT ────────────────────────────────────────────────── */
(function(){
  var belt=document.getElementById('tagsBelt');
  if(!belt||belt.children.length===0)return;
  belt.innerHTML=belt.innerHTML+belt.innerHTML;
  function init(){var half=belt.scrollWidth/2;if(!half){setTimeout(init,120);return;}belt.style.setProperty('--belt-half','-'+half+'px');belt.style.animationDuration=(half/80).toFixed(2)+'s';}
  document.readyState==='complete'?init():window.addEventListener('load',init,{passive:true});
  window.addEventListener('resize',function(){var half=belt.scrollWidth/2;if(!half)return;belt.style.setProperty('--belt-half','-'+half+'px');belt.style.animationDuration=(half/80).toFixed(2)+'s';},{passive:true});
})();

/* ─── CORE ─────────────────────────────────────────────────────── */
function toggleMenu(){
  var x=document.getElementById('menuContainer'),btn=document.getElementById('menuBtn');
  var open=x.style.display==='block';
  x.style.display=open?'none':'block';
  btn.setAttribute('aria-expanded',String(!open));
}
function shareContent(){
  var m=document.querySelector('meta[name=description]');
  var t=document.title+'\n\nindyonogames.com'+(m?' - '+m.getAttribute('content'):'')+'\n';
  if(navigator.share){navigator.share({title:document.title,text:t,url:window.location.href}).catch(function(){});}
  else{if(navigator.clipboard){navigator.clipboard.writeText(window.location.href).then(showCopyToast);}else alert('Share: '+window.location.href);}
}
function showTab(id){
  document.querySelectorAll('.tab').forEach(function(t){var on=t.id===id+'Tab';t.classList.toggle('active',on);t.setAttribute('aria-selected',String(on));});
  document.querySelectorAll('.tab-content').forEach(function(c){c.classList.toggle('active',c.id===id);});
}

/* ─── FOMO ─────────────────────────────────────────────────────── */
(function(){
  var names=['Rahul','Priya','Amit','Sneha','Vikram','Pooja','Suresh','Anjali','Deepak','Kavita'];
  var cities=['Delhi','Mumbai','Pune','Kolkata','Chennai','Hyderabad','Bangalore','Jaipur','Lucknow','Surat'];
  var actions=['just downloaded','just signed up for','just claimed \u20B951 bonus on','just got welcome bonus on'];
  var emojis=['\u{1F3AE}','\u{1F3AF}','\u{1F4B0}','\u{1F3B3}','\u{1F3B2}','\u2B50'];
  var toast=document.getElementById('fomoToast');if(!toast)return;
  function getApps(){var a=[];document.querySelectorAll('.app-title').forEach(function(e){var t=e.textContent.trim();if(t)a.push(t);});return a.filter(function(v,i,arr){return arr.indexOf(v)===i;});}
  function show(){var apps=getApps();if(!apps.length){setTimeout(show,2000);return;}
    var n=names[Math.floor(Math.random()*names.length)];var c=cities[Math.floor(Math.random()*cities.length)];
    var a=apps[Math.floor(Math.random()*apps.length)];var ac=actions[Math.floor(Math.random()*actions.length)];var e=emojis[Math.floor(Math.random()*emojis.length)];
    document.getElementById('fomoAvatar').textContent=e;document.getElementById('fomoName').textContent=n+' from '+c;
    document.getElementById('fomoAction').textContent=ac+' '+a;document.getElementById('fomoTime').textContent='Just now';
    toast.classList.add('show');setTimeout(function(){toast.classList.remove('show');},4000);setTimeout(show,Math.floor(Math.random()*12000)+8000);}
  setTimeout(show,6000);
})();

/* ─── DOM READY ────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded',function(){
  document.getElementById('searchInput').addEventListener('input',function(){
    var f=this.value.toLowerCase().trim();
    var panel=document.querySelector('.tab-content.active');if(!panel)return;
    panel.querySelectorAll('.app-item').forEach(function(item){item.style.display=item.textContent.toLowerCase().includes(f)?'':'none';});
  });
});

/* ─── COUNTDOWN ────────────────────────────────────────────────── */
(function(){
  var els=document.querySelectorAll('.countdown-container[data-launch]');if(!els.length)return;
  function pad(n){return n<10?'0'+n:n;}var last=0;
  function tick(ts){if(ts-last>=1000){last=ts;els.forEach(function(c){var left=new Date(c.getAttribute('data-launch')).getTime()-Date.now();var el=c.querySelector('.countdown');if(!el)return;if(left<=0){el.textContent='Now Available!';el.classList.add('expired');return;}var d=Math.floor(left/86400000),h=Math.floor((left%86400000)/3600000),m=Math.floor((left%3600000)/60000),s=Math.floor((left%60000)/1000);el.textContent=d+'d '+pad(h)+':'+pad(m)+':'+pad(s);});}requestAnimationFrame(tick);}
  requestAnimationFrame(tick);
})();

/* ─── SKELETON ─────────────────────────────────────────────────── */
(function(){
  var ov=document.getElementById('skelOverlay'),al=document.getElementById('all');if(!ov||!al)return;
  function hide(){ov.style.display='none';al.style.visibility='';}
  document.readyState==='complete'?setTimeout(hide,200):window.addEventListener('load',function(){setTimeout(hide,200);},{passive:true});
})();

/* ─── COPY TOAST ───────────────────────────────────────────────── */
function showCopyToast(){var t=document.getElementById('copyToast');t.classList.add('show');setTimeout(function(){t.classList.remove('show');},2200);}
</script>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-021DH2WQ0N"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-021DH2WQ0N');
    </script>
</body>
</html>
