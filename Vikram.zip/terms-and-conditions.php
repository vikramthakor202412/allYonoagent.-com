<?php
$nid=$_GET["!"];

$json = file_get_contents("alldetails/$nid.json");
     $json = json_decode($json, true);
        $name= htmlspecialchars($json['name']);  
 $imglink= htmlspecialchars($json['imglink']);  
        $mwith= htmlspecialchars($json['mwith']);  
        $tdown= htmlspecialchars($json['tdown']);  
        $signbo= htmlspecialchars($json['signbo']);   $bonus=$signbo;
        
        $applink= htmlspecialchars($json['applink']); 
        $bigimglink= htmlspecialchars($json['bigimglink']);  
        $chanidv= htmlspecialchars($json['chanidv']); 
        $gameidff= htmlspecialchars($json['gameidff']);  
$madd= htmlspecialchars($json['madd']);  
  $refperapro= htmlspecialchars($json['refperapro']); 
$refcoms= htmlspecialchars($json['refcoms']);  


 $rgegg="alldetails/wmaupchanl.json";  
   $wch=file_get_contents($rgegg);
                          
                          $rgeggrge="alldetails/maupchanl.json";  
                          $mch=file_get_contents($rgeggrge);
                          
                          $rgeggrgergg="alldetails/upchanl.json";  
                          $uch=file_get_contents($rgeggrgergg);
                          
                          $rgeggrgergggr="alldetails/chanl.json";  
                          $rch=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/1websitelink.json";  
                          $weblink=file_get_contents($rgeggrgergggr); 
                          
                          
                          $rgeggrgergggr="alldetails/email.json";  
                          $email=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/telegramcon.json";  
                          $telegram=file_get_contents($rgeggrgergggr); 
?>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title> Terms & Conditions- All Yono Store</title>
	<link rel="canonical" href="contact-us.php" />
<meta name="description" content="Contact Us - Yono Apps (Read Carefully)" /><meta content='Contact Us - Yono Apps' name='keywords'/><meta content='Contact Us - Yono Apps' name='title'/>      <meta property="og:image" content="admin/images/1000417226.jpg"/><meta property="og:url" content="contact-us.php"/><meta property="og:title" content="Contact Us - Yono Apps "/><meta property="og:description" content="Contact Us - Yono Apps"/><meta name="og:site_name" content="Yono Apps"/><meta property="og:type" content="website" /><meta property="og:locale" content="en_IN" /><link rel="apple-touch-icon" sizes="180x180" href="i/apple-touch-icon.php"><link rel="apple-touch-icon" sizes="57x57" href="i/apple-icon-57x57.php"><link rel="apple-touch-icon" sizes="60x60" href="i/apple-icon-60x60.php"><link rel="apple-touch-icon" sizes="72x72" href="i/apple-icon-72x72.php"><link rel="apple-touch-icon" sizes="76x76" href="i/apple-icon-76x76.php"><link rel="apple-touch-icon" sizes="114x114" href="i/apple-icon-114x114.php"><link rel="apple-touch-icon" sizes="120x120" href="i/apple-icon-120x120.php"><link rel="apple-touch-icon" sizes="144x144" href="i/apple-icon-144x144.php"><link rel="apple-touch-icon" sizes="152x152" href="i/apple-icon-152x152.php"><link rel="apple-touch-icon" sizes="180x180" href="i/apple-icon-180x180.php"><link rel="icon" type="image/png" sizes="192x192"  href="i/android-icon-192x192.php"><link rel="icon" type="image/png" sizes="32x32" href="i/favicon-32x32.php"><link rel="icon" type="image/png" sizes="96x96" href="i/favicon-96x96.php"><link rel="icon" type="image/png" sizes="16x16" href="i/favicon-16x16.php"><link rel="manifest" href="i/manifest.json"><meta name="msapplication-TileColor" content="#ffffff"><meta name="msapplication-TileImage" content="i/ms-icon-144x144.php">    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />  <meta name="robots" content="index, follow"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script>

    function toggleMenu() {
  var x = document.getElementById("menuContainer");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
function shareContent() {
  // Extract the domain name from the URL
  var domain = window.location.hostname;
  // Attempt to get the meta description content
  var metaElement = document.querySelector("meta[name=description]");
  var metaDescription = metaElement ? metaElement.getAttribute("content") : '';
  // Create the share text in the format "Title\n(domain) - (description)"
  var shareText = document.title + "\n\n" + "AllYonoAppsT.com" + (metaDescription ? " - " + metaDescription : '') + "\n" + "» ";
  // Check if the Web Share API is supported
  if (navigator.share) {
    navigator.share({
      title: document.title,
      text: shareText,
      url: window.location.href
    }).then(() => {
      console.log('Thanks for sharing!');
    })
    .catch(console.error);
  } else {
    // Fallback for browsers that do not support navigator.share
    alert('Web Share API is not supported in your browser.');
  }
}
function closeStickyAd() {
  document.getElementById('stickyAd').style.display = 'none';
}
function showTab(selectedTab) {
  var tabs = document.querySelectorAll(".tabs .tab");
  var contents = document.querySelectorAll(".content");
  tabs.forEach(function(tab) {
    if (tab.id === selectedTab + "Tab") {
      tab.classList.add("active");
    } else {
      tab.classList.remove("active");
    }
  });
  contents.forEach(function(content) {
    if (content.id === selectedTab) {
      content.classList.add("active");
    } else {
      content.classList.remove("active");
    }
  });
}
document.addEventListener('DOMContentLoaded', function() {
  const questions = document.querySelectorAll('.question8262');
  questions.forEach((question, index) => {
    question.addEventListener('click', () => {
      const answer = question.nextElementSibling;
      answer.classList.toggle('show');
    });
  });
});
</script> <style>

.navbar a{
font-size: 12px !important;
}
</style><style>@import url(ajax/libs/font-awesome/6.5.1/css/all.min.css);.ul,li{font-size:15px}*,body{margin:0}.footer-link,.link-style{text-decoration-line:underline}.center .downBtn,.center-text,.hed,.menu-container,.navbar a,.popup-content,.small-center-text{text-align:center}*,.footbtn,.hed1,.menu-item{box-sizing:border-box}.close-button,.header-text,.navbar a,a{text-decoration:none}.app-info,.bodylook,.navbar a,.red-disclaimer-box,body{font-family:Arial,sans-serif}.close-btn,.custom-image,.icon,.popup-trigger,.tabs .tab{cursor:pointer}#customers,#iTable{border-collapse:collapse}*{padding:0;list-style:none}.container{width:90%;max-width:1200px;margin:0 auto;padding:20px}@media only screen and (max-width:768px){.container{padding:10px}}@media only screen and (max-width:480px){.container{padding:5px}}h3,h4,p{padding:9px}li{padding-left:18px;paddin-right:18px;padding-top:3px;padding-bottom:3px}ul{padding:18px}ol{padding-left:11px;paddin-right:11px}h2{padding:7px;text-align:left;border-bottom:2px solid #dedede;border-left:6px solid #00f;font-size:24px;color:red;padding-block:10px;margin-top:0}table,td,th{border:1px solid;padding:3px}.allrummystore_img{border:1px solid #ddd;border-radius:4px;padding:5px;width:90%;display:block;margin:10px auto}.ul{padding:6% 5%}.note{color:#c9c3b5;padding:0;font-size:.24rem}.bodylook{background-color:#fff;border:5px solid #000;padding:2%}.hed,h2.relatedapps{background:radial-gradient(circle at 10% 20%,#005d85 0,#00b595 90%)}.footbtn a img,.top img{width:100%;display:block}.center .downBtn{width:125%;padding-top:0;margin:120% 24% 37% -12%}.center .downBtn img{width:70%;display:block;text-align:center;margin:0 auto;animation:1.8s infinite moves}.footbtn a,.kf img,.swiper-container .swiper-slide,.swiper-container .swiper-slide img,.top1 img,.top2 img,.top3 img{width:100%}.swiper-container{width:100%;margin:0 auto;overflow:hidden}a{-webkit-tap-highlight-color:transparent}.top1 img{margin-top:3%}.word{width:94%;margin:0 auto}.word p{font-size:.7rem;color:#ddcda6}.footbtn{width:750px;position:fixed;bottom:0;left:0;right:0;margin:auto;display:flex;justify-content:space-between;align-items:center;padding:0;z-index:99}.kf,.tg{z-index:999;position:fixed;top:0;bottom:0}.custom-image{border-radius:3px;border:2px solid #73ad21;margin:0 auto;display:block;width:100%}.kf{right:0;margin:5rem auto;width:3rem;height:3rem}.download-btn-img{margin:0 auto;display:block;width:261px;height:62.0055px}.tg{right:-3%;margin:9rem auto;width:6.5rem;height:3rem}.tg img{width:75%}.hed{border-radius:10px;font-size:17px;padding:5px 25px;color:#fff;border:3px solid #000}.hed1{border-style:double solid;height:auto;width:100%;margin:auto;color:purple;padding:5px;font-size:20px;display:inline-block;background-color:#fbeeff;border-width:5px}#customers tr:nth-child(2n),.popup-trigger{background-color:#f2f2f2}#customers{font-family:Arial,Helvetica,sans-serif;width:100%}#customers td,#customers th{border:1px solid #ddd;padding:8px}#customers tr:hover{background-color:#ddd}#customers th{padding-top:12px;padding-bottom:12px;text-align:left;background-color:#04aa6d;color:#fff}.telegram-image{margin:0 auto;display:block;width:268px;height:51.4802px}.popup,.popup-overlay{width:100%;height:100%}.text-shadow{text-shadow:-3px 2px 20px rgba(0,255,0,.45)}.color-text{color:#41a85f}.q-heading{color:purple;font-size:1.2rem;margin-top:1rem;margin-bottom:.5rem}.popup-trigger{display:inline-block;margin:10px;padding:5px;border:1px solid #000}.popup{display:none;position:fixed;top:0;left:0}.answer8262.show,.close-button,.content.active,.navbar a,.popup:target{display:block}.popup-overlay{position:absolute;background:rgba(0,0,0,.7)}.popup-content{position:relative;background:#fff;padding:20px;border-radius:8px;width:70%;max-width:600px;margin:10% auto}body{padding:0}.close-button{margin:20px auto;padding:10px 20px;background-color:red;color:#fff;border-radius:5px}.center-text{font-size:1rem;font-weight:700;line-height:1.5}.small-center-text{font-size:.7rem;font-weight:700;line-height:1.5}.menu-item,.navbar a{font-size:11px;font-weight:700}.link-style{color:#f3eccd}.main-background{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;border:2px solid #0b6115}.footer-link{color:#fff}.navbar{color:#fff;display:flex;justify-content:center;flex-wrap:nowrap}.navbar a{white-space:nowrap;float:left;color:#000;padding:5px;border-right:2px solid #e5e4e2}.menu-container{display:none;background:linear-gradient(to top,#d3d3d3 0,#d3d3d3 1%,#e0e0e0 26%,#efefef 48%,#d9d9d9 75%,#bcbcbc 100%);padding:20px}.menu-item{background:linear-gradient(109.6deg,#1b1b4f 11.2%,#78c9f4 100.2%);color:#fff;padding:7px 14px;margin:8px;display:inline-block;width:30%;border-radius:8px}.menu-row{display:flex;justify-content:space-around}.icon{display:block;text-align:right;padding:2px 6px;color:#fff;font-size:18px;font-weight:700}.header{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;display:flex;justify-content:space-between;align-items:center;padding:5px}#iTable th,.navbar,.tabs .tab{background-color:#f2f2f2}.logo-top{width:35px;height:auto}.telegram-top{width:54px;height:auto}.header-text{flex-grow:1;margin:0 2px;text-align:left;font-weight:700;font-size:25px;color:#fff!important}.navbar{border-top:1px solid #001e00;border-bottom:2px solid #001e00;overflow:hidden}.navbar a:last-child{border-right:none}.navbar a.active,.navbar a:hover{background:linear-gradient(114.3deg,#137e39 .2%,#08415b 68.5%);color:#fff}.app-list_dont_copy_created_by_allrummystore_com{list-style-type:none;counter-reset:app-counter;padding:0;position:relative;margin:0}.app-item_dont_copy_created_by_allrummystore_com{display:flex;align-items:center;background-color:#f9f9f9;border-radius:10px;margin-bottom:5px;padding:5px;counter-increment:section;box-shadow:0 3px 6px rgba(0,0,0,.1)}.app-item_dont_copy_created_by_allrummystore_com::before{counter-increment:app-counter;content:counter(app-counter) ".";font-weight:700;font-size:1em;margin-right:1px;color:#899499}.app-icon_dont_copy_created_by_allrummystore_com-container{padding:2px}.app-icon_dont_copy_created_by_allrummystore_com{width:65px;border-radius:5px}.install-button,.sticky-ad{width:100%;box-sizing:border-box}.app-details_dont_copy_created_by_allrummystore_com{flex-grow:1;margin-left:8px}.app-title_dont_copy_created_by_allrummystore_com{font-size:1.15em;margin:0 0 5px}.bonus-amount_dont_copy_created_by_allrummystore_com{color:red;font-size:12px;margin:0;font-weight:700}.mrnew{color:grey;font-weight:900;font-size:17px;margin:0}.download-count{color:#ffaa1d;font-weight:600;font-size:13px;margin:0}.withdrawal-amount_dont_copy_created_by_allrummystore_com{color:green;font-size:12px;font-weight:700;margin:0}.download-button_dont_copy_created_by_allrummystore_com{display:inline-block;padding:.63em .53em;margin:0 .1em .1em 0;background-image:radial-gradient(100% 100% at 100% 0,#5adaff 0,#5468ff 100%);border-radius:.33em;box-sizing:border-box;text-decoration:none;font-weight:700;box-shadow:rgba(45,35,66,.4) 0 2px 4px,rgba(45,35,66,.3) 0 7px 13px -3px,rgba(58,65,111,.5) 0 -3px 0 inset;box-sizing:border-box;font-size:14px;color:#fff;text-shadow:0 .04em .04em rgba(0,0,0,.35);text-align:center;transition:.2s}.centerio,.centerio1,h3.hindi-translate{text-decoration:underline}a.download-button_dont_copy_created_by_allrummystore_com:hover{border-color:#fff}h2.relatedapps{border-radius:10px;font-size:20px;text-align:center;padding:5px 25px;color:#fff;border:3px solid #000}h3.hindi-translate{border-radius:1px;font-size:20px;text-align:center;color:#00308f;padding:5px 25px;background:linear-gradient(to bottom,#f93,#fff 50%,#138808);border:3px solid #00308f}.sticky-ad{position:fixed;bottom:0;left:0;background:#f4f4f4;padding:2px}.ad-content{position:relative;max-width:1200px;margin:auto;display:flex;justify-content:center;align-items:center}.close-btn{position:absolute;right:-5px;top:-25px;background-color:red;color:#fff;border:none;font-size:10px;font-weight:700;padding:5px 10px;border-radius:5px}img{max-width:100%;height:auto}.red-disclaimer-box{background-color:#fff7f7;border:2px solid #ff5733;padding:10px;margin:10px;border-radius:4px;color:#000;font-size:11px;line-height:1.5}.centerio{text-align:center;font-weight:700;font-size:16px}.centerio1{font-weight:700;font-size:13px}.app-container,.app-container2{max-width:768px;margin:20px auto;background-color:#fff;padding:10px;box-shadow:0 0 10px rgba(0,0,0,.1)}.app-header,.app-header1{display:flex;align-items:center;padding:20px}.header-image{flex-basis:60%;text-align:left}.header9272 h1,.mr193,.tabs{text-align:center}.header-image img{width:80%;border-radius:25px}.header-content,.header-content12{flex-basis:40%}.age-rating,.rating-info{margin:12px 0}.age-rating span,.rating-info span,.text1{display:inline-block;margin-right:10px}.seoquake-nofollow i,.tabs .tab{margin-right:5px}.install-button{background-color:#00f;color:#fff;padding:10px 20px;border:none;cursor:pointer;font-weight:700;border-radius:20px;margin-top:10px}.app-info{display:flex;flex-direction:column;align-items:center}.rating-info{display:flex;align-items:center;font-size:18px}.download-block,.rating-block,.reviews-block{display:flex;flex-direction:column;align-items:center;margin:5px}.separator{color:#ccc;margin:0 10px}#iTable,.content,.tabs{margin:0 auto}.text1{font-size:15px}.tabs{display:flex;justify-content:center;font-weight:700;font-size:16px}.tabs .tab{flex:1;padding:8px;border:2px solid #ddd;color:#000}.tabs .tab:last-child{margin-right:0}.content{width:auto;display:none}.group-card,.group-card1{margin-bottom:20px;padding:7px;position:relative;overflow:hidden}.join-text,.join-text1{margin-left:10px;font-weight:700}.tabs .tab.active{background:linear-gradient(109.6deg,#3d79b0 11.3%,#2342a4 91.1%);color:#fff}.group-card{border:2px solid transparent;border-radius:5px;background:#f0f8ff;display:flex;align-items:center;justify-content:space-between}.group-card1{border:2px solid transparent;border-radius:5px;background:#f0fff0;display:flex;align-items:center;justify-content:space-between}.telegram-card,.telegram-card1{animation:1s infinite telegram-border-animation}@keyframes telegram-border-animation{0%,100%{border-color:transparent}50%{border-color:#004f7a}}.seoquake-nofollow{display:inline-flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700;text-decoration:none;padding:5px 20px;border-radius:2px;flex-shrink:0;transition:.3s ease-in-out;color:#fff!important}.telegram-card .seoquake-nofollow{background:#004f7a}.telegram-card1 .seoquake-nofollow{background:#2b7a40}.seoquake-nofollow:hover{transform:scale(1.05)}nofollow1{background:#006942}.icon-telegram{font-size:24px;color:#004f7a}.icon-telegram1{font-size:24px;color:#006942}.join-text{color:#004f7a;font-size:.9rem!important}.join-text1{color:#006942;font-size:1rem!important}.mr193{font-size:16px;font-weight:700;color:#00c700}.header9272 h1{color:#fff;margin-top:0}.container8262{max-width:600px;margin:16px auto;padding:8px;background-color:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}.faq-item{margin-bottom:20px}.question8262{font-size:16px;color:#fff;background-color:#3f51b5;padding:9px 23px 9px 9px;border-radius:5px;margin-bottom:9px;position:relative}.question8262::after{content:"+";position:absolute;top:50%;right:8px;transform:translateY(-50%);font-weight:700}.answer8262{font-size:14px;color:#333;padding:13px;border-radius:5px;display:none}.question8262::before{content:"Q. " attr(data-question-number) ": ";font-weight:700}.answer8262::before{content:"Answer. ";font-weight:700}#iTable{width:94%;border-radius:10px;background:linear-gradient(to right,#e0e0e0,#f9f9f9);overflow:hidden;padding:20px}#iTable th{padding:12px;text-align:left;font-size:17px;color:red}#iTable td{padding:10px;font-size:14px;border-bottom:2px solid #ddd}#iTable td:not(:last-child){border-right:2px solid #ddd}#iTable tr:nth-child(2n){background-color:#f9f9f9}#iTable td:first-child{font-weight:700}#iTable a{color:#00f;text-decoration:none;font-weight:700}.AllAppStore_Com_Slider{border:1px dashed red;background-color:#000}.AllAppStore_Com_Slider .AllAppStore_ticker{display:flex;align-items:center;flex-wrap:wrap}.AllAppStore_Com_Slider .AllAppStore_ticker .news{width:80%;margin:-2rem 0}.AllAppStore_Com_Slider .AllAppStore_ticker .title{width:20%;font-size:.3rem;text-align:center;background-color:#0013a4;color:#ffff}.AllAppStore_Com_Slider .AllAppStore_ticker .title p{font-size:13px;line-height:.4rem;font-weight:700}.AllAppStore_Com_Slider .AllAppStore_ticker .news marquee{font-size:12px;color:#fff;font-weight:600;padding-top:.18rem;line-height:.4rem}</style><script>function toggleMenu() {   var x = document.getElementById("menuContainer");   if (x.style.display === "block") {     x.style.display = "none";   } else {     x.style.display = "block";   } } function shareContent() {   // Extract the domain name from the URL   var domain = window.location.hostname;   // Attempt to get the meta description content   var metaElement = document.querySelector("meta[name=description]");   var metaDescription = metaElement ? metaElement.getAttribute("content") : '';   // Create the share text in the format "Title\n(domain) - (description)"   var shareText = document.title + "\n\n" + "indyonogames.com" + (metaDescription ? " - " + metaDescription : '') + "\n" + "Â» ";     // Check if the Web Share API is supported   if (navigator.share) {     navigator.share({       title: document.title,       text: shareText,       url: window.location.href     }).then(() => {       console.log('Thanks for sharing!');     })     .catch(console.error);   } else {     // Fallback for browsers that do not support navigator.share     alert('Web Share API is not supported in your browser.');   } } function closeStickyAd() {   document.getElementById('stickyAd').style.display = 'none'; } function showTab(selectedTab) {   var tabs = document.querySelectorAll(".tabs .tab");   var contents = document.querySelectorAll(".content");    tabs.forEach(function(tab) {     if (tab.id === selectedTab + "Tab") {       tab.classList.add("active");     } else {       tab.classList.remove("active");     }   });    contents.forEach(function(content) {     if (content.id === selectedTab) {       content.classList.add("active");     } else {       content.classList.remove("active");     }   }); }   document.addEventListener('DOMContentLoaded', function() {   const questions = document.querySelectorAll('.question8262');    questions.forEach((question, index) => {     question.addEventListener('click', () => {       const answer = question.nextElementSibling;       answer.classList.toggle('show');     });   }); });</script></head><body><!-- indyonogames.com Header Menu (Don't Copy Without My permission) -->

<div class="header">
    <a href="index.php">
      <img style="border-radius:10px" class="logo-top" src="logo.jpg" alt="Yono Apps Logo">
    </a>
    <a href="index.php">
      <div class="header-text">IndYonoGames</div>
    </a>
    <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer">
      <img class="telegram-top" src="telegram-join-button.png" alt="Yono Apps Telegram"></a>
    <div class="icon" onclick="toggleMenu()">&#9776; Menu</div>
  </div>
  <div class="menu-container" id="menuContainer">
    <div class="menu-row">
      <a href="index.php" class="menu-item"><i class="fa-solid fa-house"></i> Home</a>
      <a href="about-us.php" class="menu-item"><i class="fa-solid fa-clipboard-user"></i> About</a>
      <a href="contact-us.php" class="menu-item"><i class="fa-solid fa-envelope-circle-check"></i> Contact</a>
    </div>
    <div class="menu-row">
      <a href="privacy-policy.php" class="menu-item"><i class="fa-solid fa-shield-halved"></i> Privacy Policy</a>
      <a href="terms-and-conditions.php" class="menu-item"><i class="fa-solid fa-circle-exclamation"></i> Terms &#38;
        conditions</a>
      <a href="disclaimer.php" class="menu-item"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
    </div>
  </div>
    <div class="navbar">
    <a href="index.php" class=""><i class="fa-solid fa-house"></i> Home</a>
    <a href="about-us.php"><i class="fa-solid fa-address-book"></i> About</a>
    <a href="contact-us.php" class=""><i class="fa-solid fa-envelope"></i> Contact Us</a>
    <a href="disclaimer.php"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
    <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer"><i
        class="fa-brands fa-telegram"></i> Join Telegram</a>
  </div>
  <!-- header end -->
 <h1 style="display: none;">All Rummy App</h1>        
<div class="Dont_Copy_AllRummyApp_Com">
<h2><strong>Terms and Conditions</strong></h2>
<div class="devider"></div>

<p>Welcome to <strong><?php echo $weblink ;?></strong>!</p> 

<p>These terms and conditions outline the rules and regulations for the use of <strong>ABRA Pvt Ltd.'s </strong>Website, located at <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong>.</p>

<p>By accessing this website we assume you accept these terms and conditions. Do not continue to use <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong> if you do not agree to take all of the terms and conditions stated on this page.</p>
 
<p>The terms "Client," "You," and "Your" refer to the users of this website who have agreed to the terms and conditions set forth by the Company. This terminology also applies to all other agreements: the "Terms and Conditions," the "Privacy Statement," the "Disclaimer Notice," and all related documents. </p> <p>Our Company is referred to as "The Company," "Ourselves," "We," "Ours," and "Us." The terms "Party," "Parties," or "Us" include both the Client and us. All phrases refer to the provision of our support to the client in the most effective manner for the specific goal of addressing that client's needs in relation to the rendering of the Company's stated services, in line with and subject to, the law of the Netherlands. Any usage of the aforementioned terminology or other words in the singular, plural, he/she, or they format is understood to be interchangeable and to be referring to the same.</p>
 
<h3><strong>Cookies</strong></h3>

<p>We employ the use of cookies. By accessing <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong>, you agreed to use cookies in agreement with the ABRA Pvt Ltd.'s Privacy Policy. </p>

<p>Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.</p>
 
<h3><strong>License</strong></h3>

<p>Unless otherwise stated, ABRA Pvt Ltd. and/or its licensors own the intellectual property rights for all material on <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong>. All intellectual property rights are reserved. You may access this from <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong> for your own personal use subjected to restrictions set in these terms and conditions.</p>

<h3>You must not:</h3>
<ul>
    <li>Republish material from <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong></li>
    <li>Sell, rent or sub-license material from <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong></li>
    <li>Reproduce, duplicate or copy material from <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong></li>
    <li>Redistribute content from <strong><a href="https://<?php echo $weblink ;?>"><?php echo $weblink ;?></a></strong></li>
</ul>

<p>This Agreement shall begin on the date hereof. </p>

<p>Parts of this website offer an opportunity for users to post and exchange opinions and information in certain areas of the website. ABRA Pvt Ltd. does not filter, edit, publish or review Comments prior to their presence on the website. Comments do not reflect the views and opinions of ABRA Pvt Ltd.,its agents and/or affiliates. Comments reflect the views and opinions of the person who post their views and opinions. To the extent permitted by applicable laws, ABRA Pvt Ltd. shall not be liable for the Comments or for any liability, damages or expenses caused and/or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website.</p>

<p>ABRA Pvt Ltd. reserves the right to monitor all Comments and to remove any Comments which can be considered inappropriate, offensive or causes breach of these Terms and Conditions.</p>

<p>You warrant and represent that:</p>

<ul>
    <li>You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</li>
    <li>The Comments do not invade any intellectual property right, including without limitation copyright, patent or trademark of any third party;</li>
    <li>The Comments do not contain any defamatory, libelous, offensive, indecent or otherwise unlawful material which is an invasion of privacy</li>
    <li>The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity.</li>
</ul>

<p>You hereby grant ABRA Pvt Ltd. a non-exclusive license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats or media.</p>

<h3><strong>Hyperlinking to our Content</strong></h3>

<p>The following organizations may link to our Website without prior written approval:</p>

<ul>
    <li>Government agencies;</li>
    <li>Search engines;</li>
    <li>News organizations;</li>
    <li>Online directory distributors may link to our Website in the same manner as they hyperlink to the Websites of other listed businesses; and</li>
    <li>System wide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups which may not hyperlink to our Web site.</li>
</ul>

<p>These organizations may link to our home page, to publications or to other Website information so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services; and (c) fits within the context of the linking party’s site.</p>

<p>We may consider and approve other link requests from the following types of organizations:</p>

<ul>
    <li>commonly-known consumer and/or business information sources;</li>
    <li>dot.com community sites;</li>
    <li>associations or other groups representing charities;</li>
    <li>online directory distributors;</li>
    <li>internet portals;</li>
    <li>accounting, law and consulting firms; and</li>
    <li>educational institutions and trade associations.</li>
</ul>

<p>We will approve link requests from these organizations if we decide that: (a) the link would not make us look unfavorably to ourselves or to our accredited businesses; (b) the organization does not have any negative records with us; (c) the benefit to us from the visibility of the hyperlink compensates the absence of ABRA Pvt Ltd.; and (d) the link is in the context of general resource information.</p>

<p>These organizations may link to our home page so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products or services; and (c) fits within the context of the linking party’s site.</p>

<p>If you are one of the organizations listed in paragraph 2 above and are interested in linking to our website, you must inform us by sending an e-mail to ABRA Pvt Ltd.. Please include your name, your organization name, contact information as well as the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URLs on our site to which you would like to link. Wait 2-3 weeks for a response.</p>

<p>Approved organizations may hyperlink to our Website as follows:</p>

<ul>
    <li>By use of our corporate name; or</li>
    <li>By use of the uniform resource locator being linked to; or</li>
    <li>By use of any other description of our Website being linked to that makes sense within the context and format of content on the linking party’s site.</li>
</ul>

<p>No use of ABRA Pvt Ltd.'s logo or other artwork will be allowed for linking absent a trademark license agreement.</p>

<h3><strong>iFrames</strong></h3>

<p>Without prior approval and written permission, you may not create frames around our Webpages that alter in any way the visual presentation or appearance of our Website.</p>

<h3><strong>Content Liability</strong></h3>

<p>We shall not be hold responsible for any content that appears on your Website. You agree to protect and defend us against all claims that is rising on your Website. No link(s) should appear on any Website that may be interpreted as libelous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights.</p>

<h3><strong>Your Privacy</strong></h3>

<p>Please read Privacy Policy</p>

<h3><strong>Reservation of Rights</strong></h3>

<p>We reserve the right to request that you remove all links or any particular link to our Website. You approve to immediately remove all links to our Website upon request. We also reserve the right to amen these terms and conditions and it’s linking policy at any time. By continuously linking to our Website, you agree to be bound to and follow these linking terms and conditions.</p>

<h3><strong>Removal of links from our website</strong></h3>

<p>If you find any link on our Website that is offensive for any reason, you are free to contact and inform us any moment. We will consider requests to remove links but we are not obligated to or so or to respond to you directly.</p>

<p>We do not ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we promise to ensure that the website remains available or that the material on the website is kept up to date.</p>

<h3><strong>Disclaimer</strong></h3>

<p>To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website. Nothing in this disclaimer will:</p>

<ul>
    <li>limit or exclude our or your liability for death or personal injury;</li>
    <li>limit or exclude our or your liability for fraud or fraudulent misrepresentation;</li>
    <li>limit any of our or your liabilities in any way that is not permitted under applicable law; or</li>
    <li>exclude any of our or your liabilities that may not be excluded under applicable law.</li>
</ul>

<p>The limitations and prohibitions of liability set in this Section and elsewhere in this disclaimer: (a) are subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer, including liabilities arising in contract, in tort and for breach of statutory duty.</p>

<p>As long as the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature.</p>

           

</div>


<div class="main-background">
        <div class="group-card1 telegram-card1">
            <span style="display: flex; align-items: center;">
                <span onclick="shareContent()" class="join-text1">
                    <i class="fa-solid fa-square-share-nodes"></i> Share With Friends!
                </span>
            </span>
            <a class="seoquake-nofollow" onclick="shareContent()">
                <i class="fa-solid fa-share-from-square"></i> Click Here To Share
            </a>
        </div>

        <div class="center-text">
            <a class="link-style" href="about-us.php" target="_blank">About Us</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="disclaimer.php" target="_blank">Disclaimer</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="contact-us.php" target="_blank">Contact Us</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <br><a class="link-style" href="privacy-policy.php" target="_blank">Privacy Policy</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="terms-and-conditions.php" target="_blank">Terms & conditions</a>
        </div>
        <br>

        <div class="small-center-text">
            <span>
                <h1>Join Our Telegram:</h1>
            </span>
            <a class="footer-link" href="https://t.me/+FG0xq_lZH88zODI1" target="_blank">
                <h3>Click Here</h3>
            </a>
            <br>
            Copyright © 2024 <a href="index.php" style="color: white;"><strong>indyonogames.com</strong></a> All Rights Reserved
        </div>
    </div>
</footer>
</body>

</html>