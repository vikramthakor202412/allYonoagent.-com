<?php
if (isset($_GET['section']) && isset($_GET['offset'])) {
    $section = $_GET['section'];
    $offset = intval($_GET['offset']);
    
    // Load appropriate file based on section
    switch($section) {
        case '': $file = "allappss.json"; $prefix = ""; break;
        case 'b': $file = "allappss2.json"; $prefix = "b"; break;
        case 'c': $file = "allappss3.json"; $prefix = "c"; break;
        default: exit();
    }
    
    if (file_exists($file)) {
        $data = file_get_contents($file);
        $entries = explode(";'", $data);
        $count = 0;
        $output = "";
        
        // Skip already loaded entries
        for ($i = $offset; $i < count($entries) && $count < 10; $i++) {
            $entry = trim($entries[$i]);
            if (empty($entry)) continue;
            
            $json = json_decode($entry, true);
            if (!$json || !isset($json['nid'])) continue;
            
            $nid = htmlspecialchars($json['nid']);
            $detailPath = "alldetails{$prefix}/{$prefix}{$nid}.json";
            
            if (file_exists($detailPath)) {
                $details = json_decode(file_get_contents($detailPath), true);
                if ($details) {
                    $output .= '<ul class="app-list_dont_copy_created_by_allappstore_com">
                      <li class="app-item_dont_copy_created_by_allappstore_com">
                        <div class="app-icon_dont_copy_created_by_allappstore_com-container">
                          <img src="' . htmlspecialchars($details['imglink']) . '" alt=" Logo" class="app-icon_dont_copy_created_by_allappstore_com" onerror="this.src='https://via.placeholder.com/65'" />
                        </div>
                        <div class="app-details_dont_copy_created_by_allappstore_com">
                          <h6 class="app-title_dont_copy_created_by_allappstore_com">' . htmlspecialchars($details['name']) . '</h6>
                          <span class="bonus-amount_dont_copy_created_by_allappstore_com"><i class="fa-solid fa-gift"></i> Bonus ' . htmlspecialchars($details['signbo']) . '<br></span>
                          <span class="withdrawal-amount_dont_copy_created_by_allappstore_com"><i class="fa-solid fa-building-columns"></i> Min. Withdraw ₹' . htmlspecialchars($details['mwith']) . '</span>
                        </div>
                        <button class="download-button_dont_copy_created_by_allappstore_com action-btn" onclick="handleButtonClick('edtlifv2' . ('$prefix' ? '$prefix' : ''), '{$prefix}' . '$nid')" target="_blank">
                          <i class="fa-solid fa-download"></i> EDIT
                        </button>
                      </li>
                    </ul>
                    <div id="{$prefix}' . $nid . '"></div>';
                    $count++;
                }
            }
        }
        
        if ($output) {
            echo $output;
            if (($offset + $count) < count($entries)) {
                echo '<div id="more-' . $section . '" style="text-align:center; padding:20px;">
                      <button onclick="loadMoreApps(\'' . $section . '\', ' . ($offset + $count) . ')" style="padding:10px 20px; background:#5468ff; color:white; border:none; border-radius:5px;">
                          Load More Apps (+' . (count($entries) - ($offset + $count)) . ')
                      </button>
                    </div>';
            }
        }
    }
}
?>