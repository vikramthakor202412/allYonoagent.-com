<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");

$json = file_get_contents("name.json");
$json = json_decode($json, true);

$name         = htmlspecialchars($json['name']         ?? 'App Name');
$display_name = htmlspecialchars($json['display_name'] ?? $json['name'] ?? 'App Name');
$folder_name  = htmlspecialchars($json['folder_name']  ?? $json['name'] ?? 'App Name');
$meta_title   = trim($json['meta_title'] ?? '');
$meta_desc    = trim($json['meta_desc']  ?? '');

$imglink    = htmlspecialchars($json['imglink']    ?? '');
$mwith      = htmlspecialchars($json['mwith']      ?? '100');
$tdown      = htmlspecialchars($json['tdown']      ?? '10K+');
$signbo     = htmlspecialchars($json['signbo']     ?? '51');
$applink    = htmlspecialchars($json['applink']    ?? '#');
$bigimglink = htmlspecialchars($json['bigimglink'] ?? $json['imglink'] ?? '');
$chanidv    = htmlspecialchars($json['chanidv']    ?? '');
$gameidff   = htmlspecialchars($json['gameidff']   ?? '');
$madd       = htmlspecialchars($json['madd']       ?? '');
$refperapro = htmlspecialchars($json['refperapro'] ?? '');
$refcoms    = htmlspecialchars($json['refcoms']    ?? '');

// PER-APP PAGE TAGS (comma-separated, set via admin per app)
$page_tags_raw  = trim($json['page_tags'] ?? '');
if (!empty($page_tags_raw)) {
    $page_tags_items = array_filter(array_map('trim', explode(',', $page_tags_raw)));
} else {
    // Auto-generate sensible fallback tags from app data
    $page_tags_items = array_filter([
        $display_name,
        $display_name . ' APK',
        $display_name . ' Download',
        $display_name . ' Bonus',
        '₹' . $signbo . ' Sign Up Bonus',
        'Min Withdraw ₹' . $mwith,
        'Yono Rummy',
        'Rummy App',
        'Real Money App',
        'Sign Up Bonus',
        'New Rummy App',
        'Yono App',
    ]);
}

// Build pill HTML for auto-scroll belt
$page_pills_html = '';
foreach ($page_tags_items as $tag) {
    if (trim($tag) === '') continue;
    $page_pills_html .= '<span class="tag-pill"><i class="fa-solid fa-hashtag"></i>' . htmlspecialchars(trim($tag)) . '</span>';
}

// SEO
$seo_title = $meta_title !== ''
    ? htmlspecialchars($meta_title)
    : ($display_name . ' | ₹' . $signbo . ' SignUp Bonus | Download APK | Min Withdraw ₹' . $mwith);

$seo_desc = $meta_desc !== ''
    ? htmlspecialchars($meta_desc)
    : ('Join ' . $display_name . ' today & get up to ₹' . $signbo . ' bonus! Min withdrawal just ₹' . $mwith . '. Fast & secure – download now!');

$info_heading = $meta_title !== ''
    ? htmlspecialchars($meta_title)
    : ($display_name . ' APK Download – New Player Get ₹' . $signbo . ' Bonus');

$info_body = $meta_desc !== ''
    ? nl2br(htmlspecialchars($meta_desc))
    : ('<strong>' . $display_name . '</strong> is a popular online rummy game app where players can '
        . 'enjoy exciting card games, slots games and win real rewards. Download the '
        . '<strong>' . $display_name . ' app</strong> and experience smooth gameplay, '
        . 'secure payments, and fast withdrawals.');

// Channel / website files
$wch     = file_exists("../alldetails/wmaupchanl.json")   ? file_get_contents("../alldetails/wmaupchanl.json")   : '';
$mch     = file_exists("../alldetails/maupchanl.json")    ? file_get_contents("../alldetails/maupchanl.json")    : '';
$uch     = file_exists("../alldetails/upchanl.json")      ? file_get_contents("../alldetails/upchanl.json")      : '';
$rch     = file_exists("../alldetails/chanl.json")        ? file_get_contents("../alldetails/chanl.json")        : '';
$weblink = file_exists("../alldetails/1websitelink.json") ? file_get_contents("../alldetails/1websitelink.json") : '';

// All-apps list — sequential display number (1,2,3…), NID used only for folder path (backend)
$result2 = '';
$txn     = "../allappss.json";
if (file_exists($txn)) {
    $entries = [];
    foreach (explode(";'", file_get_contents($txn)) as $entry) {
        $jd = json_decode($entry, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($jd['nid'])) {
            $entries[] = $jd;
        }
    }
    // Sort by NID numerically so order is consistent
    usort($entries, fn($a, $b) => (int)$a['nid'] - (int)$b['nid']);

    $display_counter = 0; // Sequential 1,2,3… shown to visitor
    foreach ($entries as $jd) {
        $nid     = $jd['nid']; // NID used only for file path — never shown
        $appJson = @file_get_contents("../alldetails/$nid.json");
        if (!$appJson) continue;
        $appData = json_decode($appJson, true);

        $img         = htmlspecialchars($appData['imglink']      ?? '');
        $mwithdrawal = htmlspecialchars($appData['mwith']        ?? '100');
        $bon         = htmlspecialchars($appData['signbo']       ?? '51');
        $namee       = htmlspecialchars($appData['display_name'] ?? $appData['name'] ?? 'App');
        $nidd        = $appData['nid'] ?? ''; // backend only
        $fn          = htmlspecialchars($appData['folder_name']  ?? $appData['name'] ?? '');

        if (!$nidd) continue;

        $display_counter++; // ← this is what visitor sees: 1, 2, 3 …

        $result2 .= '<li class="app-item">
    <span class="app-num">' . $display_counter . '.</span>
    <div class="app-icon-wrap">
        <img src="' . $img . '" alt="' . $namee . '" class="app-icon" loading="lazy"/>
    </div>
    <div class="app-details">
        <h6 class="app-title">' . $namee . '</h6>
        <div class="app-meta">
            <span class="meta-bonus"><i class="fa-solid fa-gift"></i> Bonus Upto &#8377;' . $bon . '</span>
            <span class="meta-withdraw"><i class="fa-solid fa-building-columns"></i> Min. Withdraw &#8377;' . $mwithdrawal . '</span>
        </div>
    </div>
    <a href="../' . $fn . '/" class="dl-btn"><i class="fa-solid fa-download"></i> Download</a>
</li>';
    }
} else {
    $result2 = '<center><br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3></center>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $seo_title; ?></title>
    <link rel="canonical" href="index.php" />
    <meta name="description" content="<?php echo $seo_desc; ?>" />
    <meta name="keywords"    content="<?php echo $display_name; ?>, <?php echo $display_name; ?> apk, <?php echo $display_name; ?> bonus, rummy app" />
    <meta property="og:title"       content="<?php echo $seo_title; ?>" />
    <meta property="og:description" content="<?php echo $seo_desc;  ?>" />
    <meta property="og:url"         content="index.php" />
    <meta property="og:image"       content="<?php echo $imglink;   ?>" />
    <meta name="twitter:card"       content="summary_large_image" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
          integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" type="image/png" sizes="32x32" href="../fevicon/favicon-32x32.png">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
:root {
    --red:#e3232c; --red-dk:#c0392b; --red-lt:#ff4757;
    --red-glow:rgba(227,35,44,.35); --tg:#0088cc;
    --text:#1a1a1a; --muted:#555; --border:#eee;
    --bg:#f5f5f5; --white:#fff;
    --green:#16a34a; --orange:#f59e0b; --blue:#3b82f6; --purple:#8b5cf6;
    --card-shadow:0 4px 24px rgba(0,0,0,.09);
}
html { scroll-behavior:smooth; }
body { font-family:'Nunito',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; overflow-x:hidden; }
a    { text-decoration:none; color:inherit; }
img  { max-width:100%; display:block; }

@keyframes fadeUp    { from{opacity:0;transform:translateY(28px)}  to{opacity:1;transform:translateY(0)} }
@keyframes fadeIn    { from{opacity:0}                              to{opacity:1} }
@keyframes slideDown { from{opacity:0;transform:translateY(-100%)} to{opacity:1;transform:translateY(0)} }
@keyframes shimmer   { 0%{background-position:-400px 0} 100%{background-position:400px 0} }
@keyframes floatLogo { 0%,100%{transform:translateY(0) rotate(0deg)} 33%{transform:translateY(-6px) rotate(.8deg)} 66%{transform:translateY(-3px) rotate(-.5deg)} }
@keyframes pulseBorder{ 0%,100%{box-shadow:0 0 0 0 rgba(227,35,44,.45),var(--card-shadow)} 50%{box-shadow:0 0 0 7px rgba(227,35,44,0),var(--card-shadow)} }
@keyframes btnBeat   { 0%,100%{transform:scale(1);box-shadow:0 4px 18px var(--red-glow)} 50%{transform:scale(1.025);box-shadow:0 8px 28px rgba(227,35,44,.5)} }
@keyframes slideRight{ from{opacity:0;transform:translateX(-20px)} to{opacity:1;transform:translateX(0)} }
@keyframes ripple    { 0%{transform:scale(1);opacity:.6} 100%{transform:scale(2.4);opacity:0} }

/* ── HEADER ── */
.site-header{background:linear-gradient(100deg,var(--red-dk) 0%,var(--red) 50%,var(--red-lt) 100%);position:sticky;top:0;z-index:999;box-shadow:0 3px 14px rgba(0,0,0,.28);animation:slideDown .45s cubic-bezier(.22,.68,0,1.2) both;overflow:hidden;}
.site-header::after{content:'';position:absolute;bottom:0;left:0;width:100%;height:3px;background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.55) 50%,rgba(255,255,255,0));animation:shimmer 2.8s linear infinite;background-size:800px 3px;}
.header-inner{max-width:900px;margin:0 auto;padding:0 16px;display:flex;align-items:center;justify-content:space-between;height:58px;gap:10px;}
.header-logo{display:flex;align-items:center;gap:10px;transition:opacity .2s;flex-shrink:0;}
.header-logo:hover{opacity:.85;}
.header-logo img{height:40px;border-radius:8px;border:2px solid rgba(255,255,255,.5);transition:transform .3s;}
.header-logo:hover img{transform:rotate(-4deg) scale(1.08);}
.header-brand{color:#fff;font-size:1.1rem;font-weight:800;letter-spacing:.3px;}
.header-nav{display:flex;gap:4px;align-items:center;}
.header-nav a{color:rgba(255,255,255,.9);font-size:.82rem;font-weight:700;display:flex;align-items:center;gap:4px;padding:6px 10px;border-radius:6px;transition:background .2s,color .2s;}
.header-nav a:hover{background:rgba(255,255,255,.18);color:#fff;}
.tg-header-btn{background:rgba(255,255,255,.18)!important;border:2px solid rgba(255,255,255,.55);color:#fff!important;padding:6px 13px!important;border-radius:20px!important;font-size:.82rem!important;font-weight:800!important;}
.home-icon-btn{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.18);border:2px solid rgba(255,255,255,.55);color:#fff;font-size:.95rem;transition:background .2s,transform .2s;flex-shrink:0;}
.home-icon-btn:hover{background:rgba(255,255,255,.32);transform:scale(1.1);}
@media(max-width:600px){.header-nav{display:none;}}

/* ── LAYOUT ── */
.container{max-width:900px;margin:0 auto;padding:0 14px 40px;}

/* ── HERO CARD ── */
.hero-card{background:var(--white);border-radius:20px;padding:28px 20px 22px;margin:20px 0 16px;box-shadow:var(--card-shadow);text-align:center;position:relative;overflow:hidden;animation:fadeUp .6s .1s ease both;}
.hero-card::before{content:'';position:absolute;top:-60px;left:50%;transform:translateX(-50%);width:320px;height:120px;background:radial-gradient(ellipse,rgba(227,35,44,.09) 0%,transparent 70%);pointer-events:none;}
.hero-app-logo{width:120px;height:120px;border-radius:24px;object-fit:cover;border:3px solid var(--red);margin:0 auto 14px;animation:floatLogo 4s ease-in-out infinite,pulseBorder 2.5s ease-in-out infinite;position:relative;z-index:1;}
.hero-app-name{font-size:2rem;font-weight:900;color:var(--text);margin-bottom:2px;animation:fadeUp .5s .25s both;}
.hero-app-sub{color:var(--red);font-weight:700;font-size:1rem;margin-bottom:18px;animation:fadeUp .5s .32s both;}
.stats-strip{display:flex;flex-wrap:wrap;justify-content:center;gap:8px 20px;margin-bottom:20px;padding:13px 16px;background:#fafafa;border-radius:12px;border:1px solid var(--border);animation:fadeUp .5s .4s both;}
.stat-item{display:flex;align-items:center;gap:6px;font-size:.93rem;font-weight:800;color:#444;transition:transform .2s;}
.stat-item:hover{transform:scale(1.08);}
.stat-item i{color:var(--red);}
.stat-item .s-val{color:var(--text);}

/* ── DOWNLOAD BTN ── */
.download-main-btn{display:flex;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,var(--red),var(--red-dk));color:#fff;font-size:1.1rem;font-weight:900;padding:15px 24px;border-radius:12px;letter-spacing:.5px;width:100%;max-width:420px;margin:0 auto 12px;position:relative;overflow:hidden;animation:fadeUp .5s .48s both,btnBeat 2.4s 1.2s ease-in-out infinite;transition:filter .2s;}
.download-main-btn:hover{filter:brightness(1.1);}
.download-main-btn::before{content:'';position:absolute;inset:0;background:linear-gradient(110deg,transparent 30%,rgba(255,255,255,.18) 50%,transparent 70%);background-size:200% 100%;animation:shimmer 2.6s linear infinite;}

/* ── TELEGRAM BTN ── */
.telegram-btn{display:flex;align-items:center;justify-content:center;gap:8px;background:var(--white);color:var(--text);font-weight:800;font-size:1rem;padding:13px 24px;border-radius:12px;border:2px solid var(--red);width:100%;max-width:420px;margin:0 auto;animation:fadeUp .5s .56s both;transition:background .25s,color .25s,border-color .25s;}
.telegram-btn i{color:#0088cc;font-size:1.2rem;transition:color .25s;}
.telegram-btn:hover{background:#0088cc;color:#fff;border-color:#0088cc;}
.telegram-btn:hover i{color:#fff;}

/* ── INFO BOX ── */
.info-box{background:var(--white);border-radius:14px;padding:16px;margin:0 0 16px;box-shadow:var(--card-shadow);border-top:4px solid var(--red);animation:fadeUp .55s .18s both;}
.info-box h2{font-size:.82rem;font-weight:800;color:var(--text);margin-bottom:7px;line-height:1.45;}
.info-box p{font-size:.78rem;color:var(--muted);line-height:1.7;}
.info-box p strong{color:var(--text);}

/* ── RELATED APPS HEADER ── */
.related-header{background:linear-gradient(100deg,var(--red-dk),var(--red));color:#fff;font-size:1.15rem;font-weight:900;padding:14px 20px;border-radius:12px 12px 0 0;letter-spacing:.3px;display:flex;align-items:center;gap:10px;position:relative;overflow:hidden;}
.related-header::before{content:'';position:absolute;inset:0;background:linear-gradient(110deg,transparent 30%,rgba(255,255,255,.12) 50%,transparent 70%);background-size:200% 100%;animation:shimmer 3s linear infinite;}

/* ── APP LIST ── */
.app-list{list-style:none;padding:0;display:flex;flex-direction:column;background:var(--white);border-radius:0 0 14px 14px;box-shadow:var(--card-shadow);overflow:hidden;margin-bottom:0;}
.app-item{display:flex;align-items:center;padding:12px 14px;gap:10px;border-bottom:1px solid #f3f3f3;transition:background .18s,transform .18s;opacity:0;animation:slideRight .4s ease forwards;}
.app-item:last-child{border-bottom:none;}
.app-item:hover{background:#fff5f5;transform:translateX(3px);}

/* Sequential number shown to visitor — clean, no NID */
.app-num{
    font-size:.82rem;
    font-weight:900;
    color:var(--red);
    min-width:28px;
    height:28px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:rgba(227,35,44,.08);
    border-radius:50%;
    flex-shrink:0;
    font-family:'Nunito',sans-serif;
}

.app-icon-wrap{flex-shrink:0;}
.app-icon{width:60px;height:60px;border-radius:12px;object-fit:cover;border:2px solid #f0f0f0;transition:transform .25s,box-shadow .25s;}
.app-item:hover .app-icon{transform:scale(1.07) rotate(2deg);box-shadow:0 4px 14px rgba(227,35,44,.22);}
.app-details{flex:1;min-width:0;}
.app-title{font-size:1rem;font-weight:800;color:var(--text);margin-bottom:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.app-meta{display:flex;flex-direction:column;gap:3px;}
.meta-bonus{font-size:.82rem;font-weight:700;color:var(--red);}
.meta-bonus i{margin-right:3px;}
.meta-withdraw{font-size:.82rem;font-weight:700;color:var(--green);}
.meta-withdraw i{margin-right:3px;}
.dl-btn{flex-shrink:0;background:linear-gradient(135deg,var(--red),var(--red-dk));color:#fff;padding:9px 15px;border-radius:8px;font-weight:800;font-size:.86rem;white-space:nowrap;display:flex;align-items:center;gap:5px;box-shadow:0 2px 8px rgba(227,35,44,.28);transition:transform .15s,box-shadow .15s,filter .15s;position:relative;overflow:hidden;}
.dl-btn:hover{transform:translateY(-2px);box-shadow:0 5px 16px rgba(227,35,44,.4);filter:brightness(1.06);}

/* ── SECTION CARDS ── */
.section-card{background:var(--white);border-radius:16px;margin:0 0 16px;box-shadow:var(--card-shadow);overflow:hidden;}
.section-hdr{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #f0f0f0;}
.section-hdr-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0;}
.section-hdr-title{font-size:1rem;font-weight:900;color:var(--text);}
.section-hdr-sub{font-size:.75rem;color:var(--muted);margin-top:1px;}
.section-body{padding:16px 18px;}

/* ── ABOUT ── */
.about-hdr-icon{background:linear-gradient(135deg,rgba(227,35,44,.12),rgba(192,57,43,.06));color:var(--red);}
.about-text{font-size:.88rem;color:var(--muted);line-height:1.75;margin-bottom:12px;}
.about-text:last-child{margin-bottom:0;}
.about-text strong{color:var(--text);}

/* ── KEY FEATURES ── */
.features-hdr-icon{background:linear-gradient(135deg,rgba(245,158,11,.13),rgba(245,158,11,.04));color:var(--orange);}
.features-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px;}
.feature-item{display:flex;align-items:flex-start;gap:11px;background:#fafafa;border:1px solid #f0f0f0;border-radius:12px;padding:12px 13px;transition:transform .18s,box-shadow .18s;}
.feature-item:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,.07);}
.feature-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0;}
.feature-title{font-size:.85rem;font-weight:800;color:var(--text);margin-bottom:2px;}
.feature-desc{font-size:.76rem;color:var(--muted);line-height:1.5;}

/* ── DOWNLOAD STEPS ── */
.download-hdr-icon{background:linear-gradient(135deg,rgba(59,130,246,.13),rgba(59,130,246,.04));color:var(--blue);}
.steps-list{display:flex;flex-direction:column;gap:0;}
.step-item{display:flex;align-items:flex-start;gap:13px;padding:13px 0;border-bottom:1px solid #f5f5f5;}
.step-item:last-child{border-bottom:none;padding-bottom:0;}
.step-num-circle{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--blue),#6366f1);color:#fff;font-size:.82rem;font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;box-shadow:0 3px 10px rgba(59,130,246,.3);}
.step-content{flex:1;}
.step-title{font-size:.88rem;font-weight:800;color:var(--text);margin-bottom:3px;}
.step-desc{font-size:.79rem;color:var(--muted);line-height:1.55;}
.step-desc strong{color:var(--text);}

/* ── HINDI STEPS ── */
.register-hdr-icon{background:linear-gradient(135deg,rgba(139,92,246,.13),rgba(139,92,246,.04));color:var(--purple);}
.hindi-steps{display:flex;flex-direction:column;gap:8px;}
.hindi-step{display:flex;align-items:flex-start;gap:10px;background:#fafafa;border:1px solid #f0f0f0;border-radius:10px;padding:11px 12px;}
.hindi-step-icon{width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0;color:#fff;}
.hindi-step-icon.reg{background:linear-gradient(135deg,var(--purple),#a78bfa);}
.hindi-step-icon.bon{background:linear-gradient(135deg,var(--green),#34d399);}
.hindi-step-text{font-size:.82rem;color:var(--muted);line-height:1.6;}
.hindi-step-text strong{color:var(--text);font-size:.85rem;}

/* ── BONUS ── */
.bonus-hdr-icon{background:linear-gradient(135deg,rgba(22,163,74,.13),rgba(22,163,74,.04));color:var(--green);}
.bonus-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:9px;margin-bottom:12px;}
.bonus-card{background:#fafafa;border:1px solid #f0f0f0;border-radius:11px;padding:13px 10px;text-align:center;transition:transform .18s,box-shadow .18s;}
.bonus-card:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(0,0,0,.07);}
.bonus-card-icon{font-size:1.4rem;margin-bottom:6px;}
.bonus-card-val{font-size:1rem;font-weight:900;color:var(--red);margin-bottom:2px;}
.bonus-card-lbl{font-size:.72rem;font-weight:700;color:var(--muted);}

/* ── SAFETY ── */
.safety-hdr-icon{background:linear-gradient(135deg,rgba(22,163,74,.13),rgba(22,163,74,.04));color:var(--green);}
.safety-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:9px;}
.safety-item{display:flex;align-items:center;gap:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:11px 13px;}
.safety-item i{color:var(--green);font-size:.95rem;flex-shrink:0;width:16px;text-align:center;}
.safety-item-text{font-size:.82rem;font-weight:700;color:#166534;}

/* ── DISCLAIMER ── */
.disclaimer-box{background:#fff5f5;border:1px solid #fca5a5;border-left:4px solid var(--red);border-radius:12px;padding:16px 18px;margin:16px 0;font-size:.88rem;color:#555;line-height:1.75;}
.disclaimer-box strong{color:var(--red-dk);}

/* ══════════════════════════════════════════════════════
   AUTO-SCROLLING TAGS BAR
   CSS animation scrolls tags left infinitely.
   JS duplicates pills for a seamless seamless loop.
══════════════════════════════════════════════════════ */
.tags-scroll-section{
    border-top:1px dashed var(--red);
    border-bottom:1px dashed var(--red);
    background:#fff0f0;
    overflow:hidden;
    display:flex;
    align-items:stretch;
    margin-top:16px;
}
.tags-scroll-label{
    flex-shrink:0;
    background:linear-gradient(135deg,#c0392b 0%,#e3232c 50%,#ff4757 100%);
    color:#fff;
    font-size:10px;
    font-weight:900;
    letter-spacing:.8px;
    text-transform:uppercase;
    padding:0 14px;
    display:flex;
    align-items:center;
    gap:5px;
    white-space:nowrap;
    border-right:2px solid rgba(255,255,255,.25);
    box-shadow:3px 0 10px rgba(227,35,44,.2);
    z-index:2;
    position:relative;
}
.tags-scroll-track{
    flex:1;
    overflow:hidden;
    display:flex;
    align-items:center;
    position:relative;
    min-width:0;
}
.tags-scroll-track::before,
.tags-scroll-track::after{
    content:'';
    position:absolute;
    top:0;bottom:0;
    width:28px;
    z-index:1;
    pointer-events:none;
}
.tags-scroll-track::before{left:0;background:linear-gradient(to right,#fff0f0,transparent);}
.tags-scroll-track::after {right:0;background:linear-gradient(to left,#fff0f0,transparent);}
.tags-scroll-belt{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:8px 14px;
    white-space:nowrap;
    will-change:transform;
    animation:tagsBelt 25s linear infinite;
}
.tags-scroll-belt:hover{ animation-play-state:paused; }
@keyframes tagsBelt{
    from{ transform:translateX(0); }
    to  { transform:translateX(-50%); }
}
.tag-pill{
    display:inline-flex;
    align-items:center;
    gap:5px;
    background:#fff;
    border:1.5px solid rgba(227,35,44,.22);
    border-radius:999px;
    padding:5px 13px;
    font-size:11.5px;
    font-weight:700;
    color:var(--red);
    white-space:nowrap;
    flex-shrink:0;
    cursor:default;
    transition:background .2s,color .2s,transform .15s,border-color .2s;
    user-select:none;
}
.tag-pill:hover{
    background:var(--red);
    color:#fff;
    border-color:var(--red);
    transform:scale(1.07);
}
.tag-pill i{ font-size:9px; opacity:.6; }

/* ── FOOTER ── */
footer{background:var(--white);border-top:1px solid var(--border);text-align:center;padding:20px 12px;color:#888;font-size:.87rem;margin-top:10px;animation:fadeIn .6s .5s both;}
footer a{color:var(--red);font-weight:700;transition:color .2s;}
footer a:hover{color:var(--red-dk);}
footer strong{color:var(--text);}

/* ── SCROLL REVEAL ── */
.js-reveal{opacity:0;transform:translateY(22px);transition:opacity .5s ease,transform .5s ease;}
.js-reveal.visible{opacity:1;transform:translateY(0);}

@media(max-width:580px){
    .features-grid{grid-template-columns:1fr;}
    .bonus-cards{grid-template-columns:repeat(2,1fr);}
    .safety-grid{grid-template-columns:1fr;}
}
@media(max-width:480px){
    .hero-app-logo{width:100px;height:100px;}
    .hero-app-name{font-size:1.65rem;}
    .app-icon{width:52px;height:52px;}
    .dl-btn{padding:8px 11px;font-size:.8rem;}
}
</style>
</head>
<body>

<!-- HEADER -->
<header class="site-header">
    <div class="header-inner">
        <a href="../index.php" class="header-logo">
            <img src="../logo.jpg" alt="IndYonoGames Logo">
            <span class="header-brand">IndYonoGames</span>
        </a>
        <a href="../index.php" class="home-icon-btn" title="Go to Home">
            <i class="fa-solid fa-house"></i>
        </a>
        <nav class="header-nav">
            <a href="../index.php">Home</a>
            <a href="../about-us.php">About</a>
            <a href="../contact-us.php">Contact</a>
            <a href="../disclaimer.php">Disclaimer</a>
            <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" class="tg-header-btn">&#128226; Join Telegram</a>
        </nav>
    </div>
</header>

<!-- MAIN -->
<div class="container">

    <!-- HERO CARD -->
    <div class="hero-card">
        <img src="<?php echo $imglink; ?>" alt="<?php echo $display_name; ?>" class="hero-app-logo">
        <h1 class="hero-app-name"><?php echo $display_name; ?></h1>
        <p  class="hero-app-sub"><?php echo $display_name; ?> APK</p>
        <div class="stats-strip">
            <div class="stat-item"><i class="fa-solid fa-star"></i><span class="s-val">4.1 Ratings</span></div>
            <div class="stat-item"><i class="fa-solid fa-download"></i><span class="s-val"><?php echo $tdown; ?></span></div>
            <div class="stat-item"><i class="fa-solid fa-cart-shopping"></i><span class="s-val">Free</span></div>
            <div class="stat-item"><i class="fa-solid fa-indian-rupee-sign"></i><span class="s-val" id="bonusStat"><?php echo $signbo; ?> Bonus</span></div>
        </div>
        <a href="<?php echo $applink; ?>" class="download-main-btn">
            <i class="fa-solid fa-download"></i>
            DOWNLOAD <?php echo strtoupper($display_name); ?> APK
        </a>
        <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" class="telegram-btn">
            <i class="fa-brands fa-telegram"></i>
            Join Our Telegram Channel
        </a>
    </div>

    <!-- META INFO BOX -->
    <div class="info-box js-reveal">
        <h2><?php echo $info_heading; ?></h2>
        <p><?php echo $info_body; ?></p>
    </div>

    <!-- RELATED APPS — shows 1,2,3… NID stays backend only -->
    <div class="related-header js-reveal">&#11015;&nbsp; Other Related Apps</div>
    <ul class="app-list">
        <?php echo $result2 ?: '<p style="text-align:center;padding:30px;color:#888;font-weight:700;">No apps available right now...</p>'; ?>
    </ul>

    <div style="height:20px;"></div>

    <!-- ABOUT -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon about-hdr-icon"><i class="fa-solid fa-circle-info"></i></div>
            <div>
                <div class="section-hdr-title">About <?php echo $display_name; ?></div>
                <div class="section-hdr-sub">Everything you need to know</div>
            </div>
        </div>
        <div class="section-body">
            <p class="about-text">
                <strong><?php echo $display_name; ?></strong> is one of the most popular gaming applications in India,
                offering users an exciting opportunity to earn real money while playing their favourite games.
                With a user-friendly interface and secure payment system, this app has gained the trust of
                thousands of players across the country.
            </p>
            <p class="about-text">
                The app features a wide variety of games including <strong>Rummy, Teen Patti, Poker</strong>, and many
                other skill-based games that not only provide entertainment but also offer substantial earning
                opportunities for skilled players.
            </p>
        </div>
    </div>

    <!-- KEY FEATURES -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon features-hdr-icon"><i class="fa-solid fa-star"></i></div>
            <div>
                <div class="section-hdr-title">Key Features &amp; Benefits</div>
                <div class="section-hdr-sub">Why players love <?php echo $display_name; ?></div>
            </div>
        </div>
        <div class="section-body">
            <div class="features-grid">
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(227,35,44,.13),rgba(227,35,44,.04));color:var(--red);"><i class="fa-solid fa-gift"></i></div>
                    <div><div class="feature-title">Welcome Bonus</div><div class="feature-desc">Get &#8377;<?php echo $signbo; ?> as a sign-up bonus when you register on <?php echo $display_name; ?></div></div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(22,163,74,.13),rgba(22,163,74,.04));color:var(--green);"><i class="fa-solid fa-building-columns"></i></div>
                    <div><div class="feature-title">Low Withdrawal</div><div class="feature-desc">Minimum withdrawal is just &#8377;<?php echo $mwith; ?> via bank or UPI</div></div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(59,130,246,.13),rgba(59,130,246,.04));color:var(--blue);"><i class="fa-solid fa-shield-halved"></i></div>
                    <div><div class="feature-title">Secure Payments</div><div class="feature-desc">Fast and secure payment processing with advanced encryption</div></div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(245,158,11,.13),rgba(245,158,11,.04));color:var(--orange);"><i class="fa-solid fa-headset"></i></div>
                    <div><div class="feature-title">24/7 Support</div><div class="feature-desc">Round-the-clock customer support ready to help you anytime</div></div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(139,92,246,.13),rgba(139,92,246,.04));color:var(--purple);"><i class="fa-solid fa-dice"></i></div>
                    <div><div class="feature-title">Fair Play</div><div class="feature-desc">Certified random number generator ensures fair gameplay for all</div></div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon" style="background:linear-gradient(135deg,rgba(236,72,153,.13),rgba(236,72,153,.04));color:#ec4899;"><i class="fa-solid fa-gamepad"></i></div>
                    <div><div class="feature-title">Multiple Games</div><div class="feature-desc">Rummy, Teen Patti, Poker, Ludo and many more skill-based games</div></div>
                </div>
            </div>
        </div>
    </div>

    <!-- DOWNLOAD STEPS -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon download-hdr-icon"><i class="fa-solid fa-download"></i></div>
            <div>
                <div class="section-hdr-title"><?php echo $display_name; ?> Download &amp; Install</div>
                <div class="section-hdr-sub">Simple steps to get started</div>
            </div>
        </div>
        <div class="section-body">
            <div class="steps-list">
                <div class="step-item">
                    <div class="step-num-circle">1</div>
                    <div class="step-content"><div class="step-title">Download APK File</div><div class="step-desc">Click the <strong>"Download APK"</strong> button at the top of this page to get the <?php echo $display_name; ?> APK file.</div></div>
                </div>
                <div class="step-item">
                    <div class="step-num-circle">2</div>
                    <div class="step-content"><div class="step-title">Enable Unknown Sources</div><div class="step-desc">Go to <strong>Settings &rarr; Security &rarr; Unknown Sources</strong> and enable it to allow APK installation.</div></div>
                </div>
                <div class="step-item">
                    <div class="step-num-circle">3</div>
                    <div class="step-content"><div class="step-title">Install the App</div><div class="step-desc">Open the downloaded APK from your notification panel or file manager and tap <strong>Install</strong>.</div></div>
                </div>
                <div class="step-item">
                    <div class="step-num-circle">4</div>
                    <div class="step-content"><div class="step-title">Register &amp; Verify</div><div class="step-desc">Open <?php echo $display_name; ?>, enter your mobile number, verify via OTP, and complete your profile.</div></div>
                </div>
                <div class="step-item">
                    <div class="step-num-circle">5</div>
                    <div class="step-content"><div class="step-title">Claim Your &#8377;<?php echo $signbo; ?> Bonus</div><div class="step-desc">Your sign-up bonus of <strong>&#8377;<?php echo $signbo; ?></strong> is credited automatically after registration. Start playing!</div></div>
                </div>
            </div>
        </div>
    </div>

    <!-- REGISTER (Hindi) -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon register-hdr-icon"><i class="fa-solid fa-user-plus"></i></div>
            <div>
                <div class="section-hdr-title"><?php echo $display_name; ?> रजिस्टर करें</div>
                <div class="section-hdr-sub">आसान हिंदी में स्टेप-बाय-स्टेप गाइड</div>
            </div>
        </div>
        <div class="section-body">
            <div class="hindi-steps">
                <div class="hindi-step">
                    <div class="hindi-step-icon reg"><i class="fa-solid fa-mobile-screen"></i></div>
                    <div class="hindi-step-text"><strong>ऐप ओपन करें</strong> — <?php echo $display_name; ?> ऐप इंस्टॉल करने के बाद ओपन करें, मोबाइल नंबर डालें और OTP से वेरिफाई करें।</div>
                </div>
                <div class="hindi-step">
                    <div class="hindi-step-icon reg"><i class="fa-solid fa-language"></i></div>
                    <div class="hindi-step-text"><strong>भाषा चुनें</strong> — अपनी पसंद की भाषा सिलेक्ट करें (हिंदी या अंग्रेज़ी) और प्रोफाइल सेटअप करें।</div>
                </div>
                <div class="hindi-step">
                    <div class="hindi-step-icon reg"><i class="fa-solid fa-indian-rupee-sign"></i></div>
                    <div class="hindi-step-text"><strong>साइन-अप बोनस</strong> — रजिस्ट्रेशन पूरा होते ही आपके वॉलेट में <strong>&#8377;<?php echo $signbo; ?> बोनस</strong> क्रेडिट हो जाएगा।</div>
                </div>
            </div>
        </div>
    </div>

    <!-- BONUS CLAIM -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon bonus-hdr-icon"><i class="fa-solid fa-sack-dollar"></i></div>
            <div>
                <div class="section-hdr-title"><?php echo $display_name; ?> Bonus Claim</div>
                <div class="section-hdr-sub">Earn &amp; withdraw real money</div>
            </div>
        </div>
        <div class="section-body">
            <div class="bonus-cards">
                <div class="bonus-card"><div class="bonus-card-icon">🎁</div><div class="bonus-card-val">&#8377;<?php echo $signbo; ?></div><div class="bonus-card-lbl">Sign-Up Bonus<br>नए यूजर्स के लिए</div></div>
                <div class="bonus-card"><div class="bonus-card-icon">👥</div><div class="bonus-card-val">&#8377;10–50</div><div class="bonus-card-lbl">Refer &amp; Earn<br>प्रति रेफरल</div></div>
                <div class="bonus-card"><div class="bonus-card-icon">🏦</div><div class="bonus-card-val">&#8377;<?php echo $mwith; ?></div><div class="bonus-card-lbl">Min. Withdrawal<br>Bank / UPI</div></div>
                <div class="bonus-card"><div class="bonus-card-icon">🃏</div><div class="bonus-card-val">50+</div><div class="bonus-card-lbl">Games Available<br>रमी, टीन पत्ती…</div></div>
            </div>
            <div class="hindi-steps">
                <div class="hindi-step">
                    <div class="hindi-step-icon bon"><i class="fa-solid fa-gift"></i></div>
                    <div class="hindi-step-text"><strong>साइन-अप बोनस:</strong> &#8377;<?php echo $signbo; ?> फ्री कैश — सिर्फ नए यूजर्स के लिए, रजिस्ट्रेशन पर तुरंत मिलेगा।</div>
                </div>
                <div class="hindi-step">
                    <div class="hindi-step-icon bon"><i class="fa-solid fa-users"></i></div>
                    <div class="hindi-step-text"><strong>रेफर &amp; अर्न:</strong> दोस्तों को रेफर करने पर &#8377;10–50 प्रति रेफरल कमाएं।</div>
                </div>
                <div class="hindi-step">
                    <div class="hindi-step-icon bon"><i class="fa-solid fa-building-columns"></i></div>
                    <div class="hindi-step-text"><strong>मिनिमम विदड्रॉल:</strong> सिर्फ &#8377;<?php echo $mwith; ?> — बैंक ट्रांसफर या UPI से तुरंत निकालें।</div>
                </div>
            </div>
        </div>
    </div>

    <!-- SAFETY -->
    <div class="section-card js-reveal">
        <div class="section-hdr">
            <div class="section-hdr-icon safety-hdr-icon"><i class="fa-solid fa-shield-halved"></i></div>
            <div>
                <div class="section-hdr-title">Safety &amp; Security</div>
                <div class="section-hdr-sub">Your data &amp; money is always safe</div>
            </div>
        </div>
        <div class="section-body">
            <p class="about-text" style="margin-bottom:14px;">
                Your safety and security are top priorities on <strong><?php echo $display_name; ?></strong>. The app uses
                advanced encryption technology to protect your personal and financial information.
                All transactions are processed through secure payment gateways, ensuring your money is always safe.
            </p>
            <div class="safety-grid">
                <div class="safety-item"><i class="fa-solid fa-lock"></i><span class="safety-item-text">SSL Encrypted Connection</span></div>
                <div class="safety-item"><i class="fa-solid fa-shield-check"></i><span class="safety-item-text">Secure Payment Gateway</span></div>
                <div class="safety-item"><i class="fa-solid fa-user-shield"></i><span class="safety-item-text">Data Privacy Protected</span></div>
                <div class="safety-item"><i class="fa-solid fa-rotate"></i><span class="safety-item-text">Regular Security Updates</span></div>
                <div class="safety-item"><i class="fa-solid fa-dice"></i><span class="safety-item-text">Certified RNG Fair Play</span></div>
                <div class="safety-item"><i class="fa-solid fa-headset"></i><span class="safety-item-text">24/7 Customer Support</span></div>
            </div>
        </div>
    </div>

    <!-- DISCLAIMER -->
    <div class="disclaimer-box js-reveal">
        <strong>Important Notice</strong><br><br>
        We do <strong>not</strong> operate or own any of the listed apps.<br>
        Rummy &amp; similar games can be addictive and involve financial risk.<br>
        Only for users <strong>18+</strong>. Play responsibly.<br><br>
        Rummy is banned in Andhra Pradesh, Assam, Nagaland, Odisha, Sikkim, Tamil Nadu, Telangana.
    </div>

</div><!-- /container -->

<!-- AUTO-SCROLLING TAGS BAR (per-app tags from name.json, admin-controlled) -->
<div class="tags-scroll-section">
    <div class="tags-scroll-label">
        <i class="fa-solid fa-tags"></i>
        Tags:
    </div>
    <div class="tags-scroll-track">
        <div class="tags-scroll-belt" id="pageTagsBelt">
            <?php echo $page_pills_html; ?>
        </div>
    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>Thanks for visiting!</p>
    <p style="margin:8px 0;">
        <a href="../about-us.php">About</a> &bull;
        <a href="../disclaimer.php">Disclaimer</a> &bull;
        <a href="../contact-us.php">Contact</a>
    </p>
    <p style="margin-top:12px;">&copy; 2024 <strong>indyonogames.com</strong> &ndash; All Rights Reserved</p>
</footer>

<script>
/* ── STAGGER APP LIST ROWS ── */
document.querySelectorAll('.app-item').forEach(function(el, i){
    el.style.animationDelay = (0.04 + i * 0.05) + 's';
});

/* ── SCROLL REVEAL ── */
(function(){
    var els = document.querySelectorAll('.js-reveal');
    if(!els.length) return;
    function check(){
        var wh = window.innerHeight;
        els.forEach(function(el){
            if(el.getBoundingClientRect().top < wh - 55) el.classList.add('visible');
        });
    }
    window.addEventListener('scroll', check, {passive:true});
    check();
})();

/* ── RIPPLE ON DOWNLOAD BUTTONS ── */
document.querySelectorAll('.download-main-btn, .dl-btn').forEach(function(btn){
    btn.addEventListener('click', function(e){
        var circle = document.createElement('span');
        var d = Math.max(btn.clientWidth, btn.clientHeight);
        var rect = btn.getBoundingClientRect();
        circle.style.cssText = [
            'position:absolute','border-radius:50%','background:rgba(255,255,255,.32)',
            'width:'+d+'px','height:'+d+'px',
            'left:'+(e.clientX-rect.left-d/2)+'px',
            'top:'+(e.clientY-rect.top-d/2)+'px',
            'pointer-events:none','animation:ripple .55s linear forwards'
        ].join(';');
        btn.appendChild(circle);
        setTimeout(function(){ circle.remove(); }, 600);
    });
});

/* ── ANIMATED BONUS COUNTER ── */
(function(){
    var el = document.getElementById('bonusStat');
    if(!el) return;
    var raw    = '<?php echo addslashes($signbo); ?>';
    var target = parseInt(raw) || 51;
    var dur = 900, st = null;
    function step(ts){
        if(!st) st = ts;
        var p = Math.min((ts - st) / dur, 1);
        var e = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.floor(e * target) + ' Bonus';
        if(p < 1) requestAnimationFrame(step);
        else       el.textContent = target + ' Bonus';
    }
    setTimeout(function(){ requestAnimationFrame(step); }, 600);
})();

/* ══════════════════════════════════════════════════════
   AUTO-SCROLL TAGS — seamless infinite CSS marquee
   1. Duplicate all pill HTML so we have 2 identical
      copies side-by-side in the belt.
   2. CSS animates translateX(0 → -50%) forever.
      When -50% is reached it snaps back to 0 — the
      visitor never sees the jump because copy 2 = copy 1.
   3. Duration is set proportional to belt width so
      the scrolling speed stays constant (~80 px/s)
      regardless of how many tags are configured.
══════════════════════════════════════════════════════ */
(function(){
    var belt = document.getElementById('pageTagsBelt');
    if(!belt) return;

    // Duplicate content for seamless infinite loop
    belt.innerHTML = belt.innerHTML + belt.innerHTML;

    // Set animation duration proportional to rendered width
    function fixDuration(){
        var halfW  = belt.scrollWidth / 2; // one set of pills
        var speed  = 80;                   // pixels per second
        belt.style.animationDuration = (halfW / speed).toFixed(2) + 's';
    }
    fixDuration();
    window.addEventListener('resize', fixDuration, {passive:true});
})();
</script>

</body>
</html>
