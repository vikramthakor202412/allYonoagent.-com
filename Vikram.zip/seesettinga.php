  <html>
  <head>
        <style>
/* Reset default styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Style for input */
.input-style {
  border: 2px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  font-size: 16px;
  width: 300px; /* Adjust width as needed */
  transition: border-color 0.3s ease;
}

/* Hover effect */
.input-style:hover,
.input-style:focus {
  border-color: #007bff; /* Change border color on hover/focus */
  outline: none; /* Remove default focus outline */
}

/* Placeholder text style */
.input-style::placeholder {
  color: #999; /* Placeholder text color */
}
</style>
<style>
/* Reset default styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Style for submit button */
.submit-btn {
  background-color: #007bff; /* Button background color */
  color: #fff; /* Text color */
  padding: 10px 20px; /* Adjust padding as needed */
  font-size: 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

/* Hover effect */
.submit-btn:hover {
  background-color: #0056b3; /* Change background color on hover */
}

/* Focus effect */
.submit-btn:focus {
  outline: none; /* Remove default focus outline */
  box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.5); /* Add focus border */
}

/* Disabled state */
.submit-btn:disabled {
  background-color: #ccc; /* Change background color when disabled */
  cursor: not-allowed; /* Change cursor when disabled */
}
</style>
</head>
<?php



$id=$_GET["id"];  
$kaam=$_GET["kaam"];
$name=$_GET["name"];
$imglink=$_GET["imglink"];
$applink=$_GET["applink"];
$bigimglink=$_GET["bigimglink"];
$mwith=$_GET["mwith"];
$madd=$_GET["madd"];
$tdown=$_GET["tdown"];
$signbo=$_GET["signbo"];
$refcoms=$_GET["refcoms"]; $refperapro=$_GET["refperapro"];
$gameidff=$_GET["gameidff"]; $chanidv=$_GET["chanidv"];
$idv=$id;
if(!$name){$idv=$name;}

if($id=="cv"){ echo""; file_put_contents("alldetails2/chanl.json",$name); return;}
if($id=="uplogo"){ echo""; file_put_contents("alldetails2/upchanl.json",$name); return;}
if($id=="changedomlogvf"){ echo""; file_put_contents("alldetails2/maupchanl.json",$name); return;}
if($id=="changewhatlogodn"){ echo""; file_put_contents("alldetails2/wmaupchanl.json",$name); return;}
if($id=="tgsup"){  echo""; file_put_contents("alldetails2/telegramcon.json",$name); return;}
if($id=="gmails"){ echo""; file_put_contents("alldetails2/email.json",$name); return;}



if($kaam=="edt"){echo"";
$folder =  mkdir("$name");
$file = '{"imglink":"'.$imglink.'","signbo":"'.$signbo.'","tdown":"'.$tdown.'","mwith":"'.$mwith.'","name":"'.$name.'","nid":"'.$idv.'","chanidv":"'.$chanidv.'","madd":"'.$madd.'","bigimglink":"'.$bigimglink.'","applink":"'.$applink.'","refcoms":"'.$refcoms.'","gameidff":"'.$gameidff.'","refperapro":"'.$refperapro.'"}'; file_put_contents("$name/name.json",$file); 
$filee = ''; file_put_contents("$name/index.php",$filee);

$copy = copy("page.php", "$name/index.php");
$codingbest='{"imglink":"'.$imglink.'","signbo":"'.$signbo.'","tdown":"'.$tdown.'","mwith":"'.$mwith.'","name":"'.$name.'","nid":"'.$idv.'","chanidv":"'.$chanidv.'","madd":"'.$madd.'","bigimglink":"'.$bigimglink.'","applink":"'.$applink.'","refcoms":"'.$refcoms.'","gameidff":"'.$gameidff.'","refperapro":"'.$refperapro.'"}'; file_put_contents("alldetails2/$id.json",$codingbest); return;}



$filev="alldetails2/$id.json";
$decfe=file_get_contents($filev);
$jso=json_decode($decfe,true);
$name=$jso["name"];
$imglink=$jso["imglink"];
$applink=$jso["applink"];
$bigimglink=$jso["bigimglink"];
$mwith=$jso["mwith"];
$madd=$jso["madd"];
$tdown=$jso["tdown"];
$signbo=$jso["signbo"];
$refcoms=$jso["refcoms"];
$refperapro=$jso["refperapro"];
$gameidff=$jso["gameidff"];
$chanidv=$jso["chanidv"];

if($id=="changechanlink"){ $filev="alldetails2/chanl.json";  $chanidv=file_get_contents($filev); echo' <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ Enter Channel Logo ]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter Telegram Channel Link" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'changechanlink\')" class="submit-btn" target="_blank">SAVE</a><br><br></ul> </center> <input type="hidden" class="input-style" id="id"   value="cv"></div><br><br>'; return;}

if($id=="changeupperlogo"){ $filev="alldetails2/upchanl.json";  $chanidv=file_get_contents($filev); echo'  <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ Enter 1920*566 Logo LInk ]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter 1920*566 Logo LInk" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'changeupperlogo\')" class="submit-btn" target="_blank">SAVE</a><br><br> </ul> </center> <input type="hidden" class="input-style" id="id"   value="uplogo"></div><br><br>'; return;}

if($id=="changedomlog"){ $filev="alldetails2/maupchanl.json";  $chanidv=file_get_contents($filev); echo'  <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ ENTER 1920*421 Logo Link ]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter 1920*421 Logo LInk" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'changedomlog\')" class="submit-btn" target="_blank">SAVE</a><br> <br></ul> </center> <input type="hidden" class="input-style" id="id"   value="changedomlogvf"></div><br><br>'; return;}

if($id=="changewhatlogo"){ $filev="alldetails2/wmaupchanl.json";  $chanidv=file_get_contents($filev); echo' <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ Enter Whats Up Channel Link ]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter Whats Up Channel Link" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'changewhatlogo\')" class="submit-btn" target="_blank">SAVE</a><br><br></ul> </center> <input type="hidden" class="input-style" id="id"   value="changewhatlogodn"></div><br><br>'; return;}

if($id=="gmail"){ $filev="alldetails2/email.json";  $chanidv=file_get_contents($filev); echo' <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ Enter Bussinus Gmail ]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter Bussinus Gmail" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'gmail\')" class="submit-btn" target="_blank">SAVE</a><br><br></ul> </center> <input type="hidden" class="input-style" id="id"   value="gmails"></div><br><br>'; return;}

if($id=="tgdsupport"){ $filev="alldetails2/telegramcon.json";  $chanidv=file_get_contents($filev); echo' <br><center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;  " > <font size="4" style="font:bold; background: orange; ">[ Enter Telegram Support Link]</font><hr><br> <input type="text" class="input-style" id="name" Placeholder="Enter Telegram Support Link" value="'.$chanidv.'"> <br><br><a  onclick="edtlifv22a(\'tgdsupport\')" class="submit-btn" target="_blank">SAVE</a><br><br></ul> </center> <input type="hidden" class="input-style" id="id"   value="tgsup"></div><br><br>'; return;}

echo'<center><div style=" width:90%; background: white; border-top:3px solid black; border-right:3px solid black; border-bottom:3px solid black;border-left:3px solid black; border-radius:25px;   " >
<font size="4" style="font:bold; background: orange; ">[ INDEX ID IS '.$id.' ]</font><hr> 
<input type="text" class="input-style" id="name" Placeholder="Name" value="'.$name.'"><br>
<input type="text" class="input-style" id="imglink" Placeholder="Img Link" value="'.$imglink.'"><br>
<input type="text" class="input-style" id="applink" Placeholder="App Link" value="'.$applink.'"><br>
<input type="text" class="input-style" id="bigimglink" Placeholder="Download Big Download Img Link" value="'.$bigimglink.'"><br>
<input type="text" class="input-style" id="mwith" Placeholder="Min Withdraw" value="'.$mwith.'"><br>
<input type="text" class="input-style" id="madd" Placeholder="Min Add" value="'.$madd.'"><br>
<input type="text" class="input-style" id="tdown" Placeholder="Total Downloads" value="'.$tdown.'"><br>
<input type="text" class="input-style" id="signbo" Placeholder="Sign-up Bonus" value="'.$signbo.'"><br>
<input type="text" class="input-style" id="refcoms" Placeholder="Refer Percent Commision" value="'.$refcoms.'"><br>
<input type="text" class="input-style" id="refperapro" Placeholder="Refer Percent Affiliate Program" value="'.$refperapro.'"><br>
<input type="text" class="input-style" id="gameidff" Placeholder="Refer link Game ID" value="'.$gameidff.'"><br>
<input type="text" class="input-style" id="chanidv" Placeholder="Refer Link Channel ID" value="'.$chanidv.'">
<input type="hidden" class="input-style" id="id"   value="'.$id.'"><br><br>

<a  onclick="edtlifv22a(\''.$id.'\')" class="submit-btn"  target="_blank">SAVE</a><br><br></ul> </div></center> ';
			

?>

</html>