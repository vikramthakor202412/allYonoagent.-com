<?php
ini_set('max_execution_time', '60');

$rgeggrgergggr = "alldetails/1websitelink.json";
$weblink = file_exists($rgeggrgergggr) ? file_get_contents($rgeggrgergggr) : 'indyonogames.com';

$rgeggrgergggr = "alldetails/email.json";
$email = file_exists($rgeggrgergggr) ? file_get_contents($rgeggrgergggr) : 'contact@indyonogames.com';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>About Us - IndYonoGames</title>
<link rel="canonical" href="about-us.php" />
<meta name="description" content="About Us - Yono Apps (Read Carefully)" />
<meta content='About Us - Yono Apps' name='keywords'/>
<meta content='About Us - Yono Apps' name='title'/>
<meta property="og:image" content="logo.jpg"/>
<meta property="og:url" content="about-us.php"/>
<meta property="og:title" content="About Us - IndYonoGames"/>
<meta property="og:description" content="About Us - Yono Apps"/>
<meta name="og:site_name" content="IndYonoGames"/>
<meta property="og:type" content="website" />
<meta property="og:locale" content="en_IN" />
<link rel="icon" type="image/png" sizes="32x32" href="logo.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="logo.jpg">
<meta name="msapplication-TileColor" content="#0a0a0f">
<meta name="theme-color" content="#c9922a">
<meta name="robots" content="index, follow"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<script>
function toggleMenu() {
  var x = document.getElementById("menuContainer");
  x.style.display = x.style.display === "block" ? "none" : "block";
}
function shareContent() {
  var metaElement = document.querySelector("meta[name=description]");
  var metaDescription = metaElement ? metaElement.getAttribute("content") : '';
  var shareText = document.title + "\n\n" + "indyonogames.com" + (metaDescription ? " - " + metaDescription : '') + "\n" + "» ";
  if (navigator.share) {
    navigator.share({ title: document.title, text: shareText, url: window.location.href }).catch(console.error);
  } else {
    alert('Web Share API is not supported in your browser.');
  }
}
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.question8262').forEach(function(question) {
    question.addEventListener('click', function() {
      question.nextElementSibling.classList.toggle('show');
    });
  });
});
</script>
<style>
:root {
    --bg-primary: #0a0a0f;
    --bg-secondary: #13131e;
    --bg-card: #1a1a2e;
    --text-primary: #f0ead6;
    --text-secondary: #9a8f7a;
    --accent-primary: #c9922a;
    --accent-secondary: #e8b84b;
    --accent-hover: #f5d17a;
    --accent-glow: rgba(201,146,42,0.35);
    --border-color: rgba(201,146,42,0.2);
    --shadow-color: rgba(0,0,0,0.7);
    --gradient-bg: linear-gradient(135deg, #b07d1e 0%, #e8b84b 50%, #c9922a 100%);
    --gradient-card: linear-gradient(145deg, #1a1a2e 0%, #13131e 100%);
    --green: #22c55e;
    --red: #f87171;
}
body {
    background: var(--bg-primary);
    color: var(--text-primary);
    font-family: 'Nunito', Arial, sans-serif;
    margin: 0; padding: 0;
    animation: fadeIn 0.8s ease-in-out;
}
body::before {
    content: '';
    position: fixed; inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none; z-index: 0; opacity: 0.4;
}
@keyframes fadeIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }

.header {
    background: linear-gradient(135deg, #0d0d1a 0%, #1a1408 50%, #0d0d1a 100%);
    border-bottom: 2px solid var(--accent-primary);
    color: #fff; display: flex;
    justify-content: space-between; align-items: center;
    padding: 8px 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.8);
    position: relative; z-index: 100;
}
.logo-top { width: 35px; height: auto; border-radius: 8px; }
.telegram-top { width: 54px; height: auto; }
.header-text {
    flex-grow: 1; margin: 0 8px; text-align: left;
    font-weight: 700; font-size: 22px;
    font-family: 'Cinzel', serif;
    color: var(--accent-secondary) !important;
    text-shadow: 0 0 20px rgba(232,184,75,0.4);
    letter-spacing: 0.5px; text-decoration: none;
}
.icon { display: block; text-align: right; padding: 2px 6px; color: #fff; font-size: 18px; font-weight: 700; cursor: pointer; }

.menu-container {
    display: none;
    background: linear-gradient(135deg, #0d0d1a 0%, #1a1408 100%);
    padding: 16px; border-bottom: 1px solid var(--border-color);
    position: relative; z-index: 99;
}
.menu-row { display: flex; justify-content: space-around; flex-wrap: wrap; gap: 6px; }
.menu-item {
    background: linear-gradient(135deg, rgba(201,146,42,0.2) 0%, rgba(232,184,75,0.1) 100%);
    border: 1px solid var(--border-color);
    color: var(--accent-secondary); padding: 8px 14px; margin: 4px;
    display: inline-block; width: 28%; border-radius: 10px;
    font-family: 'Nunito', sans-serif; font-weight: 700; font-size: 11px;
    text-decoration: none; text-align: center; transition: all 0.25s ease;
}
.menu-item:hover { background: rgba(201,146,42,0.3); color: var(--accent-hover); transform: translateY(-2px); }

.navbar {
    display: flex; justify-content: center; flex-wrap: nowrap;
    background: linear-gradient(90deg, #0d0d1a 0%, #1a1408 50%, #0d0d1a 100%);
    border-top: 1px solid rgba(201,146,42,0.2);
    border-bottom: 1px solid rgba(201,146,42,0.2);
    overflow: hidden; position: relative; z-index: 98;
}
.navbar a {
    white-space: nowrap; float: left;
    color: var(--text-secondary); padding: 6px 8px;
    font-size: 11px !important; font-weight: 700;
    font-family: 'Nunito', sans-serif;
    border-right: 1px solid rgba(201,146,42,0.15);
    text-decoration: none; transition: all 0.2s ease;
}
.navbar a:last-child { border-right: none; }
.navbar a.active, .navbar a:hover {
    background: linear-gradient(135deg, rgba(201,146,42,0.25) 0%, rgba(232,184,75,0.12) 100%);
    color: var(--accent-secondary) !important;
}

.page-content { max-width: 860px; margin: 0 auto; padding: 20px 14px 30px; position: relative; z-index: 1; }

h2, h2.relatedapps {
    color: #1a0e00 !important;
    background: var(--gradient-bg);
    border-radius: 10px; font-size: 20px;
    text-align: center; padding: 10px 20px;
    border: 2px solid rgba(255,255,255,0.15);
    font-family: 'Cinzel', serif;
    margin: 16px 0 12px;
    box-shadow: 0 4px 16px rgba(201,146,42,0.4);
}

p { color: var(--text-primary); font-size: 14px; line-height: 1.7; padding: 8px 4px; font-family: 'Nunito', sans-serif; }
p strong { color: var(--accent-secondary); }
p a { color: var(--accent-primary); text-decoration: underline; }

/* ── ABOUT HERO CARD ── */
.about-hero {
    background: var(--gradient-card);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    margin: 16px 0;
    box-shadow: 0 8px 30px var(--shadow-color);
    position: relative;
    overflow: hidden;
}
.about-hero::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--gradient-bg);
}
.about-hero p { padding: 6px 0; margin: 0; }

/* ── NOTICE BOX ── */
.notice-box {
    background: rgba(201,146,42,0.08);
    border: 1px solid var(--border-color);
    border-left: 3px solid var(--accent-primary);
    border-radius: 0 10px 10px 0;
    padding: 14px 16px;
    margin: 14px 0;
    font-size: 13px;
    color: var(--text-primary);
    line-height: 1.7;
}
.notice-box b, .notice-box strong { color: var(--accent-secondary); }
.notice-box a { color: var(--accent-primary); text-decoration: underline; }

/* ── FOOTER ── */
footer { position: relative; z-index: 1; }
.group-card, .group-card1 {
    display: flex; align-items: center;
    justify-content: space-between;
    padding: 12px 14px; border: 1px solid var(--border-color);
    overflow: hidden;
}
.group-card {
    background: linear-gradient(135deg, rgba(0,79,122,0.2) 0%, rgba(0,79,122,0.05) 100%);
    animation: telegram-border-animation 1s infinite;
}
.group-card1 {
    background: linear-gradient(135deg, rgba(43,122,64,0.2) 0%, rgba(43,122,64,0.05) 100%);
    animation: telegram-border-animation 1s infinite;
}
@keyframes telegram-border-animation {
    0%,100% { border-color: var(--border-color); }
    50% { border-color: var(--accent-primary); }
}
.join-text { margin-left: 10px; font-weight: 700; color: #7dd3fc; font-size: .9rem; }
.join-text1 { margin-left: 10px; font-weight: 700; color: #86efac; font-size: 1rem; }
.icon-telegram { font-size: 24px; color: #7dd3fc; }
.seoquake-nofollow {
    display: inline-flex; align-items: center; justify-content: center;
    font-size: .9rem; font-weight: 700; text-decoration: none;
    padding: 8px 18px; border-radius: 8px; flex-shrink: 0;
    transition: all .3s ease-in-out; color: #fff !important;
}
.telegram-card .seoquake-nofollow { background: #004f7a; }
.telegram-card1 .seoquake-nofollow { background: var(--gradient-bg); color: #1a0e00 !important; }
.seoquake-nofollow:hover { transform: scale(1.05); filter: brightness(1.1); }
.main-background {
    background: linear-gradient(to top, #0a0a0f 0%, #1a1408 100%);
    color: var(--text-primary); border-top: 2px solid var(--accent-primary);
    padding: 16px 12px;
}
.center-text { font-size: .95rem; font-weight: 700; line-height: 2; text-align: center; }
.small-center-text { font-size: .75rem; font-weight: 700; line-height: 1.8; text-align: center; }
.link-style { color: var(--accent-secondary); text-decoration: underline; }
.footer-link { color: var(--accent-secondary); text-decoration: none; }

.back-to-top {
    position: fixed; bottom: 20px; right: 14px; z-index: 8999;
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--gradient-bg); border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 6px 20px rgba(201,146,42,0.55);
    opacity: 0; pointer-events: none;
    transform: translateY(20px) scale(0.8);
    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.back-to-top.visible { opacity: 1; pointer-events: auto; transform: translateY(0) scale(1); }
.back-to-top i { color: #1a0e00; font-size: 1.05rem; }
img { max-width: 100%; height: auto; }
a { -webkit-tap-highlight-color: transparent; }
</style>
</head>
<body>

<div class="header">
  <a href="index.php"><img style="border-radius:10px" class="logo-top" src="logo.jpg" alt="IndYonoGames Logo"></a>
  <a href="index.php" style="text-decoration:none;"><div class="header-text">IndYonoGames</div></a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer">
    <img class="telegram-top" src="telegram-join-button.png" alt="Telegram"></a>
  <div class="icon" onclick="toggleMenu()">&#9776; Menu</div>
</div>

<div class="menu-container" id="menuContainer">
  <div class="menu-row">
    <a href="index.php" class="menu-item"><i class="fa-solid fa-house"></i> Home</a>
    <a href="about-us.php" class="menu-item"><i class="fa-solid fa-clipboard-user"></i> About</a>
    <a href="contact-us.php" class="menu-item"><i class="fa-solid fa-envelope-circle-check"></i> Contact</a>
  </div>
  <div class="menu-row">
    <a href="privacy-policy.php" class="menu-item"><i class="fa-solid fa-shield-halved"></i> Privacy Policy</a>
    <a href="terms-and-conditions.php" class="menu-item"><i class="fa-solid fa-circle-exclamation"></i> Terms &amp; Conditions</a>
    <a href="disclaimer.php" class="menu-item"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
  </div>
</div>

<div class="navbar">
  <a href="index.php"><i class="fa-solid fa-house"></i> Home</a>
  <a href="about-us.php" class="active"><i class="fa-solid fa-address-book"></i> About</a>
  <a href="contact-us.php"><i class="fa-solid fa-envelope"></i> Contact Us</a>
  <a href="disclaimer.php"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
  <a href="https://t.me/+FG0xq_lZH88zODI1" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-telegram"></i> Join Telegram</a>
</div>
<!-- header end -->

<div class="page-content">

<h2 class="relatedapps"><i class="fa-solid fa-circle-info"></i> About Us</h2>

<div class="about-hero">
  <p>अगर दोस्तो आप <strong>Rummy &amp; Teen Patti App</strong> से पैसे कमाना चाहते हैं तो हमारी इस <strong>Official Website <?php echo htmlspecialchars($weblink); ?> Daily</strong> आते रहे। यहां पर आपको <strong>New Rummy Earning App</strong> या फीर <strong>All Best Rummy &amp; Teen Patti Earning App</strong> और सभी प्रकार Casino App आपको हमारी इस Website पर मिलेंगे। इन सभी एप्लीकेशन से आप घर बैठे हजारों रुपए कमा सकते है।</p>

  <p>हमारी इस <strong><a href="https://<?php echo htmlspecialchars($weblink); ?>"><?php echo htmlspecialchars($weblink); ?></a> Website</strong> का एक ही लक्ष्य है की आपको <strong>New Rummy Earning App &amp; New Teen Patti Earning App</strong> और सभी प्रकार Casino App की जानकारी सबसे पहले मिले। अगर आप किसी भी App की ज्यादा जानकारी प्राप्त करना चाहते हैं तो आपको आर्टिकल भी मिल जायेंगे। जिस से आप उस App के बारेमे और जानकारी पता लगा सको।</p>

  <p><b>Contact Us –</b> <a href="contact-us.php">Visit Our Contact Us Page</a></p>
</div>

<div class="notice-box">
  <strong>⚠️ आवश्यक सूचना :-</strong> इस <strong><a href="https://<?php echo htmlspecialchars($weblink); ?>"><?php echo htmlspecialchars($weblink); ?></a> Website</strong> पर जो भी App है उन सभी App में हम आपको पैसे Add करने की सलाह नहीं देते हैं। इसके बावजूद भी आप अपने पैसे Add करते हैं तो फ़ायदे और नुकसान के लिए आप स्वयं जिम्मेदार होंगे।
</div>

</div><!-- /page-content -->

<footer>
  <div class="group-card telegram-card">
    <span style="display:flex;align-items:center;">
      <i class="fab fa-telegram icon-telegram"></i>
      <span class="join-text">Join Our Telegram Channel</span>
    </span>
    <a class="seoquake-nofollow" href="https://t.me/+FG0xq_lZH88zODI1" rel="nofollow noopener noreferrer" target="_blank">
      <i class="fab fa-telegram"></i> Join Now
    </a>
  </div>
  <div class="main-background">
    <div class="group-card1 telegram-card1">
      <span style="display:flex;align-items:center;">
        <span onclick="shareContent()" class="join-text1" style="cursor:pointer;">
          <i class="fa-solid fa-square-share-nodes"></i> Share With Friends!
        </span>
      </span>
      <a class="seoquake-nofollow" onclick="shareContent()" style="cursor:pointer;">
        <i class="fa-solid fa-share-from-square"></i> Click Here To Share
      </a>
    </div>
    <div class="center-text">
      <a class="link-style" href="about-us.php">About Us</a> &nbsp;&nbsp;
      <a class="link-style" href="disclaimer.php">Disclaimer</a> &nbsp;&nbsp;
      <a class="link-style" href="contact-us.php">Contact Us</a><br>
      <a class="link-style" href="privacy-policy.php">Privacy Policy</a> &nbsp;&nbsp;
      <a class="link-style" href="terms-and-conditions.php">Terms &amp; Conditions</a>
    </div>
    <br>
    <div class="small-center-text">
      <span><h1 style="font-size:14px;font-family:'Cinzel',serif;color:var(--accent-secondary);">Join Our Telegram:</h1></span>
      <a class="footer-link" href="https://t.me/+FG0xq_lZH88zODI1" target="_blank">
        <strong style="color:var(--accent-primary);font-size:16px;">Click Here</strong>
      </a><br><br>
      Copyright &copy; 2024 <a href="index.php" style="color:var(--accent-secondary);"><strong>indyonogames.com</strong></a> All Rights Reserved
    </div>
  </div>
</footer>

<button class="back-to-top" id="backToTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" aria-label="Back to top">
  <i class="fa-solid fa-chevron-up"></i>
</button>

<script>
(function(){
  var btn = document.getElementById('backToTop');
  if(!btn) return;
  window.addEventListener('scroll', function(){
    btn.classList.toggle('visible', window.scrollY > 300);
  }, {passive:true});
})();
</script>

</body>
</html>
