// ══════════════════════════════════════════════════
//   AllYonoGame — Service Worker (PWA)
//   File: sw.js  |  Place in ROOT folder
// ══════════════════════════════════════════════════

var CACHE_NAME = 'allyonogame-v2';

// Only cache local files — external URLs can fail and block install
var CACHE_URLS = [
    './index.php',
    './logo.jpg',
    './banner.jpg',
    './telegram-join-button.png',
    './manifest.json'
];

// ── INSTALL: Cache local assets only ───────────────
self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(function(cache) {
            // Use individual adds so one failure doesn't block all
            var promises = CACHE_URLS.map(function(url) {
                return cache.add(url).catch(function(err) {
                    console.warn('Could not cache:', url, err);
                });
            });
            return Promise.all(promises);
        })
    );
    // Take control immediately without waiting for old SW to die
    self.skipWaiting();
});

// ── ACTIVATE: Delete old caches ────────────────────
self.addEventListener('activate', function(event) {
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames
                    .filter(function(name) { return name !== CACHE_NAME; })
                    .map(function(name) { return caches.delete(name); })
            );
        }).then(function() {
            return self.clients.claim();
        })
    );
});

// ── FETCH: Network first, then cache fallback ──────
self.addEventListener('fetch', function(event) {
    // Only handle GET requests
    if (event.request.method !== 'GET') return;

    // Only handle same-origin and http/https requests
    var url = event.request.url;
    if (!url.startsWith('http')) return;

    // Skip browser-extension and chrome-extension requests
    if (url.startsWith('chrome-extension')) return;

    event.respondWith(
        fetch(event.request)
            .then(function(networkResponse) {
                // Cache valid responses from our own origin only
                if (
                    networkResponse &&
                    networkResponse.status === 200 &&
                    networkResponse.type === 'basic'
                ) {
                    var clone = networkResponse.clone();
                    caches.open(CACHE_NAME).then(function(cache) {
                        cache.put(event.request, clone);
                    });
                }
                return networkResponse;
            })
            .catch(function() {
                // Network failed — serve from cache
                return caches.match(event.request).then(function(cached) {
                    if (cached) return cached;
                    // Fallback for HTML navigation requests
                    if (event.request.headers.get('accept') &&
                        event.request.headers.get('accept').includes('text/html')) {
                        return caches.match('./index.php');
                    }
                });
            })
    );
});
