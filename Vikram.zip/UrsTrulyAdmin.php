<?php
ob_start();
@ini_set('max_file_uploads',500);@ini_set('post_max_size','128M');@ini_set('upload_max_filesize','32M');
@ini_set('max_input_vars',5000);@ini_set('max_execution_time',300);@ini_set('memory_limit','256M');
ini_set('session.cookie_httponly',1);ini_set('session.cookie_samesite','Strict');ini_set('session.gc_maxlifetime',604800);
session_set_cookie_params(['lifetime'=>604800,'httponly'=>true,'samesite'=>'Strict']);
session_start();
define('ADMIN_USER','INDYONO@ADMIN');define('ADMIN_PASS','IndYono@Admin@345');
define('BD',__DIR__.DIRECTORY_SEPARATOR);define('TOTP_FILE',BD.'alldetails/.totp_secret.json');
define('SESSION_DAYS',7);define('SELF','UrsTrulyAdmin.php');

function tb32($b){$b=strtoupper(str_replace(' ','',$b));$c='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$s='';$buf=0;$bits=0;for($i=0;$i<strlen($b);$i++){$v=strpos($c,$b[$i]);if($v===false)continue;$buf=($buf<<5)|$v;$bits+=5;if($bits>=8){$bits-=8;$s.=chr(($buf>>$bits)&0xFF);}}return $s;}
function tgen($sec,$off=0){$k=tb32($sec);$t=floor((time()+$off*30)/30);$m=pack('N*',0).pack('N*',$t);$h=hash_hmac('sha1',$m,$k,true);$o=ord($h[19])&0xF;$c=((ord($h[$o])&0x7F)<<24)|((ord($h[$o+1])&0xFF)<<16)|((ord($h[$o+2])&0xFF)<<8)|(ord($h[$o+3])&0xFF);return str_pad($c%1000000,6,'0',STR_PAD_LEFT);}
function tverify($sec,$inp){$inp=trim($inp);for($o=-1;$o<=1;$o++){if(tgen($sec,$o)===$inp)return true;}return false;}
function tnew(){$c='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$s='';for($i=0;$i<32;$i++)$s.=$c[random_int(0,31)];return $s;}
function tqr($sec){$u='otpauth://totp/'.rawurlencode('YonoBestGame Admin').'?secret='.$sec.'&issuer=YonoBestGame&digits=6&period=30';return 'https://api.qrserver.com/v1/create-qr-code/?size=240x240&data='.urlencode($u);}
function loadT(){return file_exists(TOTP_FILE)?json_decode(file_get_contents(TOTP_FILE),true):null;}
function saveT($d){$dir=dirname(TOTP_FILE);if(!is_dir($dir))mkdir($dir,0750,true);file_put_contents(TOTP_FILE,json_encode($d));}
$TC=loadT();$T_READY=!empty($TC['secret'])&&!empty($TC['verified']);
function sessOK(){if(empty($_SESSION['ayg_ok']))return false;if((time()-($_SESSION['ayg_ts']??0))>SESSION_DAYS*86400){session_destroy();return false;}return true;}
if(isset($_GET['logout'])){session_destroy();header('Location: '.SELF);exit;}
$ip=md5($_SERVER['REMOTE_ADDR']??'');$rlf=sys_get_temp_dir().'/ayg_'.$ip.'.json';
function rlGet($f){$n=time();$d=file_exists($f)?json_decode(file_get_contents($f),true):['t'=>$n,'c'=>0];if($n-$d['t']>900)$d=['t'=>$n,'c'=>0];return $d;}
function rlAdd($f,$d){$d['c']++;file_put_contents($f,json_encode($d));}
$rl=rlGet($rlf);$rl_blocked=$rl['c']>=10;
$setup=false;$setup_err='';$setup_step=1;
if(!$T_READY){
  $setup=true;
  if(!empty($TC['secret'])&&empty($TC['verified'])){
    $setup_step=2;
    if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['vt'])){
      if(!$rl_blocked){if(tverify($TC['secret'],$_POST['totp_code']??'')){$TC['verified']=true;saveT($TC);header('Location: '.SELF);exit;}else{rlAdd($rlf,$rl);$setup_err='Wrong code. Try again.';}}
      else{$setup_err='Too many attempts. Wait 15 min.';}
    }
  }elseif($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['ss'])){$s=tnew();saveT(['secret'=>$s,'verified'=>false]);$TC=loadT();$setup_step=2;}
}
$login_err='';$logged_in=sessOK();
if(!$logged_in&&!$setup&&$_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['do_login'])){
  if($rl_blocked){$login_err='Too many attempts. Wait 15 minutes.';}
  else{if(trim($_POST['u']??'')===ADMIN_USER&&($_POST['p']??'')===ADMIN_PASS&&tverify($TC['secret'],$_POST['totp_code']??'')){$_SESSION['ayg_ok']=true;$_SESSION['ayg_ts']=time();session_regenerate_id(true);header('Location: '.SELF);exit;}else{rlAdd($rlf,$rl);$login_err='Wrong username, password, or authenticator code.';}}
}
function rj($p){if(!file_exists($p))return null;$d=json_decode(file_get_contents($p),true);return(json_last_error()===JSON_ERROR_NONE)?$d:null;}
function wj($p,$d){$dir=dirname($p);if(!is_dir($dir))mkdir($dir,0755,true);file_put_contents($p,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
function rApps($f){if(!file_exists($f))return[];$e=[];foreach(explode(";'",file_get_contents($f))as $x){$j=json_decode(trim($x),true);if($j&&isset($j['nid']))$e[]=$j;}return $e;}
function wApps($f,$arr){file_put_contents($f,implode(";'",array_map('json_encode',$arr)));}
function appendNid($f,$nid){$ex=rApps($f);if(!in_array($nid,array_column($ex,'nid'))){$l=json_encode(['nid'=>$nid]);$sep=file_exists($f)&&filesize($f)>0?";'":'';file_put_contents($f,$sep.$l,FILE_APPEND);}}
function ensureDir($p){if(!is_dir($p))mkdir($p,0755,true);}
function flash($m,$t='ok'){$_SESSION['flash']=[$m,$t];}
function gFlash(){if(!empty($_SESSION['flash'])){$f=$_SESSION['flash'];unset($_SESSION['flash']);return $f;}return null;}
function h($s){return htmlspecialchars((string)($s??''),ENT_QUOTES,'UTF-8');}
function getNextNid(){$f=BD.'series.json';$n=file_exists($f)?(int)file_get_contents($f):0;$n++;file_put_contents($f,(string)$n);return(string)$n;}
function peekNextNid(){$f=BD.'series.json';$n=file_exists($f)?(int)file_get_contents($f):0;return(string)($n+1);}
function bumpSeriesIfNeeded($nid){$f=BD.'series.json';$cur=file_exists($f)?(int)file_get_contents($f):0;if((int)$nid>$cur)file_put_contents($f,(string)(int)$nid);}
function rotateNewSlots($nd){ensureDir(BD.'new');for($i=1;$i<=4;$i++){$src=BD.'new/'.($i+1).'.json';$dst=BD.'new/'.$i.'.json';if(file_exists($src))copy($src,$dst);elseif(file_exists($dst))@unlink($dst);}wj(BD.'new/5.json',$nd);}
function buildNameJson($d,$nid){
  $nd=['imglink'=>$d['imglink']??'','signbo'=>$d['signbo']??'0','tdown'=>$d['tdown']??'0','mwith'=>$d['mwith']??'0',
    'name'=>$d['name']??'','display_name'=>$d['display_name']??$d['name']??'',
    'folder_name'=>$d['folder_name']??$d['name']??'',
    'meta_title'=>$d['meta_title']??'','meta_desc'=>$d['meta_desc']??'',
    'page_tags'=>$d['page_tags']??'','nid'=>$nid,'chanidv'=>$d['chanidv']??'','madd'=>$d['madd']??'0',
    'bigimglink'=>$d['bigimglink']??'','applink'=>$d['applink']??'',
    'refcoms'=>$d['refcoms']??'','gameidff'=>$d['gameidff']??'','refperapro'=>$d['refperapro']??''];
  if(isset($d['tag_text']))$nd['tag_text']=$d['tag_text'];
  if(isset($d['tag_color']))$nd['tag_color']=$d['tag_color'];
  return $nd;
}
function createAppFolder($fn,$nid,$appData=null){
  if(empty($fn))return false;$fp=BD.$fn;
  if(!is_dir($fp)){if(!mkdir($fp,0755,true))return false;}
  $ps=BD.'page.php';$pd=$fp.'/index.php';
  if(file_exists($ps))copy($ps,$pd);else file_put_contents($pd,'<?php header("Location: ../index.php");exit;');
  if($appData){file_put_contents($fp.'/name.json',json_encode(buildNameJson($appData,$nid),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
  return true;
}
function updateNameJson($fn,$d,$nid){if(!$fn||!is_dir(BD.$fn))return;file_put_contents(BD.$fn.'/name.json',json_encode(buildNameJson($d,$nid),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
function appDataFromPost($nid){
  return ['nid'=>$nid,'name'=>trim($_POST['name']??''),'display_name'=>trim($_POST['display_name']??''),
    'folder_name'=>trim($_POST['folder_name']??''),'meta_title'=>trim($_POST['meta_title']??''),
    'meta_desc'=>trim($_POST['meta_desc']??''),'page_tags'=>trim($_POST['page_tags']??''),
    'imglink'=>trim($_POST['imglink']??''),'applink'=>trim($_POST['applink']??''),
    'bigimglink'=>trim($_POST['bigimglink']??''),'signbo'=>trim($_POST['signbo']??'0'),
    'mwith'=>trim($_POST['mwith']??'0'),'madd'=>trim($_POST['madd']??'0'),
    'tdown'=>trim($_POST['tdown']??'0'),'refcoms'=>trim($_POST['refcoms']??''),
    'refperapro'=>trim($_POST['refperapro']??''),'gameidff'=>trim($_POST['gameidff']??''),
    'chanidv'=>trim($_POST['chanidv']??''),'tag_text'=>trim($_POST['tag_text']??''),
    'tag_color'=>trim($_POST['tag_color']??'#e3232c')];
}
$TP=[['HOT','HOT','#ef4444'],['TOP','TOP','#c9922a'],['NEW','NEW','#22c55e'],['HIGH BONUS','HIGH BONUS','#8b5cf6'],['VIP','VIP','#3b82f6'],['FAST PAY','FAST PAY','#f59e0b'],['TRENDING','TRENDING','#ec4899'],['VERIFIED','VERIFIED','#10b981'],['Remove','','#6b7280']];

if($logged_in&&$_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['action'])){
  $ac=$_POST['action'];
  if($ac==='add_all'){
    if(trim($_POST['name']??'')===''){flash('App Name required.','err');header('Location: '.SELF.'?tab=all_app');exit;}
    $nid=getNextNid();$d=appDataFromPost($nid);
    if(empty($d['folder_name']))$d['folder_name']=$d['name'];
    if(empty($d['display_name']))$d['display_name']=$d['name'];
    ensureDir(BD.'alldetails');wj(BD."alldetails/{$nid}.json",$d);
    appendNid(BD.'allappss.json',$nid);rotateNewSlots($d);
    $ok=createAppFolder($d['folder_name'],$nid,$d);
    flash($ok?"App added! NID:{$nid}":'App added but folder failed.','err');
    header('Location: '.SELF.'?tab=all_app');exit;
  }
  if($ac==='edit_all'){
    $nid=trim($_POST['nid']??'');if(!$nid){flash('NID missing.','err');header('Location: '.SELF.'?tab=manage');exit;}
    $ex=rj(BD."alldetails/{$nid}.json")??[];$oldFN=$ex['folder_name']??$ex['name']??'';
    $d=array_merge($ex,appDataFromPost($nid));
    if(empty($d['folder_name']))$d['folder_name']=$d['name'];
    if(empty($d['display_name']))$d['display_name']=$d['name'];
    $newFN=$d['folder_name'];wj(BD."alldetails/{$nid}.json",$d);
    if($oldFN&&$oldFN!==$newFN&&is_dir(BD.$oldFN))rename(BD.$oldFN,BD.$newFN);
    if(!is_dir(BD.$newFN))createAppFolder($newFN,$nid,$d);
    updateNameJson($newFN,$d,$nid);
    flash("App updated!");header('Location: '.SELF.'?tab=manage');exit;
  }
  if($ac==='del_all'){
    $nid=trim($_POST['nid']??'');$app=rj(BD."alldetails/{$nid}.json");$fn=$app['folder_name']??$app['name']??'';
    $f=BD."alldetails/{$nid}.json";if(file_exists($f))unlink($f);
    $e=rApps(BD.'allappss.json');wApps(BD.'allappss.json',array_values(array_filter($e,fn($x)=>$x['nid']!==$nid)));
    $pos=rj(BD.'alldetails/main_positions.json')??[];unset($pos[$nid]);wj(BD.'alldetails/main_positions.json',$pos);
    if($fn&&is_dir(BD.$fn)){$it=new RecursiveDirectoryIterator(BD.$fn,RecursiveDirectoryIterator::SKIP_DOTS);$files=new RecursiveIteratorIterator($it,RecursiveIteratorIterator::CHILD_FIRST);foreach($files as $file){$file->isDir()?rmdir($file->getRealPath()):unlink($file->getRealPath());}rmdir(BD.$fn);}
    flash("Deleted!",'err');header('Location: '.SELF.'?tab=manage');exit;
  }
  if($ac==='set_new_slot'){
    $sl=max(1,min(5,intval($_POST['slot']??5)));$nidRef=trim($_POST['nid_ref']??'');
    if($nidRef&&file_exists(BD."alldetails/{$nidRef}.json")){$d=rj(BD."alldetails/{$nidRef}.json");}
    else{$nm=trim($_POST['name']??'');$d=['nid'=>$nidRef,'name'=>$nm,'display_name'=>trim($_POST['display_name']??$nm),'folder_name'=>trim($_POST['folder_name']??$nm),'meta_title'=>'','meta_desc'=>'','page_tags'=>'','imglink'=>trim($_POST['imglink']??''),'applink'=>trim($_POST['applink']??''),'signbo'=>trim($_POST['signbo']??'0'),'mwith'=>trim($_POST['mwith']??'0'),'tag_text'=>trim($_POST['tag_text']??''),'tag_color'=>trim($_POST['tag_color']??'#22c55e'),'bigimglink'=>'','madd'=>'0','tdown'=>'0','refcoms'=>'','refperapro'=>'','gameidff'=>'','chanidv'=>''];}
    ensureDir(BD.'new');wj(BD."new/{$sl}.json",$d);flash("Slot {$sl} saved!");header('Location: '.SELF.'?tab=new_app');exit;
  }
  if($ac==='add_up'){
    $dir=BD.'alldetails4/';ensureDir($dir);$files=glob($dir.'d*.json');$ids=[];
    foreach($files??[] as $fi){if(preg_match('/d(\d+)\.json$/i',basename($fi),$m))$ids[]=(int)$m[1];}
    $nid=$ids?((string)(max($ids)+1)):'1';$nm=trim($_POST['name']??'');
    $d=['nid'=>$nid,'name'=>$nm,'display_name'=>trim($_POST['display_name']??$nm),'imglink'=>trim($_POST['imglink']??''),'applink'=>trim($_POST['applink']??''),'bigimglink'=>trim($_POST['bigimglink']??''),'signbo'=>trim($_POST['signbo']??'0'),'mwith'=>trim($_POST['mwith']??'0'),'tdown'=>'Coming Soon','launch_date'=>trim($_POST['launch_date']??''),'tag_text'=>trim($_POST['tag_text']??''),'tag_color'=>trim($_POST['tag_color']??'#3b82f6')];
    wj($dir."d{$nid}.json",$d);appendNid(BD.'allappss4.json',$nid);flash("Upcoming added!");header('Location: '.SELF.'?tab=upcoming');exit;
  }
  if($ac==='del_up'){$nid=trim($_POST['nid']??'');$f=BD."alldetails4/d{$nid}.json";if(file_exists($f))unlink($f);$e=rApps(BD.'allappss4.json');wApps(BD.'allappss4.json',array_values(array_filter($e,fn($x)=>$x['nid']!==$nid)));flash("Deleted!",'err');header('Location: '.SELF.'?tab=upcoming');exit;}
  if($ac==='edit_up'){
    $nid=trim($_POST['nid']??'');$ex=rj(BD."alldetails4/d{$nid}.json")??[];$nm=trim($_POST['name']??'');
    $d=array_merge($ex,['nid'=>$nid,'name'=>$nm,'display_name'=>trim($_POST['display_name']??$nm),'imglink'=>trim($_POST['imglink']??''),'applink'=>trim($_POST['applink']??''),'bigimglink'=>trim($_POST['bigimglink']??''),'signbo'=>trim($_POST['signbo']??'0'),'mwith'=>trim($_POST['mwith']??'0'),'tdown'=>trim($_POST['tdown']??'Coming Soon'),'launch_date'=>trim($_POST['launch_date']??''),'tag_text'=>trim($_POST['tag_text']??''),'tag_color'=>trim($_POST['tag_color']??'#3b82f6')]);
    wj(BD."alldetails4/d{$nid}.json",$d);flash("Updated!");header('Location: '.SELF.'?tab=upcoming');exit;
  }
  if($ac==='save_pos'){$pos=[];foreach(($_POST['pos']??[])as $n=>$v)$pos[$n]=intval($v);wj(BD.'alldetails/main_positions.json',$pos);flash("Positions saved!");header('Location: '.SELF.'?tab=positions');exit;}
  if($ac==='upd_tag'){
    $nid=trim($_POST['nid']??'');$d=rj(BD."alldetails/{$nid}.json");
    if($d){$d['tag_text']=trim($_POST['tag_text']??'');$d['tag_color']=trim($_POST['tag_color']??'#ef4444');wj(BD."alldetails/{$nid}.json",$d);$fn=$d['folder_name']??$d['name']??'';if($fn&&is_dir(BD.$fn))updateNameJson($fn,$d,$nid);flash("Tag updated!");}
    header('Location: '.SELF.'?tab=tags');exit;
  }
  if($ac==='save_homepage_seo'){
    ensureDir(BD.'alldetails');
    wj(BD.'alldetails/homepage_seo.json',['meta_title'=>trim($_POST['hp_meta_title']??''),'meta_desc'=>trim($_POST['hp_meta_desc']??''),'content_title'=>trim($_POST['hp_content_title']??''),'content_body'=>trim($_POST['hp_content_body']??'')]);
    flash("Homepage SEO saved!");header('Location: '.SELF.'?tab=homepage_seo');exit;
  }
  if($ac==='save_index_tags'){
    ensureDir(BD.'alldetails');wj(BD.'alldetails/index_tags.json',['label'=>trim($_POST['itlabel']??'Tags:'),'tags'=>trim($_POST['ittags']??'')]);
    flash("Tags bar saved!");header('Location: '.SELF.'?tab=index_tags');exit;
  }
  if($ac==='add_bonus'){$b=rj(BD.'alldetails/daily_bonus.json')??[];$b[]=['name'=>trim($_POST['bn']??''),'img'=>trim($_POST['bi']??''),'code'=>trim($_POST['bc']??''),'bonus'=>trim($_POST['ba']??''),'mwith'=>trim($_POST['bm']??''),'note'=>trim($_POST['bno']??'')];wj(BD.'alldetails/daily_bonus.json',$b);flash("Bonus added!");header('Location: '.SELF.'?tab=bonus');exit;}
  if($ac==='del_bonus'){$b=rj(BD.'alldetails/daily_bonus.json')??[];array_splice($b,intval($_POST['bi']),1);wj(BD.'alldetails/daily_bonus.json',$b);flash("Removed!",'err');header('Location: '.SELF.'?tab=bonus');exit;}
  if($ac==='clr_bonus'){wj(BD.'alldetails/daily_bonus.json',[]);flash("Cleared!",'err');header('Location: '.SELF.'?tab=bonus');exit;}
  if($ac==='save_ann'){wj(BD.'alldetails/announcement.json',['img_url'=>trim($_POST['ai']??''),'link_url'=>trim($_POST['al2']??''),'btn_text'=>trim($_POST['ab']??'Join Channel'),'enabled'=>isset($_POST['ae'])?1:0]);flash("Popup saved!");header('Location: '.SELF.'?tab=announcement');exit;}
  if($ac==='save_site'){wj(BD.'alldetails/site_settings.json',['site_name'=>trim($_POST['sn']??'YonoBestGame'),'telegram_url'=>trim($_POST['tg']??''),'whatsapp_url'=>trim($_POST['wa']??''),'apps_listed'=>trim($_POST['apl']??'50+')]);flash("Settings saved!");header('Location: '.SELF.'?tab=settings');exit;}
  if($ac==='chg_totp_step1'){
    if($rl_blocked){flash('Too many attempts.','err');header('Location: '.SELF.'?tab=settings');exit;}
    if(trim($_POST['cur_pass']??'')!==ADMIN_PASS){rlAdd($rlf,$rl);flash('Wrong password.','err');header('Location: '.SELF.'?tab=settings#chg-totp');exit;}
    if(!tverify($TC['secret'],trim($_POST['cur_totp']??''))){rlAdd($rlf,$rl);flash('Wrong current code.','err');header('Location: '.SELF.'?tab=settings#chg-totp');exit;}
    $newSec=tnew();$_SESSION['chg_totp_pending']=$newSec;flash('Verified! Scan new QR.','ok');header('Location: '.SELF.'?tab=settings&chg_step=2#chg-totp');exit;
  }
  if($ac==='chg_totp_step2'){
    $pending=$_SESSION['chg_totp_pending']??'';
    if(!$pending){flash('Session expired.','err');header('Location: '.SELF.'?tab=settings#chg-totp');exit;}
    if(!tverify($pending,trim($_POST['new_totp']??''))){rlAdd($rlf,$rl);flash('Wrong new code.','err');header('Location: '.SELF.'?tab=settings&chg_step=2#chg-totp');exit;}
    saveT(['secret'=>$pending,'verified'=>true]);unset($_SESSION['chg_totp_pending']);flash('Authenticator updated!','ok');header('Location: '.SELF.'?tab=settings');exit;
  }
  if($ac==='chg_totp_cancel'){unset($_SESSION['chg_totp_pending']);flash('Cancelled.','ok');header('Location: '.SELF.'?tab=settings');exit;}
  if($ac==='bulk_import'){
    $isAjax=!empty($_POST['ajax'])||(isset($_SERVER['HTTP_X_REQUESTED_WITH'])&&strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])==='xmlhttprequest');
    $mode=$_POST['import_mode']??'skip';$uploads=$_FILES['json_files']??null;
    if(empty($uploads)||empty(array_filter((array)($uploads['name']??[])))){if($isAjax){ob_clean();header('Content-Type: application/json');echo json_encode(['added'=>0,'updated'=>0,'skipped'=>0,'errors'=>1,'error_list'=>['No files']]);exit;}flash('No files.','err');header('Location: '.SELF.'?tab=bulk_import');exit;}
    $added=0;$updated=0;$skipped=0;$errors=[];ensureDir(BD.'alldetails');
    $total=count($uploads['name']);$realCount=0;$existingNids=array_column(rApps(BD.'allappss.json'),'nid');
    for($fi=0;$fi<$total;$fi++){
      $fname=basename($uploads['name'][$fi]??'');$ferr=$uploads['error'][$fi]??4;$ftmp=$uploads['tmp_name'][$fi]??'';
      if(empty($fname)||$ferr===UPLOAD_ERR_NO_FILE)continue;$realCount++;
      if($ferr!==UPLOAD_ERR_OK){$errors[]="$fname: upload error";continue;}
      if(strtolower(pathinfo($fname,PATHINFO_EXTENSION))!=='json'){$errors[]="$fname: not .json";continue;}
      $raw=@file_get_contents($ftmp);if(!$raw){$errors[]="$fname: empty";continue;}
      $item=json_decode($raw,true);if(json_last_error()!==JSON_ERROR_NONE){$errors[]="$fname: invalid JSON";continue;}
      if(is_array($item)&&isset($item[0])&&is_array($item[0]))$item=$item[0];
      if(!is_array($item)){$errors[]="$fname: not object";continue;}
      $nm=trim($item['name']??'');if($nm===''){$errors[]="$fname: missing name";continue;}
      $fileNid=trim((string)($item['nid']??''));$nidInSystem=$fileNid!==''&&in_array($fileNid,$existingNids);
      if($nidInSystem&&$mode==='skip'){$skipped++;continue;}
      if($fileNid!==''){$nid=$fileNid;bumpSeriesIfNeeded($nid);}else{$nid=getNextNid();}
      $fn=trim($item['folder_name']??$nm);if(empty($fn))$fn=$nm;
      $data=['nid'=>$nid,'name'=>$nm,'display_name'=>trim($item['display_name']??$nm),'folder_name'=>$fn,'meta_title'=>trim($item['meta_title']??''),'meta_desc'=>trim($item['meta_desc']??''),'page_tags'=>trim($item['page_tags']??''),'imglink'=>trim($item['imglink']??''),'applink'=>trim($item['applink']??''),'bigimglink'=>trim($item['bigimglink']??''),'signbo'=>trim($item['signbo']??'0'),'mwith'=>trim($item['mwith']??'0'),'madd'=>trim($item['madd']??'0'),'tdown'=>trim($item['tdown']??'0'),'refcoms'=>trim($item['refcoms']??''),'refperapro'=>trim($item['refperapro']??''),'gameidff'=>trim($item['gameidff']??''),'chanidv'=>trim($item['chanidv']??''),'tag_text'=>trim($item['tag_text']??''),'tag_color'=>trim($item['tag_color']??'#e3232c')];
      wj(BD."alldetails/{$nid}.json",$data);
      if(!$nidInSystem){appendNid(BD.'allappss.json',$nid);$existingNids[]=$nid;createAppFolder($fn,$nid,$data);$added++;}
      else{$oldFn=$item['folder_name']??$item['name']??$fn;if($oldFn&&$oldFn!==$fn&&is_dir(BD.$oldFn))rename(BD.$oldFn,BD.$fn);if(!is_dir(BD.$fn))createAppFolder($fn,$nid,$data);else updateNameJson($fn,$data,$nid);$updated++;}
    }
    if($isAjax){ob_clean();header('Content-Type: application/json');echo json_encode(['added'=>$added,'updated'=>$updated,'skipped'=>$skipped,'errors'=>count($errors),'error_list'=>$errors,'total'=>$realCount]);exit;}
    $msg="Done — {$realCount} files. Added:{$added}";if($updated)$msg.=" Updated:{$updated}";if($skipped)$msg.=" Skipped:{$skipped}";if($errors)$msg.=" Errors:".count($errors);
    $_SESSION['bulk_errors']=$errors;$_SESSION['bulk_stats']=['total'=>$realCount,'added'=>$added,'updated'=>$updated,'skipped'=>$skipped,'errors'=>count($errors)];
    flash($msg,($added===0&&$updated===0&&count($errors)>0)?'err':'ok');header('Location: '.SELF.'?tab=bulk_import');exit;
  }
}

$allApps=[];$mpos=rj(BD.'alldetails/main_positions.json')??[];
foreach(rApps(BD.'allappss.json')as $e){$d=rj(BD."alldetails/{$e['nid']}.json");if($d){$d['pos']=$mpos[$d['nid']]??999;$allApps[]=$d;}}
usort($allApps,fn($a,$b)=>$a['pos']<=>$b['pos']);
$upcoming=[];foreach(rApps(BD.'allappss4.json')as $e){$d=rj(BD."alldetails4/d{$e['nid']}.json");if($d)$upcoming[]=$d;}
$newSlots=[];for($i=1;$i<=5;$i++)$newSlots[$i]=rj(BD."new/{$i}.json");
$bonuses=rj(BD.'alldetails/daily_bonus.json')??[];
$ann=rj(BD.'alldetails/announcement.json')??['img_url'=>'','link_url'=>'https://t.me/+FG0xq_lZH88zODI1','btn_text'=>'Join Channel','enabled'=>1];
$site=rj(BD.'alldetails/site_settings.json')??['site_name'=>'YonoBestGame','telegram_url'=>'https://t.me/+FG0xq_lZH88zODI1','whatsapp_url'=>'','apps_listed'=>'50+'];
$index_tags=rj(BD.'alldetails/index_tags.json')??['label'=>'Tags:','tags'=>'Yono Apps, yono rummy, yono arcade, yono 777, rummy'];
$homepage_seo=rj(BD.'alldetails/homepage_seo.json')??['meta_title'=>'IndYonoGames - Download All Rs51 To Rs500 Bonus App And New Yono Rummy Apps','meta_desc'=>'IndYonoGames - Download All Yono Rummy App And Get Rs500 To Rs1500 Sign Up Bonus. Min Withdrawal Rs100','content_title'=>'Yono Best Games — India\'s Biggest Yono App Downloading Platform','content_body'=>'Yono Best Games is a trusted platform where players can discover a huge collection of real money gaming apps.'];
$fl=gFlash();$tab=$_GET['tab']??'dashboard';
$days_left=$logged_in?max(0,SESSION_DAYS-floor((time()-($_SESSION['ayg_ts']??time()))/86400)):0;
$bulk_errors=$_SESSION['bulk_errors']??[];unset($_SESSION['bulk_errors']);
$bulk_stats=$_SESSION['bulk_stats']??null;unset($_SESSION['bulk_stats']);
$nextNid=peekNextNid();
$editUpNid=$_GET['edit_up']??null;$editUpApp=$editUpNid?rj(BD."alldetails4/d{$editUpNid}.json"):null;
$editNid=$_GET['edit']??null;$editApp=$editNid?rj(BD."alldetails/{$editNid}.json"):null;
$chg_step=intval($_GET['chg_step']??0);$chg_pending=$_SESSION['chg_totp_pending']??'';
if(!file_exists(BD.'page.php'))file_put_contents(BD.'page.php','<?php header("Location: ../index.php");exit;');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>YonoBestGame Admin v4.5</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Space+Grotesk:wght@600;700;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
:root{--gold:#e8b84b;--g3:#c9922a;--g1:#b07d1e;--grad:linear-gradient(135deg,#b07d1e,#e8b84b 55%,#c9922a);--bg:#06060f;--bg1:#0c0c1a;--bg2:#111127;--bg3:#16162e;--card:#141428;--card2:#1a1a34;--t1:#f0e8d0;--t2:#9a8870;--t3:#5c5040;--b1:rgba(232,184,75,.1);--b2:rgba(232,184,75,.22);--b3:rgba(232,184,75,.4);--green:#10b981;--green2:#34d399;--red:#ef4444;--red2:#fca5a5;--blue:#6366f1;--blue2:#a5b4fc;--cyan:#06b6d4;--cyan2:#67e8f9;--purple:#a855f7;--orange:#f59e0b;--sw:272px;--r:14px;}
html,body{height:100%;}
body{background:var(--bg);color:var(--t1);font-family:'Inter',system-ui,sans-serif;min-height:100vh;overflow-x:hidden;}
::-webkit-scrollbar{width:4px;height:4px;}::-webkit-scrollbar-track{background:var(--bg1);}::-webkit-scrollbar-thumb{background:var(--g3);border-radius:99px;}
.auth-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;position:relative;z-index:1;}
.auth-box{width:100%;max-width:430px;animation:aIn .5s cubic-bezier(.16,1,.3,1);}
@keyframes aIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
.auth-card{background:rgba(20,20,40,.9);backdrop-filter:blur(28px);border:1px solid var(--b2);border-radius:22px;padding:34px 30px 28px;box-shadow:0 40px 80px rgba(0,0,0,.7);}
.abrand{display:flex;align-items:center;gap:14px;margin-bottom:24px;}
.alogo{width:54px;height:54px;border-radius:16px;border:2px solid var(--b3);padding:3px;background:linear-gradient(135deg,var(--bg2),var(--card2));flex-shrink:0;}
.alogo img{width:100%;height:100%;border-radius:12px;object-fit:cover;display:block;}
.abrand-name{font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:800;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.abrand-sub{font-size:11px;color:var(--t3);margin-top:3px;}
.atitle{font-size:22px;font-weight:800;color:var(--t1);margin-bottom:4px;font-family:'Space Grotesk',sans-serif;}
.asub{font-size:13px;color:var(--t2);margin-bottom:20px;line-height:1.55;}
.ig{position:relative;margin-bottom:11px;}
.ig .ic{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--t3);font-size:14px;pointer-events:none;z-index:2;}
.ainp{width:100%;background:var(--bg2);border:1.5px solid var(--b1);border-radius:11px;padding:12px 14px 12px 42px;color:var(--t1);font-size:14px;outline:none;transition:all .2s;-webkit-appearance:none;}
.ainp::placeholder{color:var(--t3);}.ainp:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(232,184,75,.1);background:var(--bg3);}
.ainp.otp{padding:13px;text-align:center;letter-spacing:10px;font-size:26px;font-weight:900;font-family:'Space Grotesk',monospace;}
.eyebtn{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--t3);cursor:pointer;font-size:14px;padding:5px;z-index:2;}
.eyebtn:hover{color:var(--gold);}
.ilbl{font-size:10px;font-weight:800;color:var(--t2);text-transform:uppercase;letter-spacing:.7px;margin-bottom:6px;display:block;}
.adivider{display:flex;align-items:center;gap:10px;margin:13px 0;color:var(--t3);font-size:11px;}
.adivider::before,.adivider::after{content:'';flex:1;height:1px;background:var(--b1);}
.abtn{width:100%;background:var(--grad);color:#1a0d00;font-weight:800;font-size:15px;padding:13px;border:none;border-radius:11px;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:9px;margin-top:8px;}
.abtn:hover{filter:brightness(1.08);transform:translateY(-1px);}
.aerr{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#fca5a5;padding:11px 14px;border-radius:10px;font-size:13px;font-weight:600;margin-bottom:13px;display:flex;align-items:center;gap:9px;}
.ablocked{background:rgba(239,68,68,.1);border:1.5px solid rgba(239,68,68,.25);color:#fca5a5;padding:18px;border-radius:12px;text-align:center;font-weight:700;font-size:13px;line-height:1.7;}
.asess{display:flex;align-items:center;gap:7px;background:rgba(232,184,75,.06);border:1px solid var(--b1);border-radius:10px;padding:9px 13px;font-size:11px;color:var(--t2);margin-top:11px;}
.afoot{text-align:center;font-size:11px;color:var(--t3);margin-top:15px;}
.sstep{display:flex;gap:13px;margin-bottom:13px;align-items:flex-start;}
.snum{width:27px;height:27px;border-radius:50%;background:var(--grad);color:#1a0d00;font-size:12px;font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.stxt{font-size:13px;color:var(--t2);line-height:1.6;padding-top:4px;}.stxt strong{color:var(--t1);}
.qrwrap{background:#fff;border-radius:16px;padding:13px;display:inline-block;margin:10px 0;}
.qrwrap img{display:block;width:240px;height:240px;}
.secbox{background:var(--bg2);border:1.5px dashed var(--b3);border-radius:11px;padding:11px 16px;font-family:'Space Grotesk',monospace;font-size:13px;letter-spacing:4px;color:var(--gold);text-align:center;word-break:break-all;margin:10px 0 4px;cursor:pointer;}
.cpyhint{font-size:10px;color:var(--t3);text-align:center;margin-bottom:13px;}
.layout{display:flex;min-height:100vh;position:relative;z-index:1;}
.sb{width:var(--sw);background:linear-gradient(180deg,var(--bg1),rgba(8,8,20,1));border-right:1px solid var(--b1);position:fixed;top:0;left:0;height:100vh;display:flex;flex-direction:column;overflow-y:auto;overflow-x:hidden;z-index:300;transition:transform .3s cubic-bezier(.25,.46,.45,.94);}
.sb-ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:299;opacity:0;transition:opacity .3s;}
.sb-top{padding:17px 13px 13px;border-bottom:1px solid var(--b1);flex-shrink:0;}
.sbbrand{display:flex;align-items:center;gap:10px;}
.sblogo{width:40px;height:40px;border-radius:12px;object-fit:cover;border:2px solid var(--b3);flex-shrink:0;}
.sbname{font-family:'Space Grotesk',sans-serif;font-size:14px;font-weight:800;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.sbver{font-size:10px;color:var(--t3);margin-top:2px;}
.sbsess{margin-top:9px;display:flex;align-items:center;gap:7px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.15);border-radius:9px;padding:7px 10px;font-size:11px;color:rgba(52,211,153,.85);font-weight:600;}
.sbnav{flex:1;padding:8px 8px 10px;overflow-y:auto;}
.nbs{font-size:9px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;color:var(--t3);padding:15px 10px 5px;}
.nbs:first-child{padding-top:8px;}
.na{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:10px;color:var(--t2);font-size:13px;font-weight:600;transition:all .15s;margin-bottom:2px;border:1px solid transparent;white-space:nowrap;position:relative;text-decoration:none;}
.na .ni{width:20px;height:20px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:11px;flex-shrink:0;background:rgba(255,255,255,.04);}
.na:hover{background:rgba(232,184,75,.08);color:var(--gold);border-color:var(--b1);}
.na:hover .ni{background:rgba(232,184,75,.14);color:var(--gold);}
.na.on{background:linear-gradient(135deg,rgba(232,184,75,.14),rgba(201,146,42,.05));color:var(--gold);border-color:var(--b2);}
.na.on .ni{background:rgba(232,184,75,.18);color:var(--gold);}
.na.on::before{content:'';position:absolute;left:0;top:22%;bottom:22%;width:3px;background:var(--grad);border-radius:0 3px 3px 0;}
.na-c:hover,.na-c.on{color:var(--cyan2)!important;}
.na-c.on{background:linear-gradient(135deg,rgba(6,182,212,.11),rgba(6,182,212,.02))!important;border-color:rgba(6,182,212,.22)!important;}
.na-c.on::before{background:linear-gradient(135deg,#0891b2,#06b6d4)!important;}
.na-red:hover,.na-red.on{color:var(--red2)!important;}
.na-red.on{background:linear-gradient(135deg,rgba(239,68,68,.11),rgba(239,68,68,.02))!important;border-color:rgba(239,68,68,.22)!important;}
.na-red.on::before{background:linear-gradient(135deg,#dc2626,#ef4444)!important;}
.na-grn:hover,.na-grn.on{color:var(--green2)!important;}
.na-grn.on{background:linear-gradient(135deg,rgba(16,185,129,.11),rgba(16,185,129,.02))!important;border-color:rgba(16,185,129,.22)!important;}
.na-grn.on::before{background:linear-gradient(135deg,#059669,#10b981)!important;}
.nbadge{margin-left:auto;background:var(--red);color:#fff;font-size:9px;font-weight:900;min-width:17px;height:17px;border-radius:99px;display:flex;align-items:center;justify-content:center;padding:0 5px;flex-shrink:0;}
.nbadge-c{background:var(--cyan);color:#001a20;}
.sbft{padding:9px 8px;border-top:1px solid var(--b1);flex-shrink:0;}
.sbft a{display:flex;align-items:center;gap:9px;font-size:13px;color:var(--t2);padding:9px 10px;border-radius:10px;transition:all .15s;border:1px solid transparent;text-decoration:none;}
.sbft a:hover{color:var(--red2);background:rgba(239,68,68,.08);}
.mn{margin-left:var(--sw);flex:1;display:flex;flex-direction:column;min-height:100vh;min-width:0;}
.tb{background:rgba(8,8,20,.88);backdrop-filter:blur(22px);border-bottom:1px solid var(--b1);padding:0 18px;height:58px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:200;gap:12px;}
.tb-l{display:flex;align-items:center;gap:10px;flex:1;min-width:0;}
.ham{display:none;background:none;border:none;color:var(--t2);font-size:17px;cursor:pointer;width:34px;height:34px;border-radius:8px;align-items:center;justify-content:center;flex-shrink:0;}
.ham:hover{background:var(--b1);color:var(--gold);}
.tbpage{font-size:14px;font-weight:700;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.tb-r{display:flex;align-items:center;gap:8px;flex-shrink:0;}
.livepill{display:flex;align-items:center;gap:6px;background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.18);color:var(--green2);padding:5px 11px;border-radius:99px;font-size:11px;font-weight:700;}
.ldot{width:7px;height:7px;border-radius:50%;background:var(--green2);animation:lp 1.8s infinite;flex-shrink:0;}
@keyframes lp{0%{box-shadow:0 0 0 0 rgba(52,211,153,.7)}70%{box-shadow:0 0 0 7px rgba(52,211,153,0)}100%{box-shadow:0 0 0 0 rgba(52,211,153,0)}}
.ct{padding:18px;flex:1;animation:pgIn .36s cubic-bezier(.16,1,.3,1);}
@keyframes pgIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.flash-msg{padding:11px 15px;border-radius:11px;font-weight:700;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:9px;}
.flash-ok{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.24);color:var(--green2);}
.flash-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.24);color:var(--red2);}
.nid-auto-badge{display:inline-flex;align-items:center;gap:10px;background:linear-gradient(135deg,rgba(232,184,75,.12),rgba(201,146,42,.04));border:1px solid var(--b2);border-radius:12px;padding:11px 16px;margin-bottom:16px;width:100%;}
.nid-auto-icon{width:36px;height:36px;border-radius:10px;background:var(--grad);display:flex;align-items:center;justify-content:center;color:#1a0d00;font-size:14px;flex-shrink:0;}
.nid-auto-num{font-size:20px;font-weight:900;color:var(--gold);font-family:'Space Grotesk',monospace;}
.nid-auto-lbl{font-size:10px;color:var(--t2);font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-top:2px;}
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:11px;margin-bottom:18px;}
.sc{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);padding:16px 14px;position:relative;overflow:hidden;transition:transform .2s;}
.sc:hover{transform:translateY(-3px);}
.sc::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:var(--r) var(--r) 0 0;}
.sc-g::before{background:var(--grad);}.sc-gr::before{background:linear-gradient(90deg,#059669,#10b981);}
.sc-b::before{background:linear-gradient(90deg,#4f46e5,#6366f1);}.sc-p::before{background:linear-gradient(90deg,#7c3aed,#a855f7);}
.sc-r::before{background:linear-gradient(90deg,#dc2626,#ef4444);}
.sic{width:38px;height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:.95rem;margin-bottom:11px;}
.sc-g .sic{background:rgba(232,184,75,.13);color:var(--gold);}.sc-gr .sic{background:rgba(16,185,129,.11);color:var(--green2);}
.sc-b .sic{background:rgba(99,102,241,.1);color:var(--blue2);}.sc-p .sic{background:rgba(168,85,247,.1);color:#d8b4fe;}
.sc-r .sic{background:rgba(239,68,68,.1);color:var(--red2);}
.sv{font-size:25px;font-weight:900;color:var(--t1);font-family:'Space Grotesk',sans-serif;line-height:1.1;}
.sl{font-size:11px;color:var(--t2);font-weight:600;margin-top:3px;}
.qg{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:9px;margin-bottom:20px;}
.qa{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);padding:14px 10px 12px;text-align:center;display:block;transition:all .18s;text-decoration:none;}
.qa:hover{border-color:var(--b3);transform:translateY(-3px);}
.qa-i{font-size:1.6rem;margin-bottom:6px;display:block;}
.qa-l{font-size:11px;font-weight:700;color:var(--t2);}.qa:hover .qa-l{color:var(--gold);}
.pc{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);overflow:hidden;margin-bottom:16px;}
.ph{padding:12px 16px;background:linear-gradient(135deg,rgba(232,184,75,.09),rgba(201,146,42,.02));border-bottom:1px solid var(--b1);font-weight:800;font-size:13px;display:flex;align-items:center;gap:8px;color:var(--gold);}
.ph i{width:16px;text-align:center;}.ph-r{margin-left:auto;display:flex;align-items:center;gap:7px;}
.pb{padding:17px;}
.fg{display:grid;grid-template-columns:repeat(auto-fill,minmax(192px,1fr));gap:12px;}
.fgr{display:flex;flex-direction:column;gap:5px;}
.flb{font-size:10px;font-weight:800;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;}
.fc{background:var(--bg2);border:1.5px solid var(--b1);border-radius:10px;padding:10px 12px;color:var(--t1);font-size:13px;outline:none;transition:all .18s;width:100%;-webkit-appearance:none;}
.fc::placeholder{color:var(--t3);}.fc:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(232,184,75,.09);background:var(--bg3);}
.fc option{background:var(--bg2);}.fc-col{height:42px;padding:4px 7px;cursor:pointer;}
.fhint{font-size:10px;color:var(--t3);line-height:1.4;}
.new-section-hdr{background:linear-gradient(135deg,rgba(6,182,212,.09),rgba(6,182,212,.02));border:1px solid rgba(6,182,212,.2);border-radius:10px;padding:9px 13px;font-size:11px;font-weight:800;color:var(--cyan2);display:flex;align-items:center;gap:8px;margin:14px 0 10px;}
.red-section-hdr{background:linear-gradient(135deg,rgba(239,68,68,.09),rgba(239,68,68,.02));border:1px solid rgba(239,68,68,.22);border-radius:10px;padding:9px 13px;font-size:11px;font-weight:800;color:var(--red2);display:flex;align-items:center;gap:8px;margin:14px 0 10px;}
.grn-section-hdr{background:linear-gradient(135deg,rgba(16,185,129,.09),rgba(16,185,129,.02));border:1px solid rgba(16,185,129,.22);border-radius:10px;padding:9px 13px;font-size:11px;font-weight:800;color:var(--green2);display:flex;align-items:center;gap:8px;margin:14px 0 10px;}
.fc-cyan{border-color:rgba(6,182,212,.25);}.fc-cyan:focus{border-color:var(--cyan2);box-shadow:0 0 0 3px rgba(6,182,212,.09);}
.fc-red{border-color:rgba(239,68,68,.25);}.fc-red:focus{border-color:var(--red2);}
.fc-grn{border-color:rgba(16,185,129,.25);}.fc-grn:focus{border-color:var(--green2);}
.flb-cyan{color:var(--cyan2);}.flb-red{color:var(--red2);}.flb-grn{color:var(--green2);}
.btn{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:9px;font-weight:700;font-size:13px;cursor:pointer;border:none;transition:all .15s;white-space:nowrap;text-decoration:none;}
.btn-g{background:var(--grad);color:#1a0d00;}.btn-g:hover{filter:brightness(1.08);transform:translateY(-1px);}
.btn-r{background:rgba(239,68,68,.1);color:var(--red2);border:1px solid rgba(239,68,68,.2);}.btn-r:hover{background:var(--red);color:#fff;}
.btn-gh{background:rgba(255,255,255,.05);color:var(--t2);border:1px solid var(--b1);}.btn-gh:hover{color:var(--t1);}
.btn-c{background:linear-gradient(135deg,#0891b2,#06b6d4);color:#001a20;}.btn-c:hover{filter:brightness(1.08);}
.btn-grn{background:linear-gradient(135deg,#059669,#10b981);color:#fff;}.btn-grn:hover{filter:brightness(1.08);transform:translateY(-1px);}
.btn-pu{background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;}.btn-pu:hover{filter:brightness(1.08);}
.btn-sm{padding:7px 12px;font-size:12px;}.btn-xs{padding:5px 9px;font-size:11px;border-radius:7px;}
.tw{overflow-x:auto;}.tbl{width:100%;border-collapse:collapse;min-width:480px;}
.tbl th{background:var(--bg2);color:var(--t2);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.6px;padding:9px 12px;border-bottom:1px solid var(--b1);text-align:left;white-space:nowrap;}
.tbl td{padding:9px 12px;border-bottom:1px solid rgba(232,184,75,.04);font-size:13px;vertical-align:middle;}
.tbl tr:last-child td{border-bottom:none;}.tbl tbody tr:hover td{background:rgba(232,184,75,.03);}
.tim{width:38px;height:38px;border-radius:9px;object-fit:cover;border:1.5px solid var(--b1);flex-shrink:0;}
.tb2{display:inline-block;padding:3px 8px;border-radius:99px;font-size:10px;font-weight:800;text-transform:uppercase;color:#fff;}
.notag{color:var(--t3);font-size:11px;font-style:italic;}
.tprow{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0 3px;}
.tpb{padding:5px 10px;border-radius:99px;font-size:11px;font-weight:800;cursor:pointer;border:none;color:#fff;transition:all .15s;font-family:inherit;}
.tpb:hover{transform:scale(1.07);}
.slotg{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:16px;}
.slotc{background:var(--card2);border:1.5px solid var(--b1);border-radius:12px;padding:11px 8px;text-align:center;}
.slotc.full{border-color:var(--b3);}
.slotc img{width:46px;height:46px;border-radius:10px;object-fit:cover;border:2px solid var(--b2);margin-bottom:7px;}
.slotn{font-size:9px;font-weight:800;color:var(--t3);text-transform:uppercase;letter-spacing:.6px;margin-bottom:4px;}
.slotnm{font-size:11px;font-weight:700;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.slotem{font-size:10px;color:var(--t3);font-style:italic;margin-top:3px;}
.slotbo{font-size:10px;color:var(--red2);font-weight:700;margin-top:2px;}
.poslist{display:flex;flex-direction:column;gap:6px;}
.positem{background:var(--card2);border:1px solid var(--b1);border-radius:11px;padding:9px 12px;display:flex;align-items:center;gap:9px;}
.poshdl{color:var(--t3);font-size:13px;cursor:grab;}
.posim{width:33px;height:33px;border-radius:8px;object-fit:cover;border:1.5px solid var(--b1);flex-shrink:0;}
.posnm{flex:1;font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.posinp{width:58px;background:var(--card);border:1.5px solid var(--b1);border-radius:8px;padding:6px 8px;color:var(--t1);font-size:13px;text-align:center;outline:none;font-family:inherit;}
.posinp:focus{border-color:var(--gold);}
.togw{display:flex;align-items:center;gap:10px;}
.tog{position:relative;width:44px;height:24px;flex-shrink:0;}.tog input{opacity:0;width:0;height:0;position:absolute;}
.togsl{position:absolute;inset:0;background:rgba(255,255,255,.07);border-radius:24px;cursor:pointer;transition:.24s;border:1px solid var(--b1);}
.togsl::before{content:'';position:absolute;width:18px;height:18px;left:2px;bottom:2px;background:#fff;border-radius:50%;transition:.24s;}
.tog input:checked+.togsl{background:var(--green);border-color:var(--green);}
.tog input:checked+.togsl::before{transform:translateX(20px);}
.togl{font-size:13px;font-weight:600;color:var(--t2);}
.tags-preview-bar{display:flex;align-items:center;background:var(--bg1);border:1px solid var(--b2);border-radius:11px;overflow:hidden;margin-top:12px;}
.tags-preview-label{flex-shrink:0;background:var(--grad);color:#1a0d00;font-size:9px;font-weight:900;letter-spacing:.8px;text-transform:uppercase;padding:8px 12px;white-space:nowrap;}
.tags-preview-scroll{display:flex;align-items:center;gap:6px;overflow-x:auto;padding:6px 10px;scrollbar-width:none;}
.tags-preview-scroll::-webkit-scrollbar{display:none;}
.tpill{display:inline-flex;align-items:center;gap:4px;background:rgba(232,184,75,.08);border:1.5px solid var(--b2);border-radius:999px;padding:3px 10px;font-size:10px;font-weight:700;color:var(--gold);white-space:nowrap;flex-shrink:0;}
.tpill i{font-size:8px;opacity:.6;}
.seo-preview-card{background:var(--bg2);border:1px solid var(--b1);border-radius:12px;padding:14px 16px;margin-top:12px;}
.seo-prev-url{font-size:11px;color:var(--green2);margin-bottom:4px;}
.seo-prev-title{font-size:14px;font-weight:800;color:#8ab4f8;margin-bottom:6px;line-height:1.35;}
.seo-prev-desc{font-size:12px;color:var(--t2);line-height:1.65;}
.dropzone{border:2px dashed rgba(6,182,212,.3);border-radius:15px;padding:38px 22px;text-align:center;cursor:pointer;transition:all .2s;background:rgba(6,182,212,.03);position:relative;overflow:hidden;}
.dropzone:hover,.dropzone.drag{border-color:var(--cyan2);background:rgba(6,182,212,.07);}
.dropzone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.dz-icon{font-size:2.8rem;margin-bottom:12px;display:block;}
.dz-title{font-size:15px;font-weight:800;color:var(--cyan2);margin-bottom:5px;}
.dz-sub{font-size:13px;color:var(--t2);}
.fcbar{display:flex;align-items:center;justify-content:space-between;background:rgba(6,182,212,.07);border:1px solid rgba(6,182,212,.18);border-radius:11px;padding:10px 14px;margin-top:12px;}
.fcbar-n{font-size:20px;font-weight:900;color:var(--cyan2);font-family:'Space Grotesk',sans-serif;}
.flist{margin-top:9px;display:flex;flex-direction:column;gap:4px;max-height:260px;overflow-y:auto;}
.fi{display:flex;align-items:center;gap:8px;background:rgba(6,182,212,.06);border:1px solid rgba(6,182,212,.16);border-radius:9px;padding:8px 11px;}
.fi-bad{background:rgba(239,68,68,.06);border-color:rgba(239,68,68,.18);}
.fi-ic{font-size:13px;flex-shrink:0;}.fi-nm{flex:1;font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.fi-sz{font-size:10px;color:var(--t3);flex-shrink:0;}
.fi-rm{background:none;border:none;color:var(--t3);cursor:pointer;font-size:11px;padding:3px 6px;border-radius:5px;transition:all .13s;flex-shrink:0;}
.fi-rm:hover{background:rgba(239,68,68,.15);color:var(--red2);}
.irs-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;}
.irs{border-radius:11px;padding:13px 9px;text-align:center;}
.irs-n{font-size:22px;font-weight:900;font-family:'Space Grotesk',sans-serif;}
.irs-l{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-top:4px;color:var(--t2);}
.irs-gr{background:rgba(16,185,129,.09);border:1px solid rgba(16,185,129,.2);}.irs-gr .irs-n{color:var(--green2);}
.irs-bl{background:rgba(99,102,241,.09);border:1px solid rgba(99,102,241,.2);}.irs-bl .irs-n{color:var(--blue2);}
.irs-go{background:rgba(232,184,75,.07);border:1px solid var(--b2);}.irs-go .irs-n{color:var(--gold);}
.irs-re{background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.18);}.irs-re .irs-n{color:var(--red2);}
.import-log{display:flex;flex-direction:column;gap:4px;max-height:300px;overflow-y:auto;margin-top:10px;}
.import-row{display:flex;align-items:center;gap:8px;padding:7px 11px;border-radius:9px;font-size:12px;font-weight:600;}
.import-row.err{background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.18);color:var(--red2);}
.div{height:1px;background:var(--b1);margin:14px 0;}
.df{display:flex;align-items:center;gap:7px;flex-wrap:wrap;}
.cg{color:var(--gold);}.cgr{color:var(--green2);}.cr{color:var(--red2);}.cm{color:var(--t2);}
.fw8{font-weight:800;}.mb14{margin-bottom:14px;}.mt12{margin-top:12px;}
.empty{text-align:center;padding:38px 18px;color:var(--t2);}.empty i{font-size:2.2rem;display:block;margin-bottom:10px;opacity:.16;}
code{background:var(--bg2);padding:2px 7px;border-radius:5px;font-size:11px;color:var(--gold);font-family:'Space Grotesk',monospace;border:1px solid var(--b1);}
.infob{background:rgba(99,102,241,.07);border:1px solid rgba(99,102,241,.16);border-radius:10px;padding:12px 14px;font-size:12px;color:#c7d2fe;line-height:1.6;}
.rotatebadge{background:rgba(232,184,75,.1);border:1px solid var(--b2);border-radius:9px;padding:9px 13px;font-size:12px;color:var(--gold);line-height:1.6;margin-bottom:14px;}
.mobnav{display:none;position:fixed;bottom:0;left:0;right:0;background:rgba(8,8,20,.96);backdrop-filter:blur(20px);border-top:1px solid var(--b1);z-index:400;padding:5px 0 max(5px,env(safe-area-inset-bottom));}
.mni-row{display:flex;justify-content:space-around;}
.mni{display:flex;flex-direction:column;align-items:center;gap:3px;padding:5px 7px;color:var(--t3);font-size:9px;font-weight:700;text-decoration:none;transition:color .15s;min-width:42px;}
.mni i{font-size:15px;}.mni.on,.mni:hover{color:var(--gold);}
@media(max-width:960px){.sb{transform:translateX(calc(-1 * var(--sw)));}.sb.on{transform:translateX(0);box-shadow:8px 0 50px rgba(0,0,0,.8);}.sb-ov.on{display:block;opacity:1;}.mn{margin-left:0;}.ham{display:flex;}.mobnav{display:block;}.ct{padding-bottom:78px;}}
@media(max-width:640px){.sg{grid-template-columns:1fr 1fr;}.slotg{grid-template-columns:repeat(3,1fr);}.fg{grid-template-columns:1fr;}.irs-grid{grid-template-columns:1fr 1fr;}.auth-card{padding:24px 16px 20px;}}
@media(max-width:480px){.ct{padding:11px 10px;}.slotg{grid-template-columns:repeat(2,1fr);}}
</style>
</head>
<body>
<?php if($setup): $sec=$TC['secret']??''; ?>
<div class="auth-page"><div class="auth-box"><div class="auth-card">
  <div class="abrand"><div class="alogo"><img src="logo.jpg" onerror="this.parentElement.innerHTML='<div style=\'width:48px;height:48px;background:var(--grad);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;\'>&#127918;</div>'"></div>
  <div><div class="abrand-name">YonoBestGame</div><div class="abrand-sub">First-Time Security Setup</div></div></div>
  <?php if($setup_step===1): ?>
    <div class="atitle">Set Up 2-Factor Auth</div>
    <div class="asub">Set up Google Authenticator before using the admin panel.</div>
    <div style="margin:12px 0 18px;">
      <div class="sstep"><div class="snum">1</div><div class="stxt">Download <strong>Google Authenticator</strong></div></div>
      <div class="sstep"><div class="snum">2</div><div class="stxt">Tap <strong>+</strong> then <strong>Scan QR code</strong></div></div>
      <div class="sstep"><div class="snum">3</div><div class="stxt">Scan QR and verify with 6-digit code</div></div>
    </div>
    <form method="POST"><input type="hidden" name="ss" value="1"><button class="abtn" type="submit"><i class="fas fa-rocket"></i> Begin Setup</button></form>
  <?php elseif($setup_step===2&&$sec): ?>
    <div class="atitle">Scan QR Code</div>
    <div class="asub">Open <strong>Google Authenticator</strong>, tap <strong>+</strong>, scan below.</div>
    <?php if($setup_err): ?><div class="aerr"><i class="fas fa-circle-exclamation"></i> <?=h($setup_err)?></div><?php endif; ?>
    <div style="text-align:center;"><div class="qrwrap"><img src="<?=tqr($sec)?>" alt="QR"></div></div>
    <div class="secbox" onclick="cpSec('<?=h($sec)?>')"><i class="fas fa-key" style="margin-right:8px;"></i><?=h($sec)?></div>
    <div class="cpyhint">Click to copy secret key</div>
    <form method="POST"><input type="hidden" name="vt" value="1">
      <div class="ilbl" style="text-align:center;margin-bottom:7px;">Enter 6-digit code</div>
      <input class="ainp otp" type="text" name="totp_code" maxlength="6" placeholder="000000" inputmode="numeric" autofocus required>
      <button class="abtn" style="margin-top:11px;" type="submit"><i class="fas fa-circle-check"></i> Verify &amp; Activate</button>
    </form>
  <?php endif; ?>
  <div class="afoot">indyonogames.com &copy; <?=date('Y')?></div>
</div></div></div>
<script>function cpSec(s){navigator.clipboard&&navigator.clipboard.writeText(s);}document.querySelectorAll('.otp').forEach(function(e){e.addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,6);});});</script>
<?php elseif(!$logged_in): ?>
<div class="auth-page"><div class="auth-box"><div class="auth-card">
  <div class="abrand"><div class="alogo"><img src="logo.jpg" onerror="this.parentElement.innerHTML='<div style=\'width:48px;height:48px;background:var(--grad);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;\'>&#127918;</div>'"></div>
  <div><div class="abrand-name">YonoBestGame</div><div class="abrand-sub">Admin Panel v4.5</div></div></div>
  <div class="atitle">Welcome Back</div>
  <div class="asub">Sign in with your credentials + authenticator code.</div>
  <?php if($rl_blocked): ?><div class="ablocked"><strong>Access Blocked</strong><br>Too many attempts. Wait 15 minutes.</div>
  <?php else: ?>
    <?php if($login_err): ?><div class="aerr"><i class="fas fa-triangle-exclamation"></i> <?=h($login_err)?></div><?php endif; ?>
    <form method="POST" autocomplete="off"><input type="hidden" name="do_login" value="1">
      <div class="ig"><input class="ainp" type="text" name="u" placeholder="Username" required autofocus><i class="fas fa-user ic"></i></div>
      <div class="ig"><input class="ainp" type="password" name="p" id="pi" placeholder="Password" required><i class="fas fa-lock ic"></i><button type="button" class="eyebtn" onclick="var i=document.getElementById('pi'),e=document.getElementById('ei');i.type=i.type==='password'?'text':'password';e.className=i.type==='password'?'fas fa-eye':'fas fa-eye-slash';"><i class="fas fa-eye" id="ei"></i></button></div>
      <div class="adivider"><i class="fas fa-mobile-screen-button" style="color:var(--gold);"></i> 2-Step Verification</div>
      <div class="ilbl">Authenticator Code</div>
      <input class="ainp otp" type="text" name="totp_code" maxlength="6" placeholder="000000" inputmode="numeric" required>
      <button class="abtn" type="submit" style="margin-top:10px;"><i class="fas fa-arrow-right-to-bracket"></i> Sign In Securely</button>
    </form>
    <div class="asess"><i class="fas fa-clock" style="color:var(--gold);"></i> Session lasts <strong style="color:var(--t1);margin:0 3px;"><?=SESSION_DAYS?> days</strong></div>
  <?php endif; ?>
  <div class="afoot">indyonogames.com &copy; <?=date('Y')?></div>
</div></div></div>
<script>document.querySelectorAll('.otp').forEach(function(e){e.addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,6);});});</script>
<?php else:
$TM=['dashboard'=>['Dashboard','fa-house-chimney'],'all_app'=>['Add App','fa-circle-plus'],'new_app'=>['New Slots','fa-star'],'upcoming'=>['Upcoming Apps','fa-hourglass-half'],'manage'=>['Manage Apps','fa-layer-group'],'positions'=>['Positions','fa-arrow-up-wide-short'],'tags'=>['Corner Tags','fa-tags'],'bonus'=>['Daily Bonus','fa-gift'],'homepage_seo'=>['Homepage SEO','fa-magnifying-glass-chart'],'index_tags'=>['Tags Bar','fa-hashtag'],'announcement'=>['Announcement','fa-bullhorn'],'settings'=>['Settings','fa-sliders'],'bulk_import'=>['Bulk Import','fa-file-import']];
?>
<div class="layout">
<div class="sb-ov" id="sbov" onclick="sbClose()"></div>
<nav class="sb" id="sb">
  <div class="sb-top">
    <div class="sbbrand"><img src="logo.jpg" class="sblogo" onerror="this.style.display='none'" alt=""><div><div class="sbname">YonoBestGame</div><div class="sbver">Admin v4.5</div></div></div>
    <div class="sbsess"><i class="fas fa-shield-check"></i> Session: <strong style="color:#fff;margin-left:3px;"><?=$days_left?>d left</strong></div>
  </div>
  <div class="sbnav">
    <div class="nbs">Overview</div>
    <a href="<?=SELF?>?tab=dashboard" class="na <?=$tab==='dashboard'?'on':''?>"><span class="ni"><i class="fas fa-house-chimney"></i></span>Dashboard</a>
    <div class="nbs">Apps</div>
    <a href="<?=SELF?>?tab=all_app" class="na <?=$tab==='all_app'?'on':''?>"><span class="ni"><i class="fas fa-circle-plus"></i></span>Add App</a>
    <a href="<?=SELF?>?tab=new_app" class="na <?=$tab==='new_app'?'on':''?>"><span class="ni"><i class="fas fa-star"></i></span>New Slots</a>
    <a href="<?=SELF?>?tab=upcoming" class="na <?=$tab==='upcoming'?'on':''?>"><span class="ni"><i class="fas fa-hourglass-half"></i></span>Upcoming <span class="nbadge"><?=count($upcoming)?></span></a>
    <a href="<?=SELF?>?tab=manage" class="na <?=$tab==='manage'?'on':''?>"><span class="ni"><i class="fas fa-layer-group"></i></span>Manage Apps <span class="nbadge"><?=count($allApps)?></span></a>
    <div class="nbs">Customise</div>
    <a href="<?=SELF?>?tab=positions" class="na <?=$tab==='positions'?'on':''?>"><span class="ni"><i class="fas fa-arrow-up-wide-short"></i></span>Positions</a>
    <a href="<?=SELF?>?tab=tags" class="na <?=$tab==='tags'?'on':''?>"><span class="ni"><i class="fas fa-tags"></i></span>Corner Tags</a>
    <a href="<?=SELF?>?tab=bonus" class="na <?=$tab==='bonus'?'on':''?>"><span class="ni"><i class="fas fa-gift"></i></span>Daily Bonus <span class="nbadge"><?=count($bonuses)?></span></a>
    <div class="nbs">Homepage</div>
    <a href="<?=SELF?>?tab=homepage_seo" class="na na-grn <?=$tab==='homepage_seo'?'on':''?>"><span class="ni" style="background:rgba(16,185,129,.1);color:var(--green2);"><i class="fas fa-magnifying-glass-chart"></i></span>Homepage SEO</a>
    <a href="<?=SELF?>?tab=index_tags" class="na na-red <?=$tab==='index_tags'?'on':''?>"><span class="ni" style="background:rgba(239,68,68,.1);color:var(--red2);"><i class="fas fa-hashtag"></i></span>Tags Bar</a>
    <a href="<?=SELF?>?tab=announcement" class="na <?=$tab==='announcement'?'on':''?>"><span class="ni"><i class="fas fa-bullhorn"></i></span>Announcement</a>
    <div class="nbs">System</div>
    <a href="<?=SELF?>?tab=settings" class="na <?=$tab==='settings'?'on':''?>"><span class="ni"><i class="fas fa-sliders"></i></span>Settings</a>
    <a href="<?=SELF?>?tab=bulk_import" class="na na-c <?=$tab==='bulk_import'?'on':''?>"><span class="ni" style="background:rgba(6,182,212,.1);color:var(--cyan2);"><i class="fas fa-file-import"></i></span><span style="color:var(--cyan2);">Bulk Import</span><span class="nbadge nbadge-c">AJAX</span></a>
    <a href="index.php" target="_blank" class="na"><span class="ni"><i class="fas fa-arrow-up-right-from-square"></i></span>View Site</a>
  </div>
  <div class="sbft"><a href="<?=SELF?>?logout=1"><i class="fas fa-right-from-bracket"></i> Logout</a></div>
</nav>
<div class="mn">
  <div class="tb">
    <div class="tb-l"><button class="ham" onclick="sbOpen()"><i class="fas fa-bars"></i></button>
    <?php $ti=$TM[$tab]??['Admin','fa-circle'];echo '<div class="tbpage"><i class="fas '.$ti[1].'" style="color:var(--gold);margin-right:6px;font-size:12px;"></i>'.h($ti[0]).'</div>';?>
    </div>
    <div class="tb-r"><div class="livepill"><div class="ldot"></div>Live</div><a href="index.php" target="_blank" class="btn btn-gh btn-sm"><i class="fas fa-eye"></i></a></div>
  </div>
  <div class="ct">
    <?php if($fl): ?><div class="flash-msg <?=$fl[1]==='ok'?'flash-ok':'flash-err'?>"><i class="fas fa-<?=$fl[1]==='ok'?'circle-check':'triangle-exclamation'?>"></i> <?=h($fl[0])?></div><?php endif; ?>

<?php if($tab==='dashboard'): ?>
<div class="sg">
  <div class="sc sc-g"><div class="sic"><i class="fas fa-mobile-screen-button"></i></div><div class="sv"><?=count($allApps)?></div><div class="sl">Apps Listed</div></div>
  <div class="sc sc-gr"><div class="sic"><i class="fas fa-star"></i></div><div class="sv"><?=count(array_filter($newSlots))?>/5</div><div class="sl">New Slots</div></div>
  <div class="sc sc-b"><div class="sic"><i class="fas fa-hourglass-half"></i></div><div class="sv"><?=count($upcoming)?></div><div class="sl">Upcoming</div></div>
  <div class="sc sc-p"><div class="sic"><i class="fas fa-gift"></i></div><div class="sv"><?=count($bonuses)?></div><div class="sl">Bonuses</div></div>
  <div class="sc sc-r"><div class="sic"><i class="fas fa-hashtag"></i></div><div class="sv"><?=$nextNid?></div><div class="sl">Next NID</div></div>
</div>
<div style="font-size:15px;font-weight:800;color:var(--t1);display:flex;align-items:center;gap:8px;margin-bottom:13px;font-family:'Space Grotesk',sans-serif;"><i class="fas fa-bolt" style="color:var(--gold);"></i> Quick Actions</div>
<div class="qg">
  <a href="<?=SELF?>?tab=all_app" class="qa"><div class="qa-i">&#10133;</div><div class="qa-l">Add App</div></a>
  <a href="<?=SELF?>?tab=new_app" class="qa"><div class="qa-i">&#11088;</div><div class="qa-l">New Slots</div></a>
  <a href="<?=SELF?>?tab=manage" class="qa"><div class="qa-i">&#128221;</div><div class="qa-l">Manage</div></a>
  <a href="<?=SELF?>?tab=positions" class="qa"><div class="qa-i">&#128290;</div><div class="qa-l">Positions</div></a>
  <a href="<?=SELF?>?tab=homepage_seo" class="qa" style="border-color:rgba(16,185,129,.25);"><div class="qa-i">&#128269;</div><div class="qa-l" style="color:var(--green2);">Homepage SEO</div></a>
  <a href="<?=SELF?>?tab=index_tags" class="qa" style="border-color:rgba(239,68,68,.2);"><div class="qa-i">&#127991;</div><div class="qa-l" style="color:var(--red2);">Tags Bar</div></a>
  <a href="<?=SELF?>?tab=bonus" class="qa"><div class="qa-i">&#127873;</div><div class="qa-l">Bonus</div></a>
  <a href="<?=SELF?>?tab=bulk_import" class="qa" style="border-color:rgba(6,182,212,.25);"><div class="qa-i">&#128229;</div><div class="qa-l" style="color:var(--cyan2);">Bulk Import</div></a>
</div>

<?php elseif($tab==='homepage_seo'): ?>
<div class="infob mb14"><i class="fas fa-circle-info"></i> Controls the <strong>page &lt;title&gt;</strong>, <strong>meta description</strong>, and the <strong>content block under "All Apps"</strong> on index.php. Saved to <code>alldetails/homepage_seo.json</code>.</div>
<div class="pc mb14" style="border-color:rgba(16,185,129,.3);border-top:3px solid var(--green2);">
  <div class="ph" style="color:var(--green2);background:rgba(16,185,129,.07);border-color:rgba(16,185,129,.15);"><i class="fas fa-magnifying-glass"></i> Google Search Preview</div>
  <div class="pb"><div class="seo-preview-card">
    <div class="seo-prev-url">&#x1F512; indyonogames.com &rsaquo; index.php</div>
    <div class="seo-prev-title" id="prev_title"><?=h($homepage_seo['meta_title']??'')?></div>
    <div class="seo-prev-desc" id="prev_desc"><?=h($homepage_seo['meta_desc']??'')?></div>
  </div></div>
</div>
<div class="pc" style="border-color:rgba(16,185,129,.3);border-top:3px solid var(--green2);">
  <div class="ph" style="color:var(--green2);background:rgba(16,185,129,.07);border-color:rgba(16,185,129,.15);"><i class="fas fa-pen-to-square"></i> Edit Homepage SEO &amp; Content Block</div>
  <div class="pb">
    <form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="save_homepage_seo">
      <div class="grn-section-hdr"><i class="fas fa-code"></i> Browser Head Tags (affect Google ranking)</div>
      <div class="fg mb14">
        <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-grn">Page &lt;title&gt; Tag *</label>
          <input class="fc fc-grn" name="hp_meta_title" id="seo_title_inp" value="<?=h($homepage_seo['meta_title']??'')?>" placeholder="IndYonoGames - Download All Rs51 To Rs500 Bonus App..." oninput="document.getElementById('prev_title').textContent=this.value" maxlength="70">
          <div class="fhint">Recommended: 50-70 chars. The blue link shown in Google results.</div></div>
        <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-grn">Meta Description *</label>
          <textarea class="fc fc-grn" name="hp_meta_desc" rows="3" placeholder="IndYonoGames - Download All Yono Rummy App..." oninput="document.getElementById('prev_desc').textContent=this.value" maxlength="165"><?=h($homepage_seo['meta_desc']??'')?></textarea>
          <div class="fhint">Recommended: 120-165 chars. The grey snippet text in Google results.</div></div>
      </div>
      <div class="grn-section-hdr"><i class="fas fa-align-left"></i> Content Block Under "All Apps" (shown on homepage with border)</div>
      <div class="fg mb14">
        <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-grn">Content Block Heading</label>
          <input class="fc fc-grn" name="hp_content_title" value="<?=h($homepage_seo['content_title']??'')?>" placeholder="Yono Best Games — India's Biggest Yono App Downloading Platform">
          <div class="fhint">The H1 heading shown inside the bordered block under the apps list.</div></div>
        <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-grn">Content Block Body Text</label>
          <textarea class="fc fc-grn" name="hp_content_body" rows="7" placeholder="Yono Best Games is a trusted platform..."><?=h($homepage_seo['content_body']??'')?></textarea>
          <div class="fhint">Paragraph text inside the bordered SEO block. Supports line breaks.</div></div>
      </div>
      <button type="submit" class="btn btn-grn"><i class="fas fa-floppy-disk"></i> Save Homepage SEO</button>
    </form>
  </div>
</div>

<?php elseif($tab==='index_tags'): ?>
<?php $it_tags=$index_tags['tags']??'';$it_label=$index_tags['label']??'Tags:';$it_items=array_filter(array_map('trim',explode(',',$it_tags))); ?>
<div class="infob mb14"><i class="fas fa-circle-info"></i> Controls the <strong>auto-scrolling tags belt</strong> at the bottom of index.php. Saved to <code>alldetails/index_tags.json</code>.</div>
<div class="pc" style="border-color:rgba(239,68,68,.3);border-top:3px solid #e3232c;">
  <div class="ph" style="color:var(--red2);background:rgba(239,68,68,.07);border-color:rgba(239,68,68,.15);"><i class="fas fa-hashtag"></i> Homepage Tags Bar Editor</div>
  <div class="pb">
    <form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="save_index_tags">
      <div class="fg mb14">
        <div class="fgr"><label class="flb flb-red">Label Text</label><input class="fc fc-red" name="itlabel" value="<?=h($it_label)?>" placeholder="Tags:" style="max-width:180px;"><div class="fhint">Sticky red badge on the left</div></div>
      </div>
      <div class="fgr mb14">
        <label class="flb flb-red">Tags (comma-separated) *</label>
        <textarea class="fc fc-red" name="ittags" rows="5" id="it_inp" oninput="previewIndexTags()" placeholder="Yono Apps, yono rummy, yono arcade..."><?=h($it_tags)?></textarea>
        <div class="fhint">Each comma-separated value = one pill in the auto-scroll bar.</div>
      </div>
      <div style="font-size:10px;font-weight:800;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;margin-bottom:8px;">Live Preview:</div>
      <div class="tags-preview-bar" id="it_preview_bar">
        <div class="tags-preview-label" id="it_preview_label"><i class="fas fa-tags"></i> <?=h($it_label)?></div>
        <div class="tags-preview-scroll" id="it_preview_scroll">
          <?php foreach($it_items as $tg): ?><span class="tpill"><i class="fas fa-hashtag"></i><?=h($tg)?></span><?php endforeach; ?>
        </div>
      </div>
      <div style="margin-top:16px;"><button type="submit" class="btn btn-r" style="background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;"><i class="fas fa-floppy-disk"></i> Save Tags Bar</button></div>
    </form>
  </div>
</div>
<?php if(!empty($it_items)): ?><div class="pc"><div class="ph"><i class="fas fa-list"></i> Current Tags (<?=count($it_items)?>)</div><div class="pb"><div style="display:flex;flex-wrap:wrap;gap:7px;"><?php foreach($it_items as $tg): ?><span class="tpill" style="font-size:12px;padding:5px 13px;"><i class="fas fa-hashtag"></i><?=h($tg)?></span><?php endforeach; ?></div></div></div><?php endif; ?>

<?php elseif($tab==='all_app'): ?>
<div class="nid-auto-badge"><div class="nid-auto-icon"><i class="fas fa-magic-wand-sparkles"></i></div><div><div class="nid-auto-num"><?=$nextNid?></div><div class="nid-auto-lbl">Next NID — auto-assigned</div></div></div>
<div class="pc"><div class="ph"><i class="fas fa-circle-plus"></i> Add New App</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="add_all">
<div class="new-section-hdr"><i class="fas fa-pen-nib"></i> Display &amp; URL Settings</div>
<div class="fg mb14">
  <div class="fgr"><label class="flb">App Name (Internal) *</label><input class="fc" name="name" placeholder="e.g. yono-rummy-51" required></div>
  <div class="fgr"><label class="flb flb-cyan">Display Name</label><input class="fc fc-cyan" name="display_name" placeholder="e.g. Yono Rummy 51"></div>
  <div class="fgr"><label class="flb flb-cyan">URL Folder Name</label><input class="fc fc-cyan" name="folder_name" id="fn_inp" placeholder="e.g. Yono-Rummy-51"><div class="fhint">URL: domain.com/<span id="fn_preview" style="color:var(--cyan2);">folder</span>/</div></div>
</div>
<div class="new-section-hdr"><i class="fas fa-search"></i> SEO Meta Tags (app page)</div>
<div class="fg mb14">
  <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-cyan">Meta Title</label><input class="fc fc-cyan" name="meta_title" placeholder="e.g. Yono Rummy 51 | Rs51 Sign Up Bonus | Download APK"></div>
  <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-cyan">Meta Description</label><textarea class="fc fc-cyan" name="meta_desc" rows="2" placeholder="Download Yono Rummy 51 and get Rs51 bonus..."></textarea></div>
</div>
<div class="red-section-hdr"><i class="fas fa-hashtag"></i> App Page Tags (scroll bar on app page)</div>
<div class="fg mb14">
  <div class="fgr" style="grid-column:1/-1;">
    <label class="flb flb-red">Page Tags (comma-separated)</label>
    <input class="fc fc-red" name="page_tags" id="pt_inp_add" placeholder="e.g. Yono Rummy, Rummy App, Rs51 Bonus" oninput="previewPageTags('pt_inp_add','pt_preview_add')">
    <div class="fhint">Leave blank to auto-generate from app data.</div>
    <div class="tags-preview-bar" id="pt_preview_add" style="display:none;"><div class="tags-preview-label"><i class="fas fa-tags"></i> Preview</div><div class="tags-preview-scroll" id="pt_preview_scroll_add"></div></div>
  </div>
</div>
<div class="div"></div>
<div class="fg">
  <div class="fgr"><label class="flb">App Icon URL</label><input class="fc" name="imglink" placeholder="https://..."></div>
  <div class="fgr"><label class="flb">App Download Link</label><input class="fc" name="applink" placeholder="https://..."></div>
  <div class="fgr"><label class="flb">Big Banner URL</label><input class="fc" name="bigimglink" placeholder="https://..."></div>
  <div class="fgr"><label class="flb">Sign Up Bonus (Rs)</label><input class="fc" name="signbo" value="0"></div>
  <div class="fgr"><label class="flb">Min. Withdrawal (Rs)</label><input class="fc" name="mwith" value="0"></div>
  <div class="fgr"><label class="flb">Min. Add (Rs)</label><input class="fc" name="madd" value="0"></div>
  <div class="fgr"><label class="flb">Total Downloads</label><input class="fc" name="tdown" value="0"></div>
  <div class="fgr"><label class="flb">Refer % Commission</label><input class="fc" name="refcoms" placeholder="30"></div>
  <div class="fgr"><label class="flb">Refer % Affiliate</label><input class="fc" name="refperapro" placeholder="5"></div>
  <div class="fgr"><label class="flb">Game ID</label><input class="fc" name="gameidff"></div>
  <div class="fgr"><label class="flb">Channel ID</label><input class="fc" name="chanidv"></div>
  <div class="fgr"><label class="flb">Corner Tag Text</label><input class="fc" name="tag_text" id="a_tt" placeholder="HOT / NEW / VIP..."></div>
  <div class="fgr"><label class="flb">Corner Tag Color</label><input class="fc fc-col" type="color" name="tag_color" id="a_tc" value="#e3232c"></div>
</div>
<div class="div"></div>
<div class="fgr mb14"><label class="flb">Quick Corner Tag Presets</label><div class="tprow"><?php foreach($TP as $t): ?><button type="button" class="tpb" style="background:<?=h($t[2])?>" onclick="sTag('a_tt','a_tc','<?=addslashes($t[1])?>','<?=h($t[2])?>')"><?=h($t[0])?></button><?php endforeach; ?></div></div>
<div class="rotatebadge"><i class="fas fa-rotate" style="margin-right:6px;"></i><strong>Auto-rotates New Slots</strong> — Folder created automatically.</div>
<button type="submit" class="btn btn-g"><i class="fas fa-plus"></i> Add App</button>
</form></div></div>
<script>(function(){var fi=document.getElementById('fn_inp'),pr=document.getElementById('fn_preview');if(!fi||!pr)return;fi.addEventListener('input',function(){pr.textContent=this.value||'folder';});})();</script>

<?php elseif($tab==='new_app'): ?>
<div class="slotg"><?php for($i=1;$i<=5;$i++):$s=$newSlots[$i];$sdn=$s?($s['display_name']??$s['name']??'—'):''; ?>
  <div class="slotc <?=$s?'full':''?>"><div class="slotn">Slot <?=$i?></div>
    <?php if($s): ?><img src="<?=h($s['imglink']??'')?>" onerror="this.src='logo.jpg'" alt=""><div class="slotnm"><?=h($sdn)?></div><div class="slotbo">Rs<?=h($s['signbo']??'')?></div>
    <?php else: ?><div style="font-size:1.5rem;margin:9px 0;">&#128219;</div><div class="slotem">Empty</div><?php endif; ?>
  </div>
<?php endfor; ?></div>
<div class="pc"><div class="ph"><i class="fas fa-star"></i> Pin App to Slot Manually</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="set_new_slot">
  <div class="fg">
    <div class="fgr"><label class="flb">Slot *</label><select class="fc" name="slot"><?php for($i=1;$i<=5;$i++): ?><option value="<?=$i?>">Slot <?=$i?><?=$newSlots[$i]?' – '.h($newSlots[$i]['display_name']??$newSlots[$i]['name']??''):' – Empty'?></option><?php endfor; ?></select></div>
    <div class="fgr"><label class="flb">App NID (pull existing)</label><input class="fc" name="nid_ref" placeholder="NID"></div>
    <div class="fgr"><label class="flb flb-cyan">Display Name</label><input class="fc fc-cyan" name="display_name"></div>
    <div class="fgr"><label class="flb flb-cyan">URL Folder</label><input class="fc fc-cyan" name="folder_name"></div>
    <div class="fgr"><label class="flb">App Name</label><input class="fc" name="name"></div>
    <div class="fgr"><label class="flb">Icon URL</label><input class="fc" name="imglink"></div>
    <div class="fgr"><label class="flb">App Link</label><input class="fc" name="applink"></div>
    <div class="fgr"><label class="flb">Bonus Rs</label><input class="fc" name="signbo" value="0"></div>
    <div class="fgr"><label class="flb">Min W/D Rs</label><input class="fc" name="mwith" value="0"></div>
    <div class="fgr"><label class="flb">Corner Tag</label><input class="fc" name="tag_text" id="n_tt"></div>
    <div class="fgr"><label class="flb">Tag Color</label><input class="fc fc-col" type="color" name="tag_color" id="n_tc" value="#22c55e"></div>
  </div>
  <div class="div"></div>
  <div class="fgr mb14"><div class="tprow"><?php foreach($TP as $t): ?><button type="button" class="tpb" style="background:<?=h($t[2])?>" onclick="sTag('n_tt','n_tc','<?=addslashes($t[1])?>','<?=h($t[2])?>')"><?=h($t[0])?></button><?php endforeach; ?></div></div>
  <button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save Slot</button>
</form></div></div>

<?php elseif($tab==='upcoming'): ?>
<?php if($editUpApp): $eudn=$editUpApp['display_name']??$editUpApp['name']??''; ?>
<div class="pc mb14" style="border-color:rgba(232,184,75,.3);"><div class="ph"><i class="fas fa-pen-to-square"></i> Editing: <?=h($eudn)?> <code><?=h($editUpApp['nid']??'')?></code></div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="edit_up"><input type="hidden" name="nid" value="<?=h($editUpApp['nid']??'')?>">
  <div class="fg">
    <div class="fgr"><label class="flb">Name *</label><input class="fc" name="name" value="<?=h($editUpApp['name']??'')?>" required></div>
    <div class="fgr"><label class="flb flb-cyan">Display Name</label><input class="fc fc-cyan" name="display_name" value="<?=h($eudn)?>"></div>
    <div class="fgr"><label class="flb">Icon URL</label><input class="fc" name="imglink" value="<?=h($editUpApp['imglink']??'')?>"></div>
    <div class="fgr"><label class="flb">App Link</label><input class="fc" name="applink" value="<?=h($editUpApp['applink']??'')?>"></div>
    <div class="fgr"><label class="flb">Bonus (Rs)</label><input class="fc" name="signbo" value="<?=h($editUpApp['signbo']??'0')?>"></div>
    <div class="fgr"><label class="flb">Min. W/D (Rs)</label><input class="fc" name="mwith" value="<?=h($editUpApp['mwith']??'0')?>"></div>
    <div class="fgr"><label class="flb">Launch Date *</label><input class="fc" type="datetime-local" name="launch_date" value="<?=h($editUpApp['launch_date']??'')?>" required></div>
    <div class="fgr"><label class="flb">Tag Text</label><input class="fc" name="tag_text" id="eu_tt" value="<?=h($editUpApp['tag_text']??'')?>"></div>
    <div class="fgr"><label class="flb">Tag Color</label><input class="fc fc-col" type="color" name="tag_color" id="eu_tc" value="<?=h($editUpApp['tag_color']??'#3b82f6')?>"></div>
  </div>
  <div class="div"></div>
  <div class="fgr mb14"><div class="tprow"><?php foreach($TP as $t): ?><button type="button" class="tpb" style="background:<?=h($t[2])?>" onclick="sTag('eu_tt','eu_tc','<?=addslashes($t[1])?>','<?=h($t[2])?>')"><?=h($t[0])?></button><?php endforeach; ?></div></div>
  <div class="df"><button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save</button><a href="<?=SELF?>?tab=upcoming" class="btn btn-gh">Cancel</a></div>
</form></div></div>
<?php endif; ?>
<div class="pc"><div class="ph"><i class="fas fa-hourglass-half"></i> Add Upcoming App</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="add_up">
  <div class="fg">
    <div class="fgr"><label class="flb">Name *</label><input class="fc" name="name" required></div>
    <div class="fgr"><label class="flb flb-cyan">Display Name</label><input class="fc fc-cyan" name="display_name"></div>
    <div class="fgr"><label class="flb">Icon URL</label><input class="fc" name="imglink" placeholder="https://..."></div>
    <div class="fgr"><label class="flb">Bonus (Rs)</label><input class="fc" name="signbo" value="0"></div>
    <div class="fgr"><label class="flb">Min. W/D (Rs)</label><input class="fc" name="mwith" value="0"></div>
    <div class="fgr"><label class="flb">Launch Date *</label><input class="fc" type="datetime-local" name="launch_date" required></div>
    <div class="fgr"><label class="flb">Tag Text</label><input class="fc" name="tag_text" id="u_tt" placeholder="COMING SOON"></div>
    <div class="fgr"><label class="flb">Tag Color</label><input class="fc fc-col" type="color" name="tag_color" id="u_tc" value="#3b82f6"></div>
  </div>
  <div class="div"></div>
  <div class="fgr mb14"><div class="tprow"><?php foreach($TP as $t): ?><button type="button" class="tpb" style="background:<?=h($t[2])?>" onclick="sTag('u_tt','u_tc','<?=addslashes($t[1])?>','<?=h($t[2])?>')"><?=h($t[0])?></button><?php endforeach; ?></div></div>
  <button type="submit" class="btn btn-g"><i class="fas fa-plus"></i> Add</button>
</form></div></div>
<?php if(!empty($upcoming)): ?>
<div class="pc"><div class="ph"><i class="fas fa-list"></i> Upcoming (<?=count($upcoming)?>)</div>
<div class="tw"><table class="tbl"><thead><tr><th>App</th><th>Display Name</th><th>NID</th><th>Launch</th><th>Bonus</th><th>Tag</th><th>Actions</th></tr></thead>
<tbody><?php foreach($upcoming as $a): $udn=$a['display_name']??$a['name']??''; ?><tr>
  <td><div class="df"><img src="<?=h($a['imglink']??'')?>" class="tim" onerror="this.src='logo.jpg'"><span class="fw8"><?=h($a['name']??'')?></span></div></td>
  <td style="color:var(--cyan2);font-weight:700;font-size:12px;"><?=h($udn)?></td><td><code><?=h($a['nid']??'')?></code></td>
  <td class="cg fw8" style="font-size:11px;"><?=h($a['launch_date']??'—')?></td>
  <td class="cr fw8">Rs<?=h($a['signbo']??'')?></td>
  <td><?=!empty($a['tag_text'])?'<span class="tb2" style="background:'.h($a['tag_color']??'#3b82f6').'">'.h($a['tag_text']).'</span>':'<span class="notag">—</span>'?></td>
  <td><div class="df"><a href="<?=SELF?>?tab=upcoming&edit_up=<?=urlencode($a['nid']??'')?>" class="btn btn-gh btn-xs"><i class="fas fa-pen"></i></a><form method="POST" action="<?=SELF?>" onsubmit="return confirm('Delete?')" style="margin:0;"><input type="hidden" name="action" value="del_up"><input type="hidden" name="nid" value="<?=h($a['nid']??'')?>"><button type="submit" class="btn btn-r btn-xs"><i class="fas fa-trash"></i></button></form></div></td>
</tr><?php endforeach; ?></tbody></table></div></div>
<?php else: ?><div class="pc"><div class="pb"><div class="empty"><i class="fas fa-hourglass-half"></i><p>No upcoming apps yet.</p></div></div></div><?php endif; ?>

<?php elseif($tab==='manage'): ?>
<?php if($editApp): $eadn=$editApp['display_name']??$editApp['name']??'';$eafn=$editApp['folder_name']??$editApp['name']??''; ?>
<div class="pc mb14" style="border-color:var(--b3);"><div class="ph"><i class="fas fa-pen-to-square"></i> Editing: <?=h($editApp['name']??'')?> <code><?=h($editApp['nid']??'')?></code></div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="edit_all"><input type="hidden" name="nid" value="<?=h($editApp['nid']??'')?>">
<div class="new-section-hdr"><i class="fas fa-pen-nib"></i> Display &amp; URL Settings</div>
<div class="fg mb14">
  <div class="fgr"><label class="flb">App Name *</label><input class="fc" name="name" value="<?=h($editApp['name']??'')?>" required></div>
  <div class="fgr"><label class="flb flb-cyan">Display Name</label><input class="fc fc-cyan" name="display_name" value="<?=h($eadn)?>"></div>
  <div class="fgr"><label class="flb flb-cyan">URL Folder</label><input class="fc fc-cyan" name="folder_name" value="<?=h($eafn)?>"><div class="fhint">Renaming moves the folder.</div></div>
</div>
<div class="new-section-hdr"><i class="fas fa-search"></i> SEO Meta Tags (app page)</div>
<div class="fg mb14">
  <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-cyan">Meta Title</label><input class="fc fc-cyan" name="meta_title" value="<?=h($editApp['meta_title']??'')?>" placeholder="Custom page title..."></div>
  <div class="fgr" style="grid-column:1/-1;"><label class="flb flb-cyan">Meta Description</label><textarea class="fc fc-cyan" name="meta_desc" rows="2"><?=h($editApp['meta_desc']??'')?></textarea></div>
</div>
<div class="red-section-hdr"><i class="fas fa-hashtag"></i> App Page Tags (scroll bar on this app's page)</div>
<div class="fg mb14">
  <div class="fgr" style="grid-column:1/-1;">
    <label class="flb flb-red">Page Tags (comma-separated)</label>
    <input class="fc fc-red" name="page_tags" id="pt_inp_edit" value="<?=h($editApp['page_tags']??'')?>" placeholder="Yono Rummy, Rummy App, Rs51 Bonus" oninput="previewPageTags('pt_inp_edit','pt_preview_edit')">
    <div class="fhint">Leave blank to auto-generate.</div>
    <div class="tags-preview-bar" id="pt_preview_edit" style="<?=!empty($editApp['page_tags'])?'':'display:none;'?>">
      <div class="tags-preview-label"><i class="fas fa-tags"></i> Preview</div>
      <div class="tags-preview-scroll" id="pt_preview_scroll_edit"><?php if(!empty($editApp['page_tags'])):foreach(array_filter(array_map('trim',explode(',',$editApp['page_tags'])))as $tg):?><span class="tpill"><i class="fas fa-hashtag"></i><?=h($tg)?></span><?php endforeach;endif;?></div>
    </div>
  </div>
</div>
<div class="div"></div>
<div class="fg">
  <div class="fgr"><label class="flb">Icon URL</label><input class="fc" name="imglink" value="<?=h($editApp['imglink']??'')?>"></div>
  <div class="fgr"><label class="flb">App Download Link</label><input class="fc" name="applink" value="<?=h($editApp['applink']??'')?>"></div>
  <div class="fgr"><label class="flb">Big Banner URL</label><input class="fc" name="bigimglink" value="<?=h($editApp['bigimglink']??'')?>"></div>
  <div class="fgr"><label class="flb">Bonus (Rs)</label><input class="fc" name="signbo" value="<?=h($editApp['signbo']??'0')?>"></div>
  <div class="fgr"><label class="flb">Min. W/D (Rs)</label><input class="fc" name="mwith" value="<?=h($editApp['mwith']??'0')?>"></div>
  <div class="fgr"><label class="flb">Min. Add (Rs)</label><input class="fc" name="madd" value="<?=h($editApp['madd']??'0')?>"></div>
  <div class="fgr"><label class="flb">Total Downloads</label><input class="fc" name="tdown" value="<?=h($editApp['tdown']??'0')?>"></div>
  <div class="fgr"><label class="flb">Refer % Commission</label><input class="fc" name="refcoms" value="<?=h($editApp['refcoms']??'')?>"></div>
  <div class="fgr"><label class="flb">Refer % Affiliate</label><input class="fc" name="refperapro" value="<?=h($editApp['refperapro']??'')?>"></div>
  <div class="fgr"><label class="flb">Game ID</label><input class="fc" name="gameidff" value="<?=h($editApp['gameidff']??'')?>"></div>
  <div class="fgr"><label class="flb">Channel ID</label><input class="fc" name="chanidv" value="<?=h($editApp['chanidv']??'')?>"></div>
  <div class="fgr"><label class="flb">Corner Tag Text</label><input class="fc" name="tag_text" id="e_tt" value="<?=h($editApp['tag_text']??'')?>"></div>
  <div class="fgr"><label class="flb">Corner Tag Color</label><input class="fc fc-col" type="color" name="tag_color" id="e_tc" value="<?=h($editApp['tag_color']??'#e3232c')?>"></div>
</div>
<div class="div"></div>
<div class="fgr mb14"><div class="tprow"><?php foreach($TP as $t): ?><button type="button" class="tpb" style="background:<?=h($t[2])?>" onclick="sTag('e_tt','e_tc','<?=addslashes($t[1])?>','<?=h($t[2])?>')"><?=h($t[0])?></button><?php endforeach; ?></div></div>
<div class="df"><button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save Changes</button><a href="<?=SELF?>?tab=manage" class="btn btn-gh">Cancel</a></div>
</form></div></div>
<?php endif; ?>
<div class="pc"><div class="ph"><i class="fas fa-layer-group"></i> All Apps (<?=count($allApps)?>)</div>
<?php if(empty($allApps)): ?><div class="pb"><div class="empty"><i class="fas fa-mobile-alt"></i><p>No apps yet.</p></div></div>
<?php else: ?><div class="tw"><table class="tbl"><thead><tr><th>#</th><th>App</th><th>Display Name</th><th>Folder</th><th>NID</th><th>Bonus</th><th>Page Tags</th><th>Corner Tag</th><th>Actions</th></tr></thead>
<tbody><?php foreach($allApps as $i=>$a):$adn=$a['display_name']??$a['name']??'';$afn=$a['folder_name']??$a['name']??'';$apt=$a['page_tags']??''; ?><tr>
  <td class="cm fw8"><?=$i+1?></td>
  <td><div class="df"><img src="<?=h($a['imglink']??'')?>" class="tim" onerror="this.src='logo.jpg'"><span class="fw8"><?=h($a['name']??'')?></span></div></td>
  <td style="color:var(--cyan2);font-weight:700;font-size:12px;"><?=h($adn)?></td>
  <td><code><?=h($afn)?>/</code></td><td><code><?=h($a['nid']??'')?></code></td>
  <td class="cr fw8">Rs<?=h($a['signbo']??'')?></td>
  <td style="font-size:11px;color:var(--t2);max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?=$apt?h($apt):'<em style="opacity:.3">auto</em>'?></td>
  <td><?=!empty($a['tag_text'])?'<span class="tb2" style="background:'.h($a['tag_color']??'#ef4444').'">'.h($a['tag_text']).'</span>':'<span class="notag">—</span>'?></td>
  <td><div class="df"><a href="<?=SELF?>?tab=manage&edit=<?=urlencode($a['nid']??'')?>" class="btn btn-gh btn-xs"><i class="fas fa-pen"></i></a><form method="POST" action="<?=SELF?>" onsubmit="return confirm('Delete <?=addslashes(h($a['display_name']??$a['name']??''))?>')" style="margin:0;"><input type="hidden" name="action" value="del_all"><input type="hidden" name="nid" value="<?=h($a['nid']??'')?>"><button type="submit" class="btn btn-r btn-xs"><i class="fas fa-trash"></i></button></form></div></td>
</tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<?php elseif($tab==='positions'): ?>
<div class="infob mb14"><i class="fas fa-circle-info"></i> <strong>Lower number = higher on site.</strong></div>
<div class="pc"><div class="ph"><i class="fas fa-arrow-up-wide-short"></i> App Display Order</div><div class="pb">
<?php if(empty($allApps)): ?><div class="empty"><i class="fas fa-sort"></i><p>No apps yet.</p></div>
<?php else: ?>
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="save_pos">
  <div class="poslist"><?php foreach($allApps as $a): $pdn=$a['display_name']??$a['name']??''; ?>
    <div class="positem"><i class="fas fa-grip-vertical poshdl"></i><img src="<?=h($a['imglink']??'')?>" class="posim" onerror="this.src='logo.jpg'"><div class="posnm"><?=h($pdn)?> <code style="font-size:9px;"><?=h($a['nid']??'')?></code></div><input type="number" class="posinp" name="pos[<?=h($a['nid']??'')?>]" value="<?=intval($a['pos']??999)?>" min="1" max="9999"></div>
  <?php endforeach; ?></div>
  <div class="div"></div><button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save Positions</button>
</form><?php endif; ?></div></div>

<?php elseif($tab==='tags'): ?>
<?php if(empty($allApps)): ?><div class="pc"><div class="pb"><div class="empty"><i class="fas fa-tags"></i><p>No apps.</p></div></div></div>
<?php else: ?>
<div class="infob mb14"><i class="fas fa-circle-info"></i> Corner Tags are the small coloured badges (HOT, NEW, VIP) shown on app icons.</div>
<div class="pc"><div class="ph"><i class="fas fa-tags"></i> Quick Corner Tag Editor (<?=count($allApps)?>)</div>
<div class="tw"><table class="tbl"><thead><tr><th>App</th><th>Display Name</th><th>NID</th><th>Current Tag</th><th>Quick Update</th></tr></thead>
<tbody><?php foreach($allApps as $a): $tdn=$a['display_name']??$a['name']??''; ?><tr>
  <td><div class="df"><img src="<?=h($a['imglink']??'')?>" class="tim" onerror="this.src='logo.jpg'"><span class="fw8"><?=h($a['name']??'')?></span></div></td>
  <td style="color:var(--cyan2);font-size:12px;font-weight:700;"><?=h($tdn)?></td><td><code><?=h($a['nid']??'')?></code></td>
  <td><?=!empty($a['tag_text'])?'<span class="tb2" style="background:'.h($a['tag_color']??'#ef4444').'">'.h($a['tag_text']).'</span>':'<span class="notag">No tag</span>'?></td>
  <td><form method="POST" action="<?=SELF?>" style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
    <input type="hidden" name="action" value="upd_tag"><input type="hidden" name="nid" value="<?=h($a['nid']??'')?>">
    <input type="text" name="tag_text" class="fc" style="width:88px;" value="<?=h($a['tag_text']??'')?>" placeholder="Tag...">
    <input type="color" name="tag_color" class="fc fc-col" style="width:38px;" value="<?=h($a['tag_color']??'#ef4444')?>">
    <?php foreach($TP as $t): ?><button type="submit" name="tag_text" value="<?=h($t[1])?>" class="tpb" style="background:<?=h($t[2])?>;font-size:10px;padding:4px 7px;" title="<?=h($t[0])?>"><?=h($t[0])?></button><?php endforeach; ?>
    <button type="submit" class="btn btn-g btn-xs"><i class="fas fa-check"></i></button>
  </form></td>
</tr><?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>

<?php elseif($tab==='bonus'): ?>
<div class="pc"><div class="ph"><i class="fas fa-plus"></i> Add Bonus Offer</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="add_bonus">
  <div class="fg">
    <div class="fgr"><label class="flb">App Name *</label><input class="fc" name="bn" required></div>
    <div class="fgr"><label class="flb">App Icon URL</label><input class="fc" name="bi" placeholder="https://..."></div>
    <div class="fgr"><label class="flb">Bonus Code</label><input class="fc" name="bc" placeholder="YONO51"></div>
    <div class="fgr"><label class="flb">Bonus Amount (Rs) *</label><input class="fc" name="ba" required></div>
    <div class="fgr"><label class="flb">Min. Withdrawal (Rs) *</label><input class="fc" name="bm" required></div>
    <div class="fgr"><label class="flb">Note</label><input class="fc" name="bno" placeholder="Limited time!"></div>
  </div>
  <div class="div"></div><button type="submit" class="btn btn-g"><i class="fas fa-plus"></i> Add Offer</button>
</form></div></div>
<?php if(!empty($bonuses)): ?>
<div class="pc"><div class="ph"><i class="fas fa-gift"></i> Active Offers (<?=count($bonuses)?>)<span class="ph-r"><form method="POST" action="<?=SELF?>" onsubmit="return confirm('Clear ALL?')" style="margin:0;"><input type="hidden" name="action" value="clr_bonus"><button type="submit" class="btn btn-r btn-xs"><i class="fas fa-trash"></i> Clear All</button></form></span></div>
<div class="tw"><table class="tbl"><thead><tr><th>#</th><th>App</th><th>Code</th><th>Bonus</th><th>W/D</th><th>Note</th><th>Del</th></tr></thead>
<tbody><?php foreach($bonuses as $bi=>$b): ?><tr>
  <td class="cm fw8"><?=$bi+1?></td>
  <td><div class="df"><?php if(!empty($b['img'])): ?><img src="<?=h($b['img'])?>" class="tim" onerror="this.src='logo.jpg'"><?php endif; ?><span class="fw8"><?=h($b['name']??'')?></span></div></td>
  <td><?=!empty($b['code'])?'<span class="tb2" style="background:var(--g3)">'.h($b['code']).'</span>':'<span class="notag">—</span>'?></td>
  <td class="cr fw8">Rs<?=h($b['bonus']??'')?></td><td class="cgr fw8">Rs<?=h($b['mwith']??'')?></td>
  <td class="cm" style="font-size:12px;"><?=h($b['note']??'—')?></td>
  <td><form method="POST" action="<?=SELF?>" onsubmit="return confirm('Remove?')" style="margin:0;"><input type="hidden" name="action" value="del_bonus"><input type="hidden" name="bi" value="<?=$bi?>"><button type="submit" class="btn btn-r btn-xs"><i class="fas fa-trash"></i></button></form></td>
</tr><?php endforeach; ?></tbody></table></div></div>
<?php else: ?><div class="pc"><div class="pb"><div class="empty"><i class="fas fa-gift"></i><p>No offers yet.</p></div></div></div><?php endif; ?>

<?php elseif($tab==='bulk_import'): ?>
<?php if($bulk_stats): ?>
<div class="pc mb14" style="border-top:3px solid var(--cyan2);"><div class="ph" style="color:var(--cyan2);"><i class="fas fa-circle-check"></i> Import Results — <?=$bulk_stats['total']?> files processed</div>
<div class="pb"><div class="irs-grid"><div class="irs irs-gr"><div class="irs-n"><?=$bulk_stats['added']?></div><div class="irs-l">Added</div></div><div class="irs irs-bl"><div class="irs-n"><?=$bulk_stats['updated']?></div><div class="irs-l">Updated</div></div><div class="irs irs-go"><div class="irs-n"><?=$bulk_stats['skipped']?></div><div class="irs-l">Skipped</div></div><div class="irs irs-re"><div class="irs-n"><?=$bulk_stats['errors']?></div><div class="irs-l">Errors</div></div></div></div></div>
<?php endif; ?>
<?php if(!empty($bulk_errors)): ?><div class="pc mb14" style="border-color:rgba(239,68,68,.25);"><div class="ph" style="color:var(--red2);"><i class="fas fa-triangle-exclamation"></i> <?=count($bulk_errors)?> Error(s)</div><div class="pb"><div class="import-log"><?php foreach($bulk_errors as $e): ?><div class="import-row err"><i class="fas fa-xmark"></i><?=h($e)?></div><?php endforeach; ?></div></div></div><?php endif; ?>
<div class="pc" style="border-top:3px solid var(--cyan2);">
  <div class="ph" style="color:var(--cyan2);"><i class="fas fa-upload"></i> Upload &amp; Import JSON Files</div>
  <div class="pb">
    <div style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:18px;">
      <button type="button" id="modeSkip" onclick="setMode('skip')" style="flex:1;min-width:140px;padding:11px 14px;border-radius:11px;border:2px solid var(--gold);background:rgba(232,184,75,.1);color:var(--gold);font-weight:800;font-size:13px;cursor:pointer;font-family:inherit;"><i class="fas fa-forward"></i> Skip Existing<div style="font-size:10px;font-weight:600;opacity:.7;margin-top:2px;">Don't touch existing apps</div></button>
      <button type="button" id="modeOver" onclick="setMode('overwrite')" style="flex:1;min-width:140px;padding:11px 14px;border-radius:11px;border:2px solid var(--b1);background:transparent;color:var(--t2);font-weight:800;font-size:13px;cursor:pointer;font-family:inherit;"><i class="fas fa-rotate"></i> Overwrite<div style="font-size:10px;font-weight:600;opacity:.7;margin-top:2px;">Update existing app data</div></button>
    </div>
    <input type="hidden" id="importModeInput" value="skip">
    <div class="dropzone" id="dropzone"><input type="file" id="fileInput" multiple accept=".json" onchange="handleFiles(this.files)"><span class="dz-icon">&#128194;</span><div class="dz-title" id="dzTitle">Click or drag .json files here</div><div class="dz-sub">Any number of files — batched AJAX upload</div></div>
    <div id="fileListWrap" style="display:none;"><div class="fcbar"><div><div class="fcbar-n" id="fcNum">0</div><div style="font-size:10px;color:var(--t2);font-weight:700;text-transform:uppercase;letter-spacing:.4px;">files selected</div></div><button type="button" onclick="clearFiles()" class="btn btn-r btn-sm btn-xs"><i class="fas fa-xmark"></i> Clear All</button></div><div class="flist" id="fileList"></div></div>
    <div id="progressWrap" style="display:none;margin-top:14px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;"><span style="font-size:12px;font-weight:700;color:var(--cyan2);" id="progressTxt">Importing...</span><span style="font-size:12px;font-weight:900;color:var(--cyan2);" id="progressPct">0%</span></div>
      <div style="background:var(--bg2);border-radius:99px;height:8px;overflow:hidden;"><div id="progressBar" style="height:100%;background:linear-gradient(90deg,#0891b2,#06b6d4);border-radius:99px;width:0%;transition:width .3s;"></div></div>
      <div class="irs-grid" style="margin-top:10px;"><div class="irs irs-gr"><div class="irs-n" id="rAdded">0</div><div class="irs-l">Added</div></div><div class="irs irs-bl"><div class="irs-n" id="rUpdated">0</div><div class="irs-l">Updated</div></div><div class="irs irs-go"><div class="irs-n" id="rSkipped">0</div><div class="irs-l">Skipped</div></div><div class="irs irs-re"><div class="irs-n" id="rErrors">0</div><div class="irs-l">Errors</div></div></div>
    </div>
    <div id="errorLogWrap" style="display:none;margin-top:10px;"><div style="font-size:11px;font-weight:800;color:var(--red2);margin-bottom:6px;"><i class="fas fa-triangle-exclamation"></i> Import Errors:</div><div class="import-log" id="errorLog"></div></div>
    <button type="button" id="submitBtn" onclick="startBatchImport()" class="btn btn-c" style="width:100%;justify-content:center;font-size:14px;padding:14px;font-weight:900;opacity:.4;pointer-events:none;margin-top:14px;" disabled><i class="fas fa-file-import"></i> <span id="submitTxt">Select files to import</span></button>
  </div>
</div>

<?php elseif($tab==='announcement'): ?>
<div class="pc"><div class="ph"><i class="fas fa-bullhorn"></i> Announcement Popup</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="save_ann">
  <div class="fg">
    <div class="fgr"><label class="flb">Popup Image URL</label><input class="fc" name="ai" value="<?=h($ann['img_url']??'')?>" placeholder="https://..."></div>
    <div class="fgr"><label class="flb">Button Link URL</label><input class="fc" name="al2" value="<?=h($ann['link_url']??'')?>" placeholder="https://t.me/..."></div>
    <div class="fgr"><label class="flb">Button Text</label><input class="fc" name="ab" value="<?=h($ann['btn_text']??'Join Channel')?>"></div>
  </div>
  <div class="div"></div>
  <div class="togw mb14"><label class="tog"><input type="checkbox" name="ae" <?=!empty($ann['enabled'])?'checked':''?>><span class="togsl"></span></label><span class="togl">Show popup on website</span></div>
  <button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save Popup</button>
</form></div></div>
<?php if(!empty($ann['img_url'])): ?><div class="pc mt12"><div class="ph"><i class="fas fa-eye"></i> Preview</div><div class="pb" style="text-align:center;"><img src="<?=h($ann['img_url'])?>" style="max-width:260px;width:100%;border-radius:12px;border:1px solid var(--b2);" onerror="this.style.display='none'"><div style="margin-top:11px;"><a href="<?=h($ann['link_url']??'')?>" target="_blank" class="btn btn-g btn-sm" style="display:inline-flex;"><?=h($ann['btn_text']??'Join Channel')?> <i class="fas fa-arrow-right"></i></a></div></div></div><?php endif; ?>

<?php elseif($tab==='settings'): ?>
<div class="pc"><div class="ph"><i class="fas fa-sliders"></i> Site Settings</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="save_site">
  <div class="fg">
    <div class="fgr"><label class="flb">Site Name</label><input class="fc" name="sn" value="<?=h($site['site_name']??'YonoBestGame')?>" required></div>
    <div class="fgr"><label class="flb">Telegram URL</label><input class="fc" name="tg" value="<?=h($site['telegram_url']??'')?>" placeholder="https://t.me/..."></div>
    <div class="fgr"><label class="flb">WhatsApp URL</label><input class="fc" name="wa" value="<?=h($site['whatsapp_url']??'')?>" placeholder="https://wa.me/..."></div>
    <div class="fgr"><label class="flb">Apps Listed Count</label><input class="fc" name="apl" value="<?=h($site['apps_listed']??'50+')?>" placeholder="50+"></div>
  </div>
  <div class="div"></div><button type="submit" class="btn btn-g"><i class="fas fa-floppy-disk"></i> Save Settings</button>
</form></div></div>
<div id="chg-totp" style="scroll-margin-top:80px;">
<?php if($chg_step===2&&$chg_pending): ?>
<div class="pc mt12" style="border-top:3px solid var(--cyan2);"><div class="ph" style="color:var(--cyan2);"><i class="fas fa-qrcode"></i> Scan New QR Code &mdash; Step 2 of 2</div><div class="pb">
  <div style="text-align:center;margin-bottom:14px;"><div class="qrwrap" style="margin:0 auto;display:inline-block;"><img src="<?=tqr($chg_pending)?>" alt="New QR" style="width:220px;height:220px;"></div></div>
  <div class="secbox" style="border-color:rgba(6,182,212,.4);color:var(--cyan2);cursor:pointer;" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?=h($chg_pending)?>')"><?=h($chg_pending)?></div>
  <div class="cpyhint">Click to copy new secret key</div>
  <form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="chg_totp_step2">
    <div class="ilbl" style="text-align:center;margin-bottom:7px;">Enter 6-digit code from NEW entry</div>
    <input class="ainp otp" style="background:var(--bg2);border:1.5px solid rgba(6,182,212,.3);color:var(--t1);" type="text" name="new_totp" maxlength="6" placeholder="000000" inputmode="numeric" required autofocus>
    <div class="df" style="margin-top:12px;">
      <button type="submit" class="btn btn-c" style="flex:1;justify-content:center;"><i class="fas fa-circle-check"></i> Activate New Authenticator</button>
      <form method="POST" action="<?=SELF?>" style="margin:0;"><input type="hidden" name="action" value="chg_totp_cancel"><button type="submit" class="btn btn-gh"><i class="fas fa-xmark"></i> Cancel</button></form>
    </div>
  </form>
</div></div>
<?php else: ?>
<div class="pc mt12" style="border-top:3px solid var(--purple);"><div class="ph" style="color:#d8b4fe;background:rgba(168,85,247,.07);"><i class="fas fa-shield-halved"></i> Change Authenticator (2FA)</div><div class="pb">
<form method="POST" action="<?=SELF?>"><input type="hidden" name="action" value="chg_totp_step1">
  <div class="fg">
    <div class="fgr"><label class="flb">Current Password</label><input class="fc" type="password" name="cur_pass" required placeholder="Enter your password"></div>
    <div class="fgr"><label class="flb">Current TOTP Code</label><input class="fc ainp otp" style="letter-spacing:6px;font-size:18px;font-weight:900;" type="text" name="cur_totp" maxlength="6" placeholder="000000" inputmode="numeric" required></div>
  </div>
  <div class="div"></div><button type="submit" class="btn btn-pu"><i class="fas fa-shield-halved"></i> Verify &amp; Get New QR</button>
</form>
</div></div>
<?php endif; ?>
</div>

<?php endif; ?>

  </div><!-- /ct -->
</div><!-- /mn -->
</div><!-- /layout -->

<!-- MOBILE NAV -->
<nav class="mobnav">
  <div class="mni-row">
    <a href="<?=SELF?>?tab=dashboard" class="mni <?=$tab==='dashboard'?'on':''?>"><i class="fas fa-house-chimney"></i>Home</a>
    <a href="<?=SELF?>?tab=all_app" class="mni <?=$tab==='all_app'?'on':''?>"><i class="fas fa-plus"></i>Add</a>
    <a href="<?=SELF?>?tab=manage" class="mni <?=$tab==='manage'?'on':''?>"><i class="fas fa-layer-group"></i>Apps</a>
    <a href="<?=SELF?>?tab=homepage_seo" class="mni <?=$tab==='homepage_seo'?'on':''?>" style="<?=$tab==='homepage_seo'?'color:var(--green2)':''?>"><i class="fas fa-magnifying-glass-chart"></i>SEO</a>
    <a href="<?=SELF?>?tab=settings" class="mni <?=$tab==='settings'?'on':''?>"><i class="fas fa-sliders"></i>Settings</a>
  </div>
</nav>
<?php endif; ?>

<script>
function sbOpen(){document.getElementById('sb').classList.add('on');document.getElementById('sbov').classList.add('on');document.body.style.overflow='hidden';}
function sbClose(){document.getElementById('sb').classList.remove('on');document.getElementById('sbov').classList.remove('on');document.body.style.overflow='';}
function sTag(ti,ci,t,c){var tf=document.getElementById(ti),cf=document.getElementById(ci);if(tf)tf.value=t;if(cf)cf.value=c;}
function previewIndexTags(){
  var inp=document.getElementById('it_inp'),sc=document.getElementById('it_preview_scroll'),bar=document.getElementById('it_preview_bar');
  if(!inp||!sc||!bar)return;
  var tags=inp.value.split(',').map(function(s){return s.trim();}).filter(Boolean);
  sc.innerHTML='';
  tags.forEach(function(t){var s=document.createElement('span');s.className='tpill';s.innerHTML='<i class="fas fa-hashtag"></i>'+t.replace(/</g,'&lt;');sc.appendChild(s);});
  bar.style.display=tags.length?'flex':'none';
}
function previewPageTags(inputId,previewId){
  var inp=document.getElementById(inputId);
  var bar=document.getElementById(previewId);
  var sc=document.getElementById(previewId.replace('preview','preview_scroll'));
  if(!inp||!bar||!sc)return;
  var tags=inp.value.split(',').map(function(s){return s.trim();}).filter(Boolean);
  sc.innerHTML='';
  tags.forEach(function(t){var s=document.createElement('span');s.className='tpill';s.innerHTML='<i class="fas fa-hashtag"></i>'+t.replace(/</g,'&lt;');sc.appendChild(s);});
  bar.style.display=tags.length?'flex':'none';
}
var _allFiles=[];
function handleFiles(files){if(!files||!files.length)return;for(var i=0;i<files.length;i++){if(files[i].name.toLowerCase().endsWith('.json'))_allFiles.push(files[i]);}renderFileList();}
function renderFileList(){
  var wrap=document.getElementById('fileListWrap'),fl=document.getElementById('fileList'),fc=document.getElementById('fcNum'),btn=document.getElementById('submitBtn'),st=document.getElementById('submitTxt');
  if(!wrap)return;
  if(!_allFiles.length){wrap.style.display='none';btn.disabled=true;btn.style.opacity='.4';btn.style.pointerEvents='none';return;}
  wrap.style.display='block';fc.textContent=_allFiles.length;btn.disabled=false;btn.style.opacity='1';btn.style.pointerEvents='auto';
  st.textContent='Import '+_allFiles.length+' file'+(+_allFiles.length===1?'':'s');
  fl.innerHTML='';
  _allFiles.slice(0,50).forEach(function(f,i){
    var row=document.createElement('div');row.className='fi';
    row.innerHTML='<span class="fi-ic">&#128196;</span><span class="fi-nm">'+f.name+'</span><span class="fi-sz">'+Math.round(f.size/1024)+'KB</span><button class="fi-rm" type="button" onclick="removeFile('+i+')"><i class="fas fa-xmark"></i></button>';
    fl.appendChild(row);
  });
  if(_allFiles.length>50){var more=document.createElement('div');more.style.cssText='font-size:11px;color:var(--t3);text-align:center;padding:7px;';more.textContent='... and '+(_allFiles.length-50)+' more';fl.appendChild(more);}
}
function removeFile(i){_allFiles.splice(i,1);renderFileList();}
function clearFiles(){_allFiles=[];renderFileList();document.getElementById('fileInput').value='';}
function setMode(m){
  document.getElementById('importModeInput').value=m;
  var sk=document.getElementById('modeSkip'),ov=document.getElementById('modeOver');
  if(m==='skip'){sk.style.borderColor='var(--gold)';sk.style.background='rgba(232,184,75,.1)';sk.style.color='var(--gold)';ov.style.borderColor='var(--b1)';ov.style.background='transparent';ov.style.color='var(--t2)';}
  else{ov.style.borderColor='var(--cyan2)';ov.style.background='rgba(6,182,212,.1)';ov.style.color='var(--cyan2)';sk.style.borderColor='var(--b1)';sk.style.background='transparent';sk.style.color='var(--t2)';}
}
async function startBatchImport(){
  if(!_allFiles.length)return;
  var btn=document.getElementById('submitBtn'),pw=document.getElementById('progressWrap'),pb=document.getElementById('progressBar'),pt=document.getElementById('progressTxt'),pp=document.getElementById('progressPct');
  var ra=document.getElementById('rAdded'),ru=document.getElementById('rUpdated'),rs=document.getElementById('rSkipped'),re=document.getElementById('rErrors'),ew=document.getElementById('errorLogWrap'),el=document.getElementById('errorLog');
  btn.disabled=true;btn.style.opacity='.5';pw.style.display='block';ew.style.display='none';el.innerHTML='';
  var BATCH=15,total=_allFiles.length,done=0,added=0,updated=0,skipped=0,errors=0,allErrors=[];
  for(var i=0;i<total;i+=BATCH){
    var chunk=_allFiles.slice(i,i+BATCH);
    var fd=new FormData();fd.append('action','bulk_import');fd.append('import_mode',document.getElementById('importModeInput').value);fd.append('ajax','1');
    chunk.forEach(function(f,j){fd.append('json_files[]',f);});
    try{
      var resp=await fetch('<?=SELF?>',{method:'POST',body:fd});
      var data=await resp.json();
      done+=chunk.length;added+=data.added||0;updated+=data.updated||0;skipped+=data.skipped||0;errors+=data.errors||0;
      if(data.error_list&&data.error_list.length)allErrors=allErrors.concat(data.error_list);
    }catch(e){done+=chunk.length;errors+=chunk.length;}
    var pct=Math.round((done/total)*100);pb.style.width=pct+'%';pp.textContent=pct+'%';
    pt.textContent='Importing... ('+done+'/'+total+')';
    ra.textContent=added;ru.textContent=updated;rs.textContent=skipped;re.textContent=errors;
  }
  pb.style.width='100%';pp.textContent='100%';pt.textContent='Done! Imported '+total+' file(s)';
  if(allErrors.length){ew.style.display='block';allErrors.forEach(function(e){var row=document.createElement('div');row.className='import-row err';row.innerHTML='<i class="fas fa-xmark"></i>'+e;el.appendChild(row);});}
  btn.disabled=false;btn.style.opacity='1';_allFiles=[];renderFileList();
}
var dz=document.getElementById('dropzone');
if(dz){dz.addEventListener('dragover',function(e){e.preventDefault();this.classList.add('drag');});dz.addEventListener('dragleave',function(){this.classList.remove('drag');});dz.addEventListener('drop',function(e){e.preventDefault();this.classList.remove('drag');handleFiles(e.dataTransfer.files);});}
document.querySelectorAll('.otp').forEach(function(e){e.addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,6);});});
</script>
</body>
</html>
