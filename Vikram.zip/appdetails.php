<?php
 
 header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");

?>

<?php
$hh=$_GET[":"]; if($hh=="!"){$gf="alldetails2";}else{if($hh=="i"){$gf="alldetails3";}else{$gf="alldetails"; }}
$nid=$_GET["!"];

$json = file_get_contents("$gf/$nid.json");
     $json = json_decode($json, true);
        $name= htmlspecialchars($json['name']);  
 $imglink= htmlspecialchars($json['imglink']);  
        $mwith= htmlspecialchars($json['mwith']);  
        $tdown= htmlspecialchars($json['tdown']);  
        $signbo= htmlspecialchars($json['signbo']);   $bonus=$signbo;
        
        $applink= htmlspecialchars($json['applink']); 
        $bigimglink= htmlspecialchars($json['bigimglink']);  
        $chanidv= htmlspecialchars($json['chanidv']); 
        $gameidff= htmlspecialchars($json['gameidff']);  
$madd= htmlspecialchars($json['madd']);  
  $refperapro= htmlspecialchars($json['refperapro']); 
$refcoms= htmlspecialchars($json['refcoms']);  


 $rgegg="alldetails/wmaupchanl.json";  
   $wch=file_get_contents($rgegg);
                          
                          $rgeggrge="alldetails/maupchanl.json";  
                          $mch=file_get_contents($rgeggrge);
                          
                          $rgeggrgergg="alldetails/upchanl.json";  
                          $uch=file_get_contents($rgeggrgergg);
                          
                          $rgeggrgergggr="alldetails/chanl.json";  
                          $rch=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/1websitelink.json";  
                          $weblink=file_get_contents($rgeggrgergggr); 
                          
   
 $result2 = ''; 
$txn = "allappss.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Function to compare $nid for sorting
    function compareNid($a, $b) {
        return $a['nid'] - $b['nid'];
    }

    // Array to hold parsed entries
    $entries = array();

    // Loop through each lifafa entry and parse JSON
    foreach ($pro as $entry) {
        $json = json_decode($entry, true);

        if (json_last_error() === JSON_ERROR_NONE && isset($json['nid'])) {
            $entries[] = $json;
        } }

    // Sort entries based on $nid
    usort($entries, 'compareNid');

    // Loop through sorted entries to generate HTML
    foreach ($entries as $json) {
    $nid = htmlspecialchars($json['nid']);  
    
    $json = file_get_contents("alldetails/$nid.json");
     $json = json_decode($json, true);
        
//rgfd
 $img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['signbo']);   $namee = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);  
 $applinkk= htmlspecialchars($json['applink']); 
   $txnd = "alldetails/$nid.json";       
$txnd = "alldetails/$nid.json";

if ($nidd) {

        $fv = <<<HTML
<li class="app-item_dont_copy_created_by_allappstore_com">
            <div class="app-icon_dont_copy_created_by_allappstore_com-container">
                <img src="{$img}" alt="{$namee}"
                    class="app-icon_dont_copy_created_by_allappstore_com" />
            </div>
            <div class="app-details_dont_copy_created_by_allappstore_com">
                <h6 class="app-title_dont_copy_created_by_allappstore_com">{$namee}</h6>
                <span class="bonus-amount_dont_copy_created_by_allappstore_com">
                    <i class="fa-solid fa-gift"></i> Sign Up Bonus ₹{$bonus}                </span><br>
                <span class="withdrawal-amount_dont_copy_created_by_allappstore_com">
                    <i class="fa-solid fa-building-columns"></i> Min. Withdrawal ₹{$mwithdrawal}                </span>
            </div>
            <a href="appdetails.php?!=$nid&$name">
                <button class="download-button_dont_copy_created_by_allappstore_com">
                    <i class="fa-solid fa-download"></i> Download
                </button>
            </a>
        </li>
HTML;
        $result2 .= $fv;}
    }
} else {
    // If no lifafa entries are found
    $result2 = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}




?>


<!DOCTYPE html><html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

<title><?php echo $name ?>| Get SignUp Bonus Upto ₹<?php echo $signbo ?> | Download Apk | Min Withdraw ₹<?php echo $mwith ?></title>
	<link rel="canonical" href="https://Yonoapps.in/EN-365-YONO" />
  <meta name="description" content="Join <?php echo $name ?> today and receive a bonus ranging from ₹<?php echo $signbo ?>! Enjoy seamless withdrawals with a minimum limit of just ₹<?php echo $mwith ?>. Sign up now and start spinning to win big!" />
  <meta name="keywords" content="<?php echo $name ?>" />
  
  <meta property="og:image:alt" content="<?php echo $name ?>" />
  <meta property="og:url" content="index.php" />
  <meta property="og:title" content="<?php echo $name ?> | Get SignUp Bonus Upto ₹<?php echo $signbo ?> | Download Apk | Min Withdraw ₹<?php echo $mwith ?>" />
  <meta property="og:description" content="Join <?php echo $name ?> today and receive a bonus ranging from ₹<?php echo $signbo ?>! Enjoy seamless withdrawals with a minimum limit of just ₹<?php echo $mwith ?>. Sign up now and start spinning to win big!" />
  <meta name="og:site_name" content="<?php echo $name ?>" />
 
  <meta property="og:locale" content="en_US" />
<meta property="article:modified_time" content="2024-06-20T04:31:06+00:00" />
<meta property="og:updated_time" content="2024-06-20T04:31:06+00:00" />
  <meta property="og:image:type" content="image/webp" />
  <meta property="og:type" content="application" />
  <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="">
    <meta name="twitter:title" content="<?php echo $name ?> | Get SignUp Bonus Upto ₹<?php echo $signbo ?> | Download Apk | Min Withdraw ₹<?php echo $mwith ?>">
    <meta name="twitter:description" content="Join <?php echo $name ?> today and receive a bonus ranging from ₹<?php echo $signbo ?>! Enjoy seamless withdrawals with a minimum limit of just ₹<?php echo $mwith ?>. Sign up now and start spinning to win big!">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="apple-touch-icon" sizes="180x180" href="../fevicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../fevicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../fevicon/favicon-16x16.png">
<link rel="manifest" href="../fevicon/site.php">
<link rel="mask-icon" href="../fevicon/safari-pinned-tab.php" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">
  <meta name="robots" content="index, follow" />
<script type="application/ld+json">
{
    "@context": "http:\/\/schema.org",
    "@type": "SoftwareApplication",
    "name": "EN 365 YONO",
    "operatingSystem": "ANDROID",
    "applicationCategory": "Game",
    "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.7",
        "reviewCount": "110008"
    },
    "offers": {
        "@type": "Offer",
        "price": "0.00",
        "priceCurrency": "INR"
    },
    "description": "Join <?php echo $name ?> today and receive a bonus ranging from \u20b935 to \u20b9500! Enjoy seamless withdrawals with a minimum limit of just \u20b9100. Sign up now and start spinning to win big!",
    "url": "https:\/\/Yonoapps.in/EN-365-YONO",
    "datePublished": "2024-07-10",
    "softwareVersion": "1.0.0",
    "releaseNotes": "Bug fixes and improvements",
    "fileSize": "31 MB"
}
</script><style>
          @import url("https://yonoapps.in/ajax/libs/font-awesome/6.5.1/css/all.min.css");.custom-button{width:100%;max-width:350px;height:30px;border:1px solid #08c;border-radius:25px;background-color:#fff;color:#08c;font-size:15px;font-weight:700}.wt,[class~=tgi]{position:fixed;}[class~=tgi]{right:-9.5%;}.wt,[class~=tgi]{top:0;}.wt,[class~=tgi]{bottom:0;}.wt,[class~=tgi]{margin-left:auto;}[class~=tgi]{margin-bottom:17rem;}[class~=tgi],.wt{margin-right:auto;}[class~=tgi]{margin-top:17rem;}.wt,[class~=tgi]{width:6.5rem;}.wt,[class~=tgi]{height:3rem;}[class~=tgi],.wt{z-index:999;}.wt{right:-8.8%;}.wt{margin-bottom:14.7rem;}.wt{margin-top:14.7rem;}[class~=custom-buttonW]{width:100%;}[class~=custom-buttonW]{max-width:3.645833333in;}[class~=custom-buttonW]{height:1.875pc;}[class~=custom-buttonW]{border-left-width:.010416667in;}[class~=custom-buttonW]{border-bottom-width:.010416667in;}[class~=custom-buttonW]{border-right-width:.010416667in;}[class~=custom-buttonW]{border-top-width:.010416667in;}[class~=custom-buttonW]{border-left-style:solid;}[class~=custom-buttonW]{border-bottom-style:solid;}[class~=custom-buttonW]{border-right-style:solid;}[class~=custom-buttonW]{border-top-style:solid;}[class~=custom-buttonW]{border-left-color:#25d366;}[class~=custom-buttonW]{border-bottom-color:#25d366;}[class~=custom-buttonW]{border-right-color:#25d366;}[class~=custom-buttonW]{border-top-color:#25d366;}[class~=custom-buttonW]{border-image:none;}[class~=custom-buttonW]{border-radius:.260416667in;}[class~=custom-buttonW]{background-color:#fff;}[class~=custom-buttonW]{color:#25d366;}[class~=custom-buttonW]{font-size:11.25pt;}[class~=custom-buttonW]{font-weight:700;}[class~=tgi] img{width:63%;}.wt img{width:68%;}@media (max-width:768px){.custom-button{max-width:none}}[class~=app-item_dont_copy_created_by_allappstore_com]::before{counter-increment:app-counter;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{content:counter(app-counter) ".";}[class~=app-item_dont_copy_created_by_allappstore_com]::before{font-weight:bold;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{font-size:1em;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{margin-right:.010416667in;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{color:#899499;}[class~=telegram-card]{animation:telegram-border-animation 1s infinite;}@keyframes telegram-border-animation{0%{border-color:transparent;}50%{border-color:#004f7a;}100%{border-color:transparent;}}[class~=answer8262]::before{content:"Answer. ";}[class~=seoquake-nofollow]{display:inline-flex;}[class~=seoquake-nofollow]{align-items:center;}[class~=seoquake-nofollow],[class~=answer8262]::before{font-weight:bold;}[class~=seoquake-nofollow]{justify-content:center;}[class~=seoquake-nofollow]{font-size:1rem;}#iTable{border-collapse:collapse;}h2.relatedapps{font-size:.208333333in;}#iTable{width:94%;}h2{padding-left:.4375pc;}#iTable{margin-left:auto;}[class~=seoquake-nofollow]{text-decoration:none;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{width:20%;}h2{padding-bottom:.4375pc;}[class~=seoquake-nofollow]{padding-left:1.25pc;}.AllAppStore_Com_Slider .AllAppStore_ticker .title,h2.relatedapps{text-align:center;}h2.relatedapps{padding-left:1.5625pc;}#iTable td:not(:last-child){border-right-width:.020833333in;}h2.relatedapps,#iTable td:not(:last-child){border-right-style:solid;}[class~=seoquake-nofollow]{padding-bottom:3.75pt;}h2{padding-right:.4375pc;}[class~=seoquake-nofollow]{padding-right:1.25pc;}h2.relatedapps{color:white;}h2.relatedapps{background:radial-gradient(circle at 10% 20%,#005d85 0%,#00b595 90%);}h2.relatedapps{border-left-width:.1875pc;}[class~=seoquake-nofollow]{padding-top:3.75pt;}#iTable{margin-bottom:0;}[class~=seoquake-nofollow]{border-radius:.125pc;}h2.relatedapps{border-bottom-width:.1875pc;}[class~=seoquake-nofollow]{flex-shrink:0;}[class~=seoquake-nofollow]{transition:all .3s ease-in-out;}h2.relatedapps{border-right-width:.1875pc;}[class~=seoquake-nofollow]{color:white !important;}#iTable{margin-right:auto;}h2{padding-top:.4375pc;}.ul{font-size:11.25pt;}h2{text-align:left;}h2{border-bottom-width:.125pc;}.ul{padding-top:6%;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{font-size:.3rem;}h2.relatedapps{border-top-width:.1875pc;}.ul{padding-right:5%;}.AllAppStore_Com_Slider .AllAppStore_ticker .title p{font-size:.135416667in;}#iTable td:not(:last-child){border-right-color:#ddd;}h2,h2.relatedapps{border-bottom-style:solid;}.ul{padding-bottom:6%;}.ul{padding-left:5%;}h2.relatedapps{border-left-style:solid;}[class~=image2]{position:absolute;}h2.relatedapps{border-top-style:solid;}#iTable{margin-top:0;}[class~=parent],[class~=question8262]{position:relative;}.red-disclaimer-box{border-radius:3pt;}h2.relatedapps{border-left-color:black;}.red-disclaimer-box{color:black;}#iTable{border-radius:7.5pt;}h2.relatedapps{border-bottom-color:black;}.red-disclaimer-box{font-family:"Arial",sans-serif;}h2.relatedapps{border-right-color:black;}.red-disclaimer-box{font-size:8.25pt;}h2.relatedapps{border-top-color:black;}h2{border-bottom-color:#dedede;}h2,#iTable td:not(:last-child),h2.relatedapps{border-image:none;}.red-disclaimer-box{line-height:1.5;}h2{border-left-width:.0625pc;}[class~=question8262],[class~=mr193]{font-size:1pc;}[class~=question8262]{color:#fff;}#iTable{background:linear-gradient(to right,#e0e0e0,#f9f9f9);}.AllAppStore_Com_Slider .AllAppStore_ticker .title p{line-height:.4rem;}[class~=question8262]{background-color:#3f51b5;}.AllAppStore_Com_Slider .AllAppStore_ticker .title p,[class~=mr193]{font-weight:bold;}[class~=question8262]{padding-left:9px;}[class~=question8262]{padding-right:17.25pt;}[class~=question8262]{padding-top:9px;}#iTable tr:nth-child(even){background-color:#f9f9f9;}h2{border-left-style:solid;}[class~=question8262]{padding-bottom:.5625pc;}h2{border-left-color:#00f;}[class~=question8262]{border-radius:.052083333in;}[class~=question8262]{margin-bottom:.09375in;}h2{font-size:.25in;}[class~=mr193]{text-align:center;}[class~=mr193]{color:#00c700;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{background-color:#0013a4;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{color:#ff0;}*,body{margin:0}.center-text,.small-center-text{line-height:1.5;text-align:center}.footer-link,.link-style{text-decoration-line:underline}.center .downBtn,.center-text,.hed,.menu-container,.navbar a,.popup-content,.small-center-text{text-align:center}.footbtn,.hed1,.menu-item{box-sizing:border-box}.app-info,.bodylook,.navbar a,body{font-family:Arial,sans-serif}.close-btn,.custom-image,.icon,.popup-trigger,.tabs .tab{cursor:pointer}#iTable a,.close-button,.header-text,.navbar a,a{text-decoration:none}.container{width:90%;max-width:1200px;margin:0 auto;padding:20px}@media only screen and (max-width:768px){.container{padding:10px}}@media only screen and (max-width:480px){.container{padding:5px}}h3,h4,p{padding:9px}li{padding-left:18px;paddin-right:18px;padding-top:3px;padding-bottom:3px;font-size:15px}ul{padding:18px}ol{padding-left:11px;paddin-right:11px}h2{color:red;border-left-width:6px;padding-block:10px;margin-top:0}table,td,th{border:1px solid;padding:3px}.allappstore_img{border:1px solid #ddd;border-radius:4px;padding:5px;width:90%;display:block;margin:10px auto}*,.note{padding:0}*{list-style:none}.note{color:#c9c3b5;font-size:.24rem}.bodylook{background-color:#fff;border:5px solid #000;padding:2%}.footbtn a img,.top img{width:100%;display:block}.center .downBtn{width:125%;padding-top:0;margin:120% 24% 37% -12%}.center .downBtn img{width:70%;display:block;text-align:center;margin:0 auto;animation:1.8s infinite moves}.footbtn a,.kf img,.swiper-container .swiper-slide,.swiper-container .swiper-slide img,.top1 img,.top2 img,.top3 img{width:100%}.swiper-container{width:100%;margin:0 auto;overflow:hidden}a{-webkit-tap-highlight-color:transparent}.top1 img{margin-top:3%}.word{width:94%;margin:0 auto}.word p{font-size:.7rem;color:#ddcda6}.footbtn{width:750px;position:fixed;bottom:0;left:0;right:0;margin:auto;display:flex;justify-content:space-between;align-items:center;padding:0;z-index:99}.kf,.tg{z-index:999;position:fixed;top:0;bottom:0}.custom-image{border-radius:3px;border:2px solid #73ad21;margin:0 auto;display:block;width:100%}.kf{right:0;margin:5rem auto;width:3rem;height:3rem}.download-btn-img{margin:0 auto;display:block;width:261px;height:62.0055px}.tg{right:-3%;margin:9rem auto;width:6.5rem;height:3rem}.tg img{width:75%}.hed{border-radius:10px;font-size:17px;padding:5px 25px;color:#fff;background:radial-gradient(circle at 10% 20%,#005d85 0,#00b595 90%);border:3px solid #000}.hed1{border-style:double solid;height:auto;width:100%;margin:auto;color:purple;padding:5px;font-size:20px;display:inline-block;background-color:#fbeeff;border-width:5px}#customers tr:nth-child(2n),.popup-trigger{background-color:#f2f2f2}#customers{font-family:Arial,Helvetica,sans-serif;border-collapse:collapse;width:100%}#customers td,#customers th{border:1px solid #ddd;padding:8px}#customers tr:hover{background-color:#ddd}#customers th{padding-top:12px;padding-bottom:12px;text-align:left;background-color:#04aa6d;color:#fff}.telegram-image{margin:0 auto;display:block;width:268px;height:51.4802px}.popup,.popup-overlay{width:100%;height:100%}.text-shadow{text-shadow:-3px 2px 20px rgba(0,255,0,.45)}.color-text{color:#41a85f}.q-heading{color:purple;font-size:1.2rem;margin-top:1rem;margin-bottom:.5rem}.popup-trigger{display:inline-block;margin:10px;padding:5px;border:1px solid #000}.popup{display:none;position:fixed;top:0;left:0}.answer8262.show,.close-button,.content.active,.navbar a,.popup:target{display:block}.popup-overlay{position:absolute;background:rgba(0,0,0,.7)}.popup-content{position:relative;background:#fff;padding:20px;border-radius:8px;width:70%;max-width:600px;margin:10% auto}body{padding:0}.close-button{margin:20px auto;padding:10px 20px;background-color:red;color:#fff;border-radius:5px}.center-text{font-size:1rem;font-weight:700}.small-center-text{font-size:.7rem;font-weight:700}.menu-item,.navbar a{font-size:11px;font-weight:700}.link-style{color:#f3eccd}.main-background{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;border:2px solid #0b6115}.footer-link{color:#fff}.navbar{color:#fff;display:flex;justify-content:center;flex-wrap:nowrap}.navbar a{white-space:nowrap;float:left;color:#000;padding:5px;border-right:2px solid #e5e4e2}.menu-container{display:none;background:linear-gradient(to top,#d3d3d3 0,#d3d3d3 1%,#e0e0e0 26%,#efefef 48%,#d9d9d9 75%,#bcbcbc 100%);padding:20px}.menu-item{background:linear-gradient(109.6deg,#1b1b4f 11.2%,#78c9f4 100.2%);color:#fff;padding:7px 14px;margin:8px;display:inline-block;width:30%;border-radius:8px}.menu-row{display:flex;justify-content:space-around}.icon{display:block;text-align:right;padding:2px 6px;color:#fff;font-size:18px;font-weight:700}.header{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;display:flex;justify-content:space-between;align-items:center;padding:5px}#iTable th,.navbar,.tabs .tab{background-color:#f2f2f2}.logo-top{width:35px;height:auto}.telegram-top{width:54px;height:auto}.header-text{flex-grow:1;margin:0 2px;text-align:left;font-weight:700;font-size:25px;color:#fff!important}.navbar{border-top:1px solid #001e00;border-bottom:2px solid #001e00;overflow:hidden}.navbar a:last-child{border-right:none}.navbar a.active,.navbar a:hover{background:linear-gradient(114.3deg,#137e39 .2%,#08415b 68.5%);color:#fff}.app-list_dont_copy_created_by_allappstore_com{list-style-type:none;counter-reset:app-counter;padding:0;position:relative;margin:0}.app-item_dont_copy_created_by_allappstore_com{display:flex;align-items:center;background-color:#f9f9f9;border-radius:10px;margin-bottom:5px;padding:5px;counter-increment:section;box-shadow:0 3px 6px rgba(0,0,0,.1)}.app-icon_dont_copy_created_by_allappstore_com-container{padding:2px}.app-icon_dont_copy_created_by_allappstore_com{width:65px;border-radius:5px}.install-button,.sticky-ad{width:100%;box-sizing:border-box}.app-details_dont_copy_created_by_allappstore_com{flex-grow:1;margin-left:8px}.app-title_dont_copy_created_by_allappstore_com{font-size:1.15em;margin:0 0 5px}.bonus-amount_dont_copy_created_by_allappstore_com{color:red;font-size:12px;margin:0;font-weight:700}.mrnew{color:grey;font-weight:900;font-size:17px;margin:0}.download-count{color:#ffaa1d;font-weight:600;font-size:13px;margin:0}.withdrawal-amount_dont_copy_created_by_allappstore_com{color:green;font-size:12px;font-weight:700;margin:0}.download-button_dont_copy_created_by_allappstore_com{display:inline-block;padding:.63em .53em;margin:0 .1em .1em 0;background-image:radial-gradient(100% 100% at 100% 0,#5adaff 0,#5468ff 100%);border-radius:.33em;box-sizing:border-box;text-decoration:none;font-weight:700;box-shadow:rgba(45,35,66,.4) 0 2px 4px,rgba(45,35,66,.3) 0 7px 13px -3px,rgba(58,65,111,.5) 0 -3px 0 inset;box-sizing:border-box;font-size:14px;color:#fff;text-shadow:0 .04em .04em rgba(0,0,0,.35);text-align:center;transition:.2s}.centerio,.centerio1,h3.hindi-translate{text-decoration:underline}a.download-button_dont_copy_created_by_allappstore_com:hover{border-color:#fff}.red-disclaimer-box{background-color:#fff7f7;border:2px solid #ff5733;padding:10px;margin:10px}h2.relatedapps{padding-top:5px;padding-right:25px;border-radius:10px;padding-bottom:5px}h3.hindi-translate{border-radius:1px;font-size:20px;text-align:center;color:#00308f;padding:5px 25px;background:linear-gradient(to bottom,#f93,#fff 50%,#138808);border:3px solid #00308f}.sticky-ad{position:fixed;bottom:0;left:0;background:#f4f4f4;padding:2px}.ad-content{position:relative;max-width:1200px;margin:auto;display:flex;justify-content:center;align-items:center}.close-btn{position:absolute;right:-5px;top:-25px;background-color:red;color:#fff;border:none;font-size:10px;font-weight:700;padding:5px 10px;border-radius:5px}img{max-width:100%;height:auto}.centerio{text-align:center;font-weight:700;font-size:16px}.centerio1{font-weight:700;font-size:13px}.app-container,.app-container2{max-width:768px;margin:20px auto;background-color:#fff;padding:10px;box-shadow:0 0 10px rgba(0,0,0,.1)}.app-header,.app-header1{display:flex;align-items:center;padding:20px}.header-image{flex-basis:60%;text-align:left}.header-image img{width:80%;border-radius:25px}.header-content,.header-content12{flex-basis:40%}.age-rating,.rating-info{margin:12px 0}.age-rating span,.rating-info span,.text1{display:inline-block;margin-right:10px}.seoquake-nofollow i,.tabs .tab{margin-right:5px}.install-button{background-color:#00f;color:#fff;padding:10px 20px;border:none;cursor:pointer;font-weight:700;border-radius:20px;margin-top:10px}.app-info{display:flex;flex-direction:column;align-items:center}.rating-info{display:flex;align-items:center;font-size:18px}.download-block,.rating-block,.reviews-block{display:flex;flex-direction:column;align-items:center;margin:5px}.separator{color:#ccc;margin:0 10px}.text1{font-size:15px}.tabs{display:flex;justify-content:center;text-align:center;font-weight:700;font-size:16px;margin:0 auto}.tabs .tab{flex:1;padding:8px;border:2px solid #ddd;color:#000}.tabs .tab:last-child{margin-right:0}.content{width:auto;margin:0 auto;display:none}.group-card,.group-card1{margin-bottom:20px;position:relative;align-items:center;padding:7px;overflow:hidden}.join-text,.join-text1{margin-left:10px;font-weight:700}.tabs .tab.active{background:linear-gradient(109.6deg,#3d79b0 11.3%,#2342a4 91.1%);color:#fff}.group-card{border:2px solid transparent;border-radius:5px;background:#f0f8ff;display:flex;justify-content:space-between}.group-card1{border:2px solid transparent;border-radius:5px;background:#f0fff0;display:flex;justify-content:space-between}.telegram-card1{animation:1s infinite telegram-border-animation}@keyframes telegram-border-animation{0%,100%{border-color:transparent}50%{border-color:#004f7a}}.telegram-card .seoquake-nofollow{background:#004f7a}.telegram-card1 .seoquake-nofollow{background:#2b7a40}.seoquake-nofollow:hover{transform:scale(1.05)}nofollow1{background:#006942}.icon-telegram{font-size:24px;color:#004f7a}.icon-telegram1{font-size:24px;color:#006942}.join-text{color:#004f7a;font-size:.9rem!important}.join-text1{color:#006942;font-size:1rem!important}.header9272 h1{text-align:center;color:#fff;margin-top:0}.container8262{max-width:600px;margin:16px auto;padding:8px;background-color:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}.faq-item{margin-bottom:20px}.question8262::after{content:"+";position:absolute;top:50%;right:8px;transform:translateY(-50%);font-weight:700}.answer8262{font-size:14px;color:#333;padding:13px;border-radius:5px;display:none}.question8262::before{content:"Q. " attr(data-question-number) ": ";font-weight:700}#iTable{overflow:hidden;padding:20px}#iTable th{padding:12px;text-align:left;font-size:17px;color:red}#iTable td{padding:10px;font-size:14px;border-bottom:2px solid #ddd}#iTable td:first-child{font-weight:700}#iTable a{color:#00f;font-weight:700}.AllAppStore_Com_Slider{border:1px dashed red;background-color:#000}.AllAppStore_Com_Slider .AllAppStore_ticker{display:flex;align-items:center;flex-wrap:wrap}.AllAppStore_Com_Slider .AllAppStore_ticker .news{width:80%;margin:-2rem 0}.AllAppStore_Com_Slider .AllAppStore_ticker .news marquee{font-size:12px;color:#fff;font-weight:600;padding-top:.18rem;line-height:.4rem}</style>
<script>
function toggleMenu() {
  var x = document.getElementById("menuContainer");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
function shareContent() {
  // Extract the domain name from the URL
  var domain = window.location.hostname;
  // Attempt to get the meta description content
  var metaElement = document.querySelector("meta[name=description]");
  var metaDescription = metaElement ? metaElement.getAttribute("content") : '';
  // Create the share text in the format "Title\n(domain) - (description)"
  var shareText = document.title + "\n\n" + "AllYonoAppsT.com" + (metaDescription ? " - " + metaDescription : '') + "\n" + "» ";
  // Check if the Web Share API is supported
  if (navigator.share) {
    navigator.share({
      title: document.title,
      text: shareText,
      url: window.location.href
    }).then(() => {
      console.log('Thanks for sharing!');
    })
    .catch(console.error);
  } else {
    // Fallback for browsers that do not support navigator.share
    alert('Web Share API is not supported in your browser.');
  }
}
function closeStickyAd() {
  document.getElementById('stickyAd').style.display = 'none';
}
function showTab(selectedTab) {
  var tabs = document.querySelectorAll(".tabs .tab");
  var contents = document.querySelectorAll(".content");
  tabs.forEach(function(tab) {
    if (tab.id === selectedTab + "Tab") {
      tab.classList.add("active");
    } else {
      tab.classList.remove("active");
    }
  });
  contents.forEach(function(content) {
    if (content.id === selectedTab) {
      content.classList.add("active");
    } else {
      content.classList.remove("active");
    }
  });
}
document.addEventListener('DOMContentLoaded', function() {
  const questions = document.querySelectorAll('.question8262');
  questions.forEach((question, index) => {
    question.addEventListener('click', () => {
      const answer = question.nextElementSibling;
      answer.classList.toggle('show');
    });
  });
});</script>
      <script type="application/ld+json">{"@context":"https://schema.org","@type":"HowTo","name":"How to Download and Get Started with EN 365 YONO","description":"To download and get started with EN 365 YONO, follow these simple steps:","step":[{"@type":"HowToStep","name":"Tap on the Download to Play button","text":"Tap on the Download to Play button which will redirect you to the EN 365 YONO APK."},{"@type":"HowToStep","name":"Download the EN 365 YONO APK","text":"Once redirected, download the EN 365 YONO APK from the provided link."},{"@type":"HowToStep","name":"Install the app","text":"After the APK is downloaded, tap on Install to install the app on your device."},{"@type":"HowToStep","name":"Open the EN 365 YONO app","text":"Open the EN 365 YONO app upon successful installation."},{"@type":"HowToStep","name":"Register and get a Sign Up Bonus","text":"Register and get a Sign Up Bonus to kickstart your gaming experience!"}]}</script><script type="application/ld+json">{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"What is the minimum withdrawal amount on EN 365 YONO?","acceptedAnswer":{"@type":"Answer","text":"The minimum withdrawal amount on EN 365 YONO is ₹100, available through UPI or bank transfer."}},{"@type":"Question","name":"How long does it take to receive withdrawals on EN 365 YONO?","acceptedAnswer":{"@type":"Answer","text":"Withdrawals on EN 365 YONO are typically credited to your bank or UPI account instantly or within 48 hours."}},{"@type":"Question","name":"How many withdrawal transactions are allowed per day on EN 365 YONO?","acceptedAnswer":{"@type":"Answer","text":"Users are permitted up to 10 withdrawal transactions per day on EN 365 YONO."}},{"@type":"Question","name":"What should I do if I do not receive my withdrawal within 48 hours on EN 365 YONO?","acceptedAnswer":{"@type":"Answer","text":"In case of any delay in receiving your withdrawal, please reach out to EN 365 YONO customer service for assistance."}},{"@type":"Question","name":"What are the benefits of the EN 365 YONO referral program?","acceptedAnswer":{"@type":"Answer","text":"The EN 365 YONO referral program offers bonuses ₹5 for each referral, along with 60% commissions based on your friends gameplay tax amounts and 1% commission on your friends bettings amounts."}}]}</script></head>
<body>
<!-- Header start for  (do not copy without permission from the website owner; otherwise, legal actions may be taken against you) -->
<div class="header">
    <a href="index.php">
      <img style="border-radius:10px" class="logo-top" src="logo.jpg" alt="Yono Apps Logo">
    </a>
    <a href="index.php">
      <div class="header-text">AllYonoAppsT</div>
    </a>
    <a href="https://t.me/RupayWala_Support" target="_blank" rel="noopener noreferrer">
      <img class="telegram-top" src="https://AllRummyStore.com/wp-content/uploads/2023/12/telegram-rummybonusapp-2.png" alt="Yono Apps Telegram"></a>
    <div class="icon" onclick="toggleMenu()">&#9776; Menu</div>
  </div>
  <div class="menu-container" id="menuContainer">
    <div class="menu-row">
      <a href="index.php" class="menu-item"><i class="fa-solid fa-house"></i> Home</a>
      <a href="about-us.php" class="menu-item"><i class="fa-solid fa-clipboard-user"></i> About</a>
      <a href="contact-us.php" class="menu-item"><i class="fa-solid fa-envelope-circle-check"></i> Contact</a>
    </div>
    <div class="menu-row">
      <a href="privacy-policy.php" class="menu-item"><i class="fa-solid fa-shield-halved"></i> Privacy Policy</a>
      <a href="terms-and-conditions.php" class="menu-item"><i class="fa-solid fa-circle-exclamation"></i> Terms &#38;
        conditions</a>
      <a href="disclaimer.php" class="menu-item"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
    </div>
  </div>
    <div class="navbar">
    <a href="index.php" class="active"><i class="fa-solid fa-house"></i> Home</a>
    <a href="about-us.php"><i class="fa-solid fa-address-book"></i> About</a>
    <a href="contact-us.php"><i class="fa-solid fa-envelope"></i> Contact Us</a>
    <a href="disclaimer.php"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
    <a href="https://t.me/RuPaYWalaTeaM" target="_blank" rel="noopener noreferrer"><i
        class="fa-brands fa-telegram"></i> Join Telegram</a>
  </div>
  <!-- header end -->

<div class="app-container2">
  <div class="app-header1">
    <div class="header-image">
      <img src="<?php echo $imglink ?>" alt="<?php echo $name ?> Logo">
    </div>
    <div class="header-content12">
      <h1><?php echo $name ?></h1>
<a href="<?php echo $applink ?>"><p style="color:blue; font-weight:bold;"><?php echo $name ?></p></a>
    </div>
  </div>
  <div class="app-info">
    <div class="rating-info">
        <div class="rating-block">
            <span><i class="fa-solid fa-star"></i> <b>4.1</b></span>
            <span class="text1">Ratings</span>
        </div>
        <div class="separator">|</div>
        <div class="download-block">
            <span><i class="fa-solid fa-download"></i></span>
            <span class="text1">                            <?php echo $tdown ?></span>
        </div>
        <div class="separator">|</div>
        <div class="reviews-block">
            <span><i class="fa-solid fa-cart-plus"></i></span>
            <span class="text1">Free</span></div>
            <div class="separator">|</div>
        <div class="reviews-block">
            <span><b>₹<?php echo $signbo ?></b></span>
            <span class="text1">Bonus</span>
        </div>
    </div>
  </div><a href="<?php echo $applink ?>">
  <button class="install-button">DOWNLOAD <?php echo $name ?> APK</button></a>
  <br>
  <br>
  <div style="text-align: center;">
  <a href="https://t.me/RuPaYWalaTeaM">
  <button class="custom-button"><i class="fa-brands fa-telegram"></i> Join Our Telegram Channel <i class="fa-brands fa-telegram"></i></button></a>
</div>
</div>
  <div class="app-header1">
  <br>
   <!-- <div style="text-align: center;">
  <a href="..//whatsapp-join.php">
  <button class="custom-buttonW"><i class="fa-brands fa-square-whatsapp"></i>  Follow On WhatsApp Channel For New App  <i class="fa-brands fa-square-whatsapp"></i></i></button></a>
</div>
<br> -->
 <!-- <div style="text-align: center;">
  <a href="..//telegram-join.php">
  <button class="custom-button"><i class="fa-brands fa-telegram"></i>  Join Telegram For FREE Gift Promo Codes  <i class="fa-brands fa-telegram"></i></button></a>
</div> -->
</div>
<h2 class="relatedapps"><i class="fa-solid fa-circle-chevron-down"></i> Other Related Apps <i class="fa-solid fa-circle-chevron-down"></i></h2>
  <ul class="app-list_dont_copy_created_by_allappstore_com">
  <style>

.navbar a{
font-size: 12px;
}
</style>
<style>  
.recomended h2{    color: white;
    background-color: #d10000;
    font-size: 20px;
    font-weight: 600;
    text-align: center;
    margin-top: 0.15rem;
    margin: 0 0.05rem;
    border-radius: 10px;
    border: 2px solid #000;

    
}
.app-header1{
        padding-bottom: 0px;
}
.blockquote-logo img{
        width: 30%;
    margin-left: 35%;
}
.all-rummy-apps-faq{
    margin-bottom:10px;
}
.recomended{
    padding-top:0px;
        padding: 10px;
}
.linkInfo, .recomended h2{
      font-weight: 600;
    color: #fff;  
}
blockquote{
            margin-bottom:6px;
    display: block;
    background-color: rgba(112, 112, 112, 0.133);
    padding-bottom:6px;
   margin-left:6px;
   margin-right:6px;
}
blockquote h2{    
        margin: .1rem 0 .1rem 0;
    font-size: 18px;
    font-weight: bold;
    line-height: 20px;
    padding: 10px;
    border-left: blue 2px solid;
    border-right: blue 2px solid;
    color: red;
    text-transform: capitalize;
}
blockquote p{    font-size: 16px;
    line-height: 25px;
    padding: 10px;
    text-transform: capitalize;
        
}
blockquote .LootEarning-apk-icon img{
        position: absolute;
    margin-top: -.1rem;
    margin-left: 43%;
    width: 10%;
    height: .7rem;
    border: rgb(255, 255, 255) solid .04rem;
    border-radius: 10px;
}
blockquote .AllRummyApps_landscape{
        align-items: center;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    margin-top: .25rem;
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 95%;
}
.blockquote-download img{
       width: 60%;
    margin-left: 20%; 
}
#lootearning{
        font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    margin-top: .2rem;
}
.all-rummy-apps-faq ol{
        list-style: none;
    counter-reset: item;
    margin-left: .6rem;
    margin-top: .1rem;
}
.all-rummy-apps-faq li{
        counter-increment: item;
    font-size: .28rem;
    line-height: .45rem;
    margin-right: .1rem;
    text-transform: capitalize;
}
blockquote .AllRummyApps_download_btn{
        display: block;
    margin-left: auto;
    margin-right: auto;
    width: 60%;
    height: .9rem;
  /*  background-image: url("Z_img/all-rummy-apps-download-btn.webp");*/
    background-size: 100% 100%;
    background-repeat: no-repeat;
}
    .install-button{
            
    color: #fff;
    padding: 8px 20px;
    border: none;
    cursor: pointer;
    font-weight: 900;
    border-radius: 30px;
    margin-top: 10px;
    border: 1px solid #000;
    }
    .header-image img{
            width: 60%;
    border-radius: 25px;
    }
    .header-content, .header-content12{
            flex-basis: 60%;
    text-align: center;
    margin-left: -50px;
    }
    .header-content12 h1{
            font-size: 25px;
    font-weight: 900;
    }
    .header-content12 p{
            color: green;
    font-weight: 900;
    font-size: 10px;
    }
    .header-content12 a{
            text-decoration: none;
    }
    h2.relatedapps{
            margin: 0px 10px;
    }
</style>



           
            <?php echo $result2 ?>
                           </ul>  <h2 class="relatedapps">More Information</h2>
<br>
<p><b style="color:red;">Notice:</b> This pages information is current as of the last update on <b>20-06-2024</b>. We are not responsible for any discrepancies or issues encountered with the app thereafter. For any assistance or to address issues, please contact <?php echo $name ?> Customer Support<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> < Customer Support. Add funds at your own risk.</p>
<h2 class="relatedapps"><i class="fa-solid fa-circle-chevron-down"></i> Other Related Apps <i class="fa-solid fa-circle-chevron-down"></i></h2>
  <ul class="app-list_dont_copy_created_by_allappstore_com">

    <p>No apps to display.</p>
                       </ul><a href="../index.php">
    <h2 class="relatedapps"><i class="fa-solid fa-house-circle-check"></i> Click Here Go To Home <i class="fa-solid fa-arrow-up-right-from-square"></i></h2></a>
    <div class=red-disclaimer-box>
    <div class=centerio><i class="fa-solid fa-triangle-exclamation"></i> Important Notice</div>
    <p><b>Yonoapps.in</b> do not run or the apps listed here. The <b>rummy app</b> can be addictive and risky financially, so use them carefully. Only for <b>18+ people</b>.
        <p>Please read our <b><a href="../disclaimer.php">Disclaimer page</a></b> and the specific disclaimer for each app.
            <p><b class=centerio1>Alert:</b><b> Rummy</b>, a skill-based game, is banned by the government in <b>Andhra Pradesh, Sikkim, Nagaland, Assam, Arunachal Pradesh, Tamil Nadu, Odisha, and Telangana</b>.</div> 
    <!-- footer Yonoapps.in -->
    <p class="mr193">Thanks For Reading Till...</p>
<div class="AllAppStore_Com_Slider">
            <div class="AllAppStore_ticker">
               <div class="title">
                  <p>Tags:</p>
               </div>
               <div class="news">
                  <marquee>
                     <p><?php echo $name ?>, <?php echo $name ?> mod apk, <?php echo $name ?> 500 bonus, <?php echo $name ?> 15 bonus, <?php echo $name ?> app link, <?php echo $name ?> app, <?php echo $name ?> apk, <?php echo $name ?> app download, new <?php echo $name ?>, <?php echo $name ?> download, <?php echo $name ?> apk download, ind teen patti, <?php echo $name ?> 100, <?php echo $name ?> 20, <?php echo $name ?> bonus, bingo, teen patti, bonus app, new bingo app, <?php echo $name ?> withdrawal, <?php echo $name ?> refer, <?php echo $name ?> deposit, customer support, <?php echo $name ?> new, <?php echo $name ?> 777, <?php echo $name ?> 51 download</p>
                  </marquee>
               </div>
            </div>
         </div>
         <br>
<!--
    This website was created by Aniket.
    Contact to create your website: Telegram @Aniket_Coder
--> 
<footer>
    <div class="group-card telegram-card">
        <span style="display: flex; align-items: center;">
            <i class="fab fa-telegram icon-telegram"></i>
            <span class="join-text">Join Our Telegram Channel</span>
        </span>
        <a class="seoquake-nofollow" href="https://t.me/RuPaYWalaTeaM" rel="nofollow noopener noreferrer" target="_blank">
            <i class="fab fa-telegram"></i> Join Now
        </a>
    </div>

    <div class="main-background">
        <div class="group-card1 telegram-card1">
            <span style="display: flex; align-items: center;">
                <span onclick="shareContent()" class="join-text1">
                    <i class="fa-solid fa-square-share-nodes"></i> Share With Friends!
                </span>
            </span>
            <a class="seoquake-nofollow" onclick="shareContent()">
                <i class="fa-solid fa-share-from-square"></i> Click Here To Share
            </a>
        </div>

        <div class="center-text">
            <a class="link-style" href="../about-us.php" target="_blank">About Us</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="../disclaimer.php" target="_blank">Disclaimer</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="../contact-us.php" target="_blank">Contact Us</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <br><a class="link-style" href="../privacy-policy.php" target="_blank">Privacy Policy</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a class="link-style" href="../terms-and-conditions.php" target="_blank">Terms & conditions</a>
        </div>
        <br>

        <div class="small-center-text">
            <span>
                <h1>Join Our Telegram:</h1>
            </span>
            <a class="footer-link" href="https://t.me/RuPaYWalaTeaM" target="_blank">
                <h3>Click Here</h3>
            </a>
            <br>
            Copyright © 2024 <a href="../index.php" style="color: white;"><strong>AllYonoAppsT.com</strong></a> All Rights Reserved
        </div>
    </div>
</footer>
<!--
    This website was created by Aniket.
    Contact to create your website: Telegram @Aniket_Coder
-->
</body>


</html>

