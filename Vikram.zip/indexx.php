<?php
ini_set('max_execution_time', '600');
ini_set('memory_limit', '512M');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");
?>


<?php

$result2aa = ''; 
$txn = "allappss3.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Loop through each entry
    foreach ($pro as $entry) {
        if (!empty($entry)) {
            $json = json_decode($entry, true);
            $nid = htmlspecialchars($json['nid']);
            $json_details = file_get_contents("alldetails3/c$nid.json");
            $json_details = json_decode($json_details, true);

            $img = htmlspecialchars($json_details['imglink']);
            $mwithdrawal = htmlspecialchars($json_details['mwith']);
            $downloaded = $json_details['tdown'];
            $bonus = htmlspecialchars($json_details['signbo']);
            $name = htmlspecialchars($json_details['name']);
            $nidd = htmlspecialchars($json_details['nid']);
             

            if ($nidd) {
                $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" href="appdetails.php?$name&!=c$nid&:=i" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download Now</a>
</li>
HTML;
                $result2aa .= $fv; // Append the generated markup to $result2a
            }
        }
    }
} else {
    $result2aa = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}


$result2a = ''; 
$txn = "allappss2.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Loop through each entry
    foreach ($pro as $entry) {
        if (!empty($entry)) {
            $json = json_decode($entry, true);
            $nid = htmlspecialchars($json['nid']);
            $json_details = file_get_contents("alldetails2/b$nid.json");
            $json_details = json_decode($json_details, true);

            $img = htmlspecialchars($json_details['imglink']);
            $mwithdrawal = htmlspecialchars($json_details['mwith']);
            $downloaded = $json_details['tdown'];
            $bonus = htmlspecialchars($json_details['signbo']);
            $name = htmlspecialchars($json_details['name']);
            $nidd = htmlspecialchars($json_details['nid']);
            
            $vm = $nidd ? "EDIT" : "ADD NEW";

if ($nidd) {

        $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" href="appdetails.php?$name&!=b$nid&:=!" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download Now</a>
</li>
HTML;
        $result2a .= $fv;}
    }
}} else {
    // If no lifafa entries are found
    $result2a = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}


           
           
           
 $result2 = ''; 
$txn = "allappss.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Function to compare $nid for sorting
    function compareNid($a, $b) {
        return $a['nid'] - $b['nid'];
    }

    // Array to hold parsed entries
    $entries = array();

    // Loop through each lifafa entry and parse JSON
    foreach ($pro as $entry) {
        $json = json_decode($entry, true);

        if (json_last_error() === JSON_ERROR_NONE && isset($json['nid'])) {
            $entries[] = $json;
        } }

    // Sort entries based on $nid
    usort($entries, 'compareNid');

    // Loop through sorted entries to generate HTML
    foreach ($entries as $json) {
    $nid = htmlspecialchars($json['nid']);  
    
    $json = file_get_contents("alldetails/$nid.json");
     $json = json_decode($json, true);
        
//rgfd
 $img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['signbo']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);    $txnd = "alldetails/$nid.json";       
$txnd = "alldetails/$nid.json";

if ($nidd) {

        $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" href="appdetails.php?!=$nid&$name" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download Now</a>
</li>
HTML;
        $result2 .= $fv;}
    }
} else {
    // If no lifafa entries are found
    $result2 = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}

$file="alldetails/01.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nid = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result201 = '<li>
                                <span title="Rummy Master All Rummy App">
                                    <i class="icon_i num1"></i>
                                    <img src="'.$img .'" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" href="appdetails.php?!='.$nid.'&'.$name.'" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download</a>
                            </li>  ';
                            $file="alldetails/02.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nid = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result202 = '<li>
                                <span title="Rummy Master All Rummy App">
                                    <i class="icon_i num2"></i>
                                    <img src="'.$img .'" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" href="appdetails.php?!='.$nid.'&'.$name.'" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download</a>
                            </li>  ';
                            $file="alldetails/03.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nid = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result203 = '<li>
                                <span title="Rummy Master All Rummy App">
                                    <i class="icon_i num3"></i>
                                    <img src="'.$img .'" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" href="appdetails.php?!='.$nid.'&'.$name.'" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download</a>
                            </li>  ';
                          
                          $rgegg="alldetails/wmaupchanl.json";  
                          $wch=file_get_contents($rgegg);
                          
                          $rgeggrge="alldetails/maupchanl.json";  
                          $mch=file_get_contents($rgeggrge);
                          
                          $rgeggrgergg="alldetails/upchanl.json";  
                          $uch=file_get_contents($rgeggrgergg);
                          
                          $rgeggrgergggr="alldetails/chanl.json";  
                          $rch=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/chanl.json";  
                          $weblink=file_get_contents($rgeggrgergggr);   
?>


<!DOCTYPE html>
<html lang="hi">
<head> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content=" AllYonoAppsT.com : Download All Yono Apps On  YonoAllApp.In, Here You Can Find New Rummy Apps And Earn Money Online Easily By Playing  Yono Games." />
    <meta name="keywords" content="All Rummy Application, All Rummy App, Rummy All App, Rummy 51 Bonus, New Rummy Apps, All Rummy App List 51 Bonus, All Rummy, Rummy All, All Rummy App List 41 Bonus, Rummy List, All Rummy App List, Rummy All Apk, Rummy Apps List, Rummy 51 Apk, Rummy Bonus 51 Rupees Free, All Rummy Games, All Rummy Game, Rummy All Game, Rummy All Games, Rummy Game List, Rummy 41 Bonus, All Rummy Apk, Rummy All Apk, Rummy Apk All, All Rummy App 51 Bonus, All Rummy App Link, All Rummy Store, Best Rummy App, All Rummy App List 2024, Top Rummy App, Rummy App List, Rummy Bonus App Download, All App Rummy, All Rummy Apk, All New Rummy App, All Best Rummy App, Dragon Vs Tiger, all rummy app 2023, all rummy app 2024, all rummy game 2024, all rummy game 500 bonus, all rummy games 2024, all rummy games 500 bonus, all rummy games online, new rummy app 500 bonus, new rummy apps 2023, rummy all apk 500 bonus, rummy all app 2023, rummy all app 2024, rummy all app new 2024, rummy all games 2023, rummy all games 2024, rummy gold, rummy new app 2024 download, rummy new app 51 bonus 2024, teen patti gold 51 bonus, new rummy app 500 bonus, rummy all app 2024, rummy all app new 2024, rummy all games 2024, all rummy games 2024, all rummy app 2024, new rummy apps 2023, all rummy game 2024, teen patti gold 51 bonus, all rummy games online, all rummy games online, new rummy app 500 bonus, rummy all app new 2024, rummy all app 2024, rummy all games 2024, all rummy app 2024, all rummy games 500 bonus, new rummy apps 2023,all rummy game 2024, new rummy app 500 bonus, all rummy games online, rummy all app 2024, rummy all app new 2024, rummy all app 2023, all rummy games 500 bonus, new rummy app 500 bonus, all rummy app 2024, all rummy game 500 bonus, rummy download, new rummy apps 2023, all rummy app 2023">
    <title>All Yono Apps get ₹41 Or ₹51 Bonus & Al Yono AppT</title>
    <link rel="icon" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg" type="image/x-icon">
    <link href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg" rel="image_src"/>
    <link rel="apple-touch-icon" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
    
     <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="All Rummy Apps List ₹41 Or ₹51 Bonus List & Rummy All Apps"/>
    <meta property="og:name" content="All Rummy App"/>
    <meta property="og:url" content="<?php echo $rch ;?>" />
    <link rel="canonical" href="<?php echo $rch ;?>" />
    <meta name="robots" content="index, follow"/> 
    <meta property="og:image" content="<?php echo $weblink ;?>"/>
    <meta property="og:site_name" content="<?php echo $weblink ;?>" />
    <meta name="og:name" content="All Rummy Apps"/>
    <meta property="og:description" content="All Rummy App : Download All Rummy Apps On <?php echo $weblink ;?>, Here You Can Find New Rummy Apps And Earn Money Online Easily By Playing Rummy Games."/>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="application" />
     
     <link rel="apple-touch-icon" sizes="57x57" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="60x60" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="72x72" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="76x76" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="114x114" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="120x120" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="144x144" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="152x152" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="apple-touch-icon" sizes="180x180" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="icon" type="image/png" sizes="192x192"  href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="icon" type="image/png" sizes="32x32" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="shortcut icon" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg" type="image/x-icon">
     <link rel="icon" type="image/png" sizes="96x96" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <link rel="icon" type="image/png" sizes="16x16" href="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <meta name="msapplication-TileColor" content="#ffffff">
     <meta name="msapplication-TileImage" content="https://i.postimg.cc/bwCC7j9k/IMG-20240618-202640-953.jpg">
     <meta name="theme-color" content="#ffffff">
    
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/index.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/style.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/allrummyappslink_header.css">
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
    <script src="https://trickyrummy.in/allrummyappslink_files/main.js" type="text/javascript"></script>
    <script src="https://trickyrummy.in/allrummyappslink_files/vungopro.min.js" type="text/javascript"></script> 
    <script src="https://trickyrummy.in/allrummyappslink_files/index.js" type="text/javascript"></script>
    <script src="https://kit.fontawesome.com/15963811af.js" crossorigin="anonymous"></script> 
        <script type="application/ld+json">
        {
         "@context": "https://<?php echo $weblink ;?>/",
          "@type": "WebSite",
          "name": "Rummy Apps",
          "url": "https://<?php echo $weblink ;?>"
          },
          "datePublished": ""
        }
        </script>
   </head>
   <body>
      <div class="wrap">
         <header class="green_bg flex">
    <div class="flex flex_grow">
       <span><a href="index"><img class="txt flex_grow" src="<?php echo $mch  ;?>" alt="All Rummy Apps"></a> </span></p>
    </div>
    <div class="share-link" onclick="window.open('<?php echo $wch ;?>')"title="Share this post link">
        <img src="https://trickyrummy.in/allrummyappslink_img/20231106_193029%20(1).webp" alt="All Rummy App" style="
        height: .55rem;
        margin-top: auto;
        margin-bottom: auto;
        ">
    </div>
    <div class="menu">
       <a onclick="headerNav()"><span class="fa fa-th-list"></span> Menu</a>
    </div>
    <div class="headerNav hide" id="headerNav">
       <ul class="flex">
         <li><a href="index"><i class="fa">&#xf015;</i>Home</a></li>
         <li><a href="about-us"><i class="fa">&#xf007;</i>About</a></li>
         <li><a href="contact-us"><i class="fa">&#xf095;</i>Contact</a></li>
         <li><a href="privacy-policy"><i class="fa">&#xf132;</i>Privacy</a></li>
         <li><a href="terms-and-conditions"><i class="fa">&#xf2bb;</i>T&C</a></li>
         <li><a href="all-rummy-games"><i class='fa'>&#xf02c;</i>Links</a></li>
       </ul>
       <div class="mask"></div>
     </div>
 </header>
 <nav class="nav_bar">
    <ul>
       <li class="current"><a href="index">Home</a></li>
       <li class=""><a href="about-us">About</a></li>
       <li class=""><a href="contact-us">Contact</a></li>
       <li class=""><a href="privacy-policy">Privacy</a></li>
       <li class=""><a href="all-rummy-games">Links</a></li>
    </ul>
 </nav>
 <h1 style="display: none;">All Rummy App</h1>         <img src="https://AllRummyStore.com/wp-content/uploads/2023/12/telegram-rummybonusapp-2.png" onclick="window.open('<?php echo $rch ;?>')" class="fixed max-w-sm h-auto right-2 bottom-0 top-0 z-20" style="width: 90px;margin-top: 383px;margin-bottom: auto;position: fixed;max-width: 24rem;height: auto;z-index: 20;top: 0;right: 0.5rem;bottom: 0;margin-right: -20px;" alt="Join Telegram Channel">
          <div class="ranking_list"> <div class="sort flex"> <img src="<?php echo $uch  ;?>" onclick="edtlifv2('changeupperlogo')"  alt="All Rummy App"> <div></div> </div>
            <div id="changechanlink"></div> <div id="changedomlog"></div> <div id="changeupperlogo"></div>  <div id="changewhatlogo"></div> <div class="VungoPro_in"> <ul class="flex">
                  <?php echo $result202 ;?> <?php echo $result201 ;?> <?php echo $result203 ;?>
                   
                            
                           
               </ul>
            </div>
         </div>
         <!--<div class="allrummyappslink_Slider">-->
         <!--   <div class="AllRummyApps_ticker">-->
         <!--      <div class="title">-->
         <!--         <p>सूचना :-</p>-->
         <!--      </div>-->
         <!--      <div class="news">-->
         <!--         <marquee>-->
         <!--            <p>-->
         <!--               हमारे द्वारा दिए जाने वाले सभी एप्लीकेशन के अंदर वित्तीय जोखिम उपस्थित है तो कृपया इस बात को ध्यान में रखें, एवं स्वयं के रिस्क इसके गेमों को खेलें ! और याद रखे की अगर आप इसमें से किसी भी एप्लीकेशन में भी अपने पैसे को ऐड करेंगे, तो उसका जिम्मेवार आप खुद होंगे।-->
         <!--            </p>-->
         <!--         </marquee>-->
         <!--      </div>-->
         <!--   </div>-->
         <!--</div>-->
        
        <!-- <div class="allrummyappslink_com container" style="
            margin-bottom: 5px;
            margin-top: 10px;
            margin-left: 10px;
            margin-right: 15px;">
          
                  <label class="SearchForm-module_searchInputWrap-VxSwZ" style="
            font-family: var(--cp-font-family);
            font-size: 1.3rem;
            position: relative;
            display: block;
            font-size: 16px;
            line-height: 1.2;
        "><i class="fa-solid" style="
            position: absolute;
            top: 0;
            left: 1.6em;
            bottom: 0;
            margin: auto auto auto 0;
            width: 1em;
            height: 1em;
            z-index: 1;
            color: hsl(228.39deg 12.25% 50.39%);" aria-hidden="true"></i><input autocomplete="off" class="SearchForm-module_searchInput-cYc5R" data-test-id="searchInput" id="searchInput" placeholder="Search All Rummy App here" type="search" value="" style="margin: 0px; padding: 0.4em; text-indent: 2em; border: 2px solid rgb(4, 0, 85); font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; font-optical-sizing: inherit; font-kerning: inherit; font-feature-settings: inherit; font-variation-settings: inherit; font-weight: 700; background: rgb(255, 255, 255); width: 100%; border-radius: 10px; color: rgb(0, 0, 0);"></label>
                  <div id="submitsearch" style="display: none;">
                    <span>Search All Rummy Apps Here...</span>
                    
                  </div>
         
        </div> -->
        <!--<div id="searchResults" class="display: none;"></div>-->
        <div class="container" style="
  margin-bottom: 5px;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
">
  <center>
          <label class="SearchForm-module_searchInputWrap-VxSwZ" style="
    font-family: var(--cp-font-family);
    font-size: 1.3rem;
    position: relative;
    display: block;
    font-size: 16px;
    line-height: 1.2;
"><h2 id="search-title" class="screen-reader-text" style="
    position: absolute;
    top: -9999px;
    left: -9999px;
">Search</h2><i class="fa-shake" style="
    position: absolute;
    top: -.2em;
    left: 1.3em;
    bottom: 0;
    margin: auto auto auto 0;
    width: 1em;
    height: 1em;
    z-index: 1;" aria-hidden="true">🔍</i>
    <input autocomplete="off" class="SearchForm-module_searchInput-cYc5R" data-test-id="searchInput" id="searchInput" placeholder="Search All Rummy Apps Here..." type="search" value="" style="
    width: 97%;
    margin: 0;
    padding: .4em;
    text-indent: 2em;
    border: 0;
    border-radius: 0 10px 0 10px;
    font: inherit;
    font-weight: 700;
    background: rgb(225 239 254/1);
    border: 1px solid #333;
    color: #000;
"></label>
          <div id="submitsearch" style="">
            <span>Search All Rummy Apps Here...</span>
            
          </div>
    </center>
          <div id="searchResults"></div>
        </div>
        
         <div class="LootEarning_Com tab_box">
            <div class="tab_menu flex">
               <span class="current">Good For You</span>
               <span><i class="fa-solid fa-bolt"></i> New Apps</span>
               <span>Teenpatti Apps</span>
            </div>
            <div class="tab_cont">
               <div class="sub_box ">
                  <ul id="appList" class="appList">
                          <div id="gy"><?php echo $result2 ?>   </div>
                    </ul> 
               </div>
               <div class="sub_box hide">
                  <ul id="appList">  <div id="gyargrf"><?php echo $result2a ?></div>
                                </ul>
               </div>
               <div class="sub_box hide">
                  <ul id="appList"> <div id="gyaabte"><?php echo $result2aa ?></div>
                        
                                     </ul>
               </div>
            </div>
         </div>
         <div class="allrummyappslink_Slider">
            <div class="AllRummyApps_ticker">
               <div class="title">
               <p>Tag's:-</p>
               </div>
  <div class="news">
                  <marquee>
                     <p>
                        All Rummy Apps, Best Rummy App, Top Rummy App, Rummy, Teen Patti, New Teen Patti, New Rummy, Best Teen Patti, New Teen Patti App, Best Teen Patti App, Teen Patti App, Rummy App, New Teen Patti 2023, New Rummy 2023, All Rummy APK, All Rummy App List, All Teen Patti App List, New Teen Patti 2023 App, New Teen Patti 2023 APK, All Dragon Vs Tiger App, Dragon Vs Tiger App list, Latest Rummy App, Latest Teen Patti App, Real Cash Rummy App, All Rummy App 2024 Rummy 51 Bonus, All Rummy App List 51 Bonus.
                     </p>
                  </marquee>
               </div>
            </div>
         </div>
        
<div class="AllRummyApps-footer">
    <div class="devider"></div>
    <div class="links">
        <a href="about-us" class="border"><i class="fa fa-user-o">&nbsp;</i> About Us</a>
        <a href="contact-us" class="border"><i class="fa fa-phone">&nbsp;</i>Contact Us</a>
        <a href="privacy-policy" class="border"><i class="fa fa-shield">&nbsp;</i>Privacy Policy</a>
        <a href="terms-and-conditions" class="border"><i class="fa fa-vcard-o">&nbsp;</i> Terms & Conditions</a>
        <a href="disclaimer"><i class="fa fa-exclamation-triangle">&nbsp;</i>Disclaimer</a>
        <div class="devider"></div>
    </div>
    <p>Copyright © <a href="https://AllYonoAppsT.com" style="color: white;"><strong>AllYonoAppsT.com/strong></a> All Rights Reserved</p>
</div>

<!--<script src="/allrummyappslink_files/share.js" type="text/javascript"></script>-->    </div>
      </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  // Set the interval to 100 milliseconds
  setInterval(function() {
    $.ajax({
      url: "allapps.php",
      success: function(data) {
        // Update the HTML content of the element with ID 'gy'
        $("#gy").html(data);
        $("#gya").html(data);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Log any error that occurs during the request
        console.error("AJAX request failed: " + textStatus, errorThrown);
      }
    });
  }, 1000); // Interval set to 100 milliseconds
</script>
<script>
  // Set the interval to 100 milliseconds
  setInterval(function() {
    $.ajax({
      url: "allapps.php?tg=2",
      success: function(data) {
        // Update the HTML content of the element with ID 'gy'
        $("#gyargrf").html(data);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Log any error that occurs during the request
        console.error("AJAX request failed: " + textStatus, errorThrown);
      }
    });
  }, 1000); // Interval set to 100 milliseconds
</script>
<script>
  // Set the interval to 100 milliseconds
  setInterval(function() {
    $.ajax({
      url: "allapps.php?tg=5",
      success: function(data) {
        // Update the HTML content of the element with ID 'gy'
        $("#gyaabte").html(data);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Log any error that occurs during the request
        console.error("AJAX request failed: " + textStatus, errorThrown);
      }
    });
  }, 1000); // Interval set to 100 milliseconds
</script>

<script>
 document.addEventListener("DOMContentLoaded", function () {
            const input = document.getElementById('searchInput');
            const appLists = document.querySelectorAll('#appList'); // Select all elements with the ID 'appList'
            const searchResults = document.getElementById('searchResults');
    
            input.addEventListener('input', function () {
                const filter = input.value.toUpperCase();
                
                if (filter === '') {
                    searchResults.innerHTML = ''; // Clear search results when the input is empty
                    return;
                }
    
                searchResults.innerHTML = '';
                let found = false;
    
                appLists.forEach(appList => {
                    const items = appList.querySelectorAll('.name');
    
                    items.forEach(item => {
                        const text = item.textContent.toUpperCase();
    
                        if (text.includes(filter)) {
                            found = true;
                            const clonedItem = item.closest('li').cloneNode(true);
    
                            // Create a new <ul> if it doesn't exist in searchResults
                            let ulElement = searchResults.querySelector('ul');
                            if (!ulElement) {
                                ulElement = document.createElement('ul');
                                searchResults.appendChild(ulElement);
                            }
    
                            const existingItem = ulElement.querySelector(`li .name[data-text="${text}"]`);
    
                            if (!existingItem) {
                                const liElement = document.createElement('li');
                                clonedItem.querySelector('.name').setAttribute('data-text', text); // Set an attribute to mark this element
                                liElement.appendChild(clonedItem);
                                ulElement.appendChild(liElement);
                            }
                        }
                    });
                });
    
                // Remove empty ul elements
                searchResults.querySelectorAll('ul').forEach(ul => {
                    if (!ul.children.length) {
                        ul.remove();
                    }
                });
    
                if (!found) {
                    searchResults.innerHTML = '<p>No Rummy Apps found</p>';
                }
            });
        });
   </script>
</body>
</html>