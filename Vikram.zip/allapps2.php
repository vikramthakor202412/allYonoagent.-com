<?php
$hh=$_GET["hh"]; if($hh=="3"){$gf="alldetails2"; $gfs="allappss2";}else{$gf="alldetails"; $gfs="allappss";}
$result2a = '';  $txn = "allappss2.json";
$jj=$_GET["jj"];  
if($jj=="6"){
if (file_exists($txn)) { $file = file_get_contents($txn); $pro = explode(";'", $file);

    function compareNid($a, $b) { return $a['nid'] - $b['nid']; }

    // Array to hold parsed entries
    $entries = array();
    
    foreach ($pro as $entry) { $json = json_decode($entry, true);

        if (json_last_error() === JSON_ERROR_NONE && isset($json['nid'])) { $entries[] = $json; } }
        
    usort($entries, 'compareNid');  foreach ($entries as $json) { $nid = htmlspecialchars($json['nid']);  
    
    $json = file_get_contents("alldetails2/$nid.json"); $json = json_decode($json, true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['signbo']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);    $txnd = "$gf/$nid.json";
if ($nidd) {
if (intval($nidd) < 6) {
        $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" href="appdetails.php?!=$nid&$name" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download Now</a>
</li>
HTML;
        $result2a .= $fv;}} } } else {  $result2 = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>"; }  
 
 }else{
 
$result2a = ''; 
$txn = "allappss2.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Loop through each entry
    foreach ($pro as $entry) {
        if (!empty($entry)) {
            $json = json_decode($entry, true);
            $nid = htmlspecialchars($json['nid']);
            $json_details = file_get_contents("alldetails2/b$nid.json");
            $json_details = json_decode($json_details, true);

            $img = htmlspecialchars($json_details['imglink']);
            $mwithdrawal = htmlspecialchars($json_details['mwith']);
            $downloaded = $json_details['tdown'];
            $bonus = htmlspecialchars($json_details['signbo']);
            $name = htmlspecialchars($json_details['name']);
            $nidd = htmlspecialchars($json_details['nid']);
            
            $vm = $nidd ? "EDIT" : "ADD NEW";

if ($nidd) {

        $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" href="appdetails..php?!=b$nid&$name" target="_blank"><i class="fa-solid fa-cloud-arrow-down"></i> Download Now</a>
</li>
HTML;
        $result2a .= $fv;}
    }
}} else {
    // If no lifafa entries are found
    $result2a = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}
}
 echo $result2a;

?>
