 	<style>
	  .input{
        display: block;
        width: 90%;
        margin: 10px auto;
        text-align: center;
        color: black;
        font-family: 'Montserrat';
        padding: 0;
        font-size: 15px;
        font-weight: 500;
        height: 40px;
        border: 1px solid #047aed;
        border-radius: 4px;
        background-color: #E1F5FE;
        outline: none;
        padding: 0 5px 0 5px;
        box-shadow: 0 5px 30px rgba(255, 255, 255, 0.1);
    }
     input:focus {
  border: solid blue 0.5px;
  border-radius:20px;
  width:95%;
   box-shadow: 1px 1px 8px blue ;
  transition: width 200ms ease-in, box-shadow 200ms ease-in, border 200ms ease-in, border-radius 2000ms ease-in ;
 
}  
    
@keyframes show_box {
  from{
    opacity: 0;
    transform: translateY(-30%);
  }
  to{
    opacity: 1;
    transform: translateY(0%);
  }
}

.fontrs1 {
          position: absolute;
          top: -20px;
          left: -20px;
          color: white;
          height:90px;
          width:120px;
          padding-bottom:20px;
           padding-right:30px;
            padding-top:45px;
             padding-left:40px;
             border-radius:5px;

          animation: coloranim1 10s infinite;
        }
        
        
        .fontrs2 {
          position: absolute;
          top: -20px;
          right: -20px;
          color: white;
          height:90px;
          width:120px;
           padding-bottom:20px;
           padding-right:40px;
            padding-top:45px;
             padding-left:30px;
             border-radius:5px;
             
          animation: coloranim2 10s infinite;
        }
        
        .fontrs3 {
          position: absolute;
          bottom: -20px;
          left: -20px;
          color: white;
          height:90px;
          width:120px;
          padding-bottom:50px;
           padding-right:30px;
            padding-top:25px;
             padding-left:50px;
             border-radius:5px;
          
          animation: coloranim3 10s infinite;
        }
        
        .fontrs4 {
          position: absolute;
          bottom: -20px;
          right: -20px;
          color: white;
          height:90px;
          width:120px;
          padding-bottom:50px;
           padding-right:50px;
          padding-top:25px;
          padding-left:30px;
          border-radius:5px;
          background: #047aed;
        }
	      .submit{
        height: 40px;
        width: 50%;
        border-radius: 4px;
        margin: 0 auto;
        margin: 15px 0;
        padding: 0 25px 0 25px;
        background-image:linear-gradient(135deg, green 0%, blue 51%, purple 80%, red 100%);
        border: 1px solid blue;
        font-family: 'Montserrat';
        font-size: 14px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
        animation: coloranim1 10s infinite;
    }
    .submitt{
        height: 22px;
        width: 125px;
        border: 0;
        border-radius: 4px;
        margin-top: 10px;
        margin-bottom: 10px;
        justify-content: center;
        align-items: center;
        background: green;
        border: 1px solid blue;
        font-family: 'Montserrat';
        font-size: 13px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
    }
     .submittt{
        height: 22px;
        width: 125px;
        border: 0;
        border-radius: 4px;
        margin-top: 10px;
        margin-bottom: 10px;
        justify-content: center;
        align-items: center;
        background: red;
        border: 1px solid blue;
        font-family: 'Montserrat';
        font-size: 13px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
    } 
    .submit1{
        height: 40px;
        width: 160px;
        border: 1px solid red;
        border-radius: 4px;
        margin-top: 10px;
        margin-bottom: 10px;
        padding: 0 25px 0 25px;
        background: #047aed;
        font-family: 'Montserrat';
        font-size: 14px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
    }
     </style>
  <?php
$pass=$_GET['pass']; if(!$pass){
$pass=$_COOKIE['pass'];}
$txnd = "alldetails/usegyjjvhhjyg672epepepep.json";
$filed = file_get_contents($txnd);

if($pass=="$filed"){ }else{echo"  <center> <br><div style=' margin-left:70px;width:80%; height:50%; position: absolute; z-index: 10; padding:10px; background: lightgreen; border-top:1px solid blue;border-right:1px solid blue;border-bottom:1px solid blue;border-left:1px solid blue; border-radius:5px; margin-top:250px; '> <br><br> <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> 
<font color='brown' style='font-weight:600; width:80%; height:50%;'>Enter Login Password</font><br><br>
            <center> <form method='GET' autocomplete='off'>
            <input type='text' name='pass' placeholder='Enter Admin Password' class='input'><br>
            <button type='submit' class='submit1' >Login</button></form></center> <br><br>  </div>  </center>";
            return; } ?>
            
            <?php
            setcookie('pass',$pass,time()+60*60*24*305);
            
$result2aa = ''; 
$txn = "allappss3.json";
if (file_exists($txn)) {
    $file = file_get_contents($txn); $pro = explode(";'", $file);

    // Loop through each entry
    foreach ($pro as $entry) {
        if (!empty($entry)) {
            $json = json_decode($entry, true);
            $nid = htmlspecialchars($json['nid']); $json_details = file_get_contents("alldetails3/c$nid.json"); $json_details = json_decode($json_details, true);

            $img = htmlspecialchars($json_details['imglink']);
            $mwithdrawal = htmlspecialchars($json_details['mwith']);
            $downloaded = $json_details['tdown'];
            $bonus = htmlspecialchars($json_details['signbo']);
            $name = htmlspecialchars($json_details['name']);
            $nidd = htmlspecialchars($json_details['nid']);
            
            $vm = $nidd ? "EDIT" : "ADD NEW";

            if ($nid) {
                $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" style="width: 50px; height: 50px;" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" onclick="edtlifv2aa('c$nid')" target="_blank">$vm</a> 
</li> <div id="c$nid"></div>
HTML;
                $result2aa .= $fv; // Append the generated markup to $result2a
            }
        }
    }
} else {
    $result2aa = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}



$result2a = ''; 
$txn = "allappss2.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Loop through each entry
    foreach ($pro as $entry) {
        if (!empty($entry)) {
            $json = json_decode($entry, true);
            $nid = htmlspecialchars($json['nid']);
            $json_details = file_get_contents("alldetails2/b$nid.json");
            $json_details = json_decode($json_details, true);

            $img = htmlspecialchars($json_details['imglink']);
            $mwithdrawal = htmlspecialchars($json_details['mwith']);
            $downloaded = $json_details['tdown'];
            $bonus = htmlspecialchars($json_details['signbo']);
            $name = htmlspecialchars($json_details['name']);
            $nidd = htmlspecialchars($json_details['nid']);
            
            $vm = $nidd ? "EDIT" : "ADD NEW";

            if ($nid) {
                $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" style="width: 50px; height: 50px;" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" onclick="edtlifv2a('b$nid')" target="_blank">$vm</a> 
</li> <div id="b$nid"></div>
HTML;
                $result2a .= $fv; // Append the generated markup to $result2a
            }
        }
    }
} else {
    $result2a = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>";
}




$result2 = ''; 
$txn = "allappss.json";

if (file_exists($txn)) {
    $file = file_get_contents($txn);
    $pro = explode(";'", $file);

    // Function to compare $nid for sorting
    function compareNid($a, $b) {
        return $a['nid'] - $b['nid'];
    }

    // Array to hold parsed entries
    $entries = array();

    // Loop through each lifafa entry and parse JSON
    foreach ($pro as $entry) {
        $json = json_decode($entry, true);

        if (json_last_error() === JSON_ERROR_NONE && isset($json['nid'])) {
            $entries[] = $json;
        } 
    }

    // Sort entries based on $nid
    usort($entries, 'compareNid');

    // Loop through sorted entries to generate HTML
    foreach ($entries as $json) {
    $nid = htmlspecialchars($json['nid']);  
    
    $json = file_get_contents("alldetails/$nid.json"); $json = json_decode($json, true); $img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['signbo']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);    $txnd = "alldetails/$nid.json";
    if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
if ($nid) {
 $fv = <<<HTML
<li class="flex search_li" style="width: 100%;">
    <a class="flex flex_grow" title="{$name}">
        <i class="num s_num">{$nid}</i>
        <img class="s_img" style="width: 50px; height: 50px;" src="{$img}" alt="{$name}">
        <div class="info flex_grow s_info">
            <p class="name s_name">{$name}</p>
            <p class="grade s_grade"><i class="fa"></i> <em class="s_em">{$downloaded}</em>&nbsp;|&nbsp;<span class="s_span">Bonus Rs. {$bonus}</span></p>
            <p class="txt s_txt"><i class="fa"></i> Min. Withdrawal ₹{$mwithdrawal}/-</p>
        </div>
    </a>
    <a class="btn search_btn" onclick="edtlifv2('$nid')" target="_blank">$vm</a> 
</li> <div id="$nid"></div>
HTML;
        $result2 .= $fv;} }
} else { $result2 = "<center> <br><br><h3>NO RUMMY APPS AVAILABLE RIGHT NOW!</h3> </center>"; }

$file="alldetails/02.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result202 = '<li>
                                <span title="Rummy East All Rummy App">
                                    <i class="icon_i num2"></i>
                                    <img src="'.$img .'" style="width: 50px; height: 50px;" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" onclick="edtlifv2(\'02\')" target="_blank"> '.$vm.'</a> 
                            </li>  ';
                            $file="alldetails/01.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result201 = '<li>
                                <span title="Rummy Master All Rummy App">
                                    <i class="icon_i num1"></i>
                                    <img src="'.$img .'" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" onclick="edtlifv2(\'01\')" target="_blank"> '.$vm.'</a> 
                            </li>  ';
                            $file="alldetails/03.json"; $zaker=file_get_contents($file); $json=json_decode($zaker,true);
$img = htmlspecialchars($json['imglink']);   $mwithdrawal = htmlspecialchars($json['mwith']);   $downloaded =  ($json['tdown']);   $bonus = htmlspecialchars($json['bonus']);   $name = htmlspecialchars($json['name']); $nidd = htmlspecialchars($json['nid']);
if($nidd){$vm="EDIT"; }else{$vm="ADD NEW";}
$result203 = ' <li>
                                <span title="Rummy Bharat All Rummy App">
                                    <i class="icon_i num3"></i>
                                    <img src="'.$img .'" alt="'.$name.'">
                                    <h2 class="name">'.$name.'</h2>
                                    <span class="star">★★★★★</span>
                                    <p class="grade"><i class="fa">&#xf058;</i><span> 100% Safe & Secure</span></p>
                                </span>
                                <a class="btn search_btn" onclick="edtlifv2(\'03\')" target="_blank"> '.$vm.'</a> 
                            </li>     ';
                            
                            
                             $rgegg="alldetails/wmaupchanl.json";  
                               $wch=file_get_contents($rgegg);
                          
                          $rgeggrge="alldetails/maupchanl.json";  
                          $mch=file_get_contents($rgeggrge);
                          
                          $rgeggrgergg="alldetails/upchanl.json";  
                          $uch=file_get_contents($rgeggrgergg);
                          
                          $rgeggrgergggr="alldetails/chanl.json";  
                          $rch=file_get_contents($rgeggrgergggr);   
                          
                           $rgeggrgergggr="alldetails/chanl.json";  
                          $weblink=file_get_contents($rgeggrgergggr); 
?>

<!DOCTYPE html>
<html lang="hi">
<head> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="All Rummy App : Download All Rummy Apps On TrickyRummy.In, Here You Can Find New Rummy Apps And Earn Money Online Easily By Playing Rummy Games." />
    <meta name="keywords" content="All Rummy Application, All Rummy App, Rummy All App, Rummy 51 Bonus, New Rummy Apps, All Rummy App List 51 Bonus, All Rummy, Rummy All, All Rummy App List 41 Bonus, Rummy List, All Rummy App List, Rummy All Apk, Rummy Apps List, Rummy 51 Apk, Rummy Bonus 51 Rupees Free, All Rummy Games, All Rummy Game, Rummy All Game, Rummy All Games, Rummy Game List, Rummy 41 Bonus, All Rummy Apk, Rummy All Apk, Rummy Apk All, All Rummy App 51 Bonus, All Rummy App Link, All Rummy Store, Best Rummy App, All Rummy App List 2024, Top Rummy App, Rummy App List, Rummy Bonus App Download, All App Rummy, All Rummy Apk, All New Rummy App, All Best Rummy App, Dragon Vs Tiger, all rummy app 2023, all rummy app 2024, all rummy game 2024, all rummy game 500 bonus, all rummy games 2024, all rummy games 500 bonus, all rummy games online, new rummy app 500 bonus, new rummy apps 2023, rummy all apk 500 bonus, rummy all app 2023, rummy all app 2024, rummy all app new 2024, rummy all games 2023, rummy all games 2024, rummy gold, rummy new app 2024 download, rummy new app 51 bonus 2024, teen patti gold 51 bonus, new rummy app 500 bonus, rummy all app 2024, rummy all app new 2024, rummy all games 2024, all rummy games 2024, all rummy app 2024, new rummy apps 2023, all rummy game 2024, teen patti gold 51 bonus, all rummy games online, all rummy games online, new rummy app 500 bonus, rummy all app new 2024, rummy all app 2024, rummy all games 2024, all rummy app 2024, all rummy games 500 bonus, new rummy apps 2023,all rummy game 2024, new rummy app 500 bonus, all rummy games online, rummy all app 2024, rummy all app new 2024, rummy all app 2023, all rummy games 500 bonus, new rummy app 500 bonus, all rummy app 2024, all rummy game 500 bonus, rummy download, new rummy apps 2023, all rummy app 2023">
    <title>All Rummy Apps List ₹41 Or ₹51 Bonus List & Rummy All Apps</title>
    <link rel="icon" href="https://trickyrummy.in/kr/assets/site/IMG_20240510_181753_821.webp" type="image/x-icon">
    <link href="https://trickyrummy.in/kr/assets/site/IMG_20240510_181753_821.webp" rel="image_src"/>
    <link rel="apple-touch-icon" href="https://trickyrummy.in/kr/assets/site/IMG_20240510_181753_821.webp">
    
     <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="All Rummy Apps List ₹41 Or ₹51 Bonus List & Rummy All Apps"/>
    <meta property="og:name" content="All Rummy App"/>
    <meta property="og:url" content="https://trickyrummy.in" />
    <link rel="canonical" href="https://trickyrummy.in" />
    <meta name="robots" content="index, follow"/> 
    <meta property="og:image" content="https://trickyrummy.in/kr/assets/site/IMG_20240510_181753_821.webp"/>
    <meta property="og:site_name" content="trickyrummy.in" />
    <meta name="og:name" content="All Rummy Apps"/>
    <meta property="og:description" content="All Rummy App : Download All Rummy Apps On TrickyRummy.In, Here You Can Find New Rummy Apps And Earn Money Online Easily By Playing Rummy Games."/>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="application" />
    <link rel="stylesheet" href="https://yonoapps.in/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
     
     <meta name="msapplication-TileColor" content="#ffffff">
     <meta name="msapplication-TileImage" content="https://trickyrummy.in/kr/assets/site/IMG_20240510_181753_821.webp">
     <meta name="theme-color" content="#ffffff">
    
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/index.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/style.css">
    <link rel="stylesheet" type="text/css" href="https://trickyrummy.in/allrummyappslink_files/allrummyappslink_header.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://trickyrummy.in/allrummyappslink_files/main.js" type="text/javascript"></script>
    <script src="https://trickyrummy.in/allrummyappslink_files/vungopro.min.js" type="text/javascript"></script> 
    <script src="https://trickyrummy.in/allrummyappslink_files/index.js" type="text/javascript"></script>
    <script src="https://kit.fontawesome.com/15963811af.js" crossorigin="anonymous"></script>
    
        <script type="application/ld+json">
        {
         "@context": "https://schema.org/",
          "@type": "WebSite",
          "name": "Tricky Rummy",
          "url": "https://TrickyRummy.in"
          },
          "datePublished": ""
        }
        </script>

<style>
          @import url("ajax/libs/font-awesome/6.5.1/css/all.min.css");.custom-button{width:100%;max-width:350px;height:30px;border:1px solid #08c;border-radius:25px;background-color:#fff;color:#08c;font-size:15px;font-weight:700}.wt,[class~=tgi]{position:fixed;}[class~=tgi]{right:-9.5%;}.wt,[class~=tgi]{top:0;}.wt,[class~=tgi]{bottom:0;}.wt,[class~=tgi]{margin-left:auto;}[class~=tgi]{margin-bottom:17rem;}[class~=tgi],.wt{margin-right:auto;}[class~=tgi]{margin-top:17rem;}.wt,[class~=tgi]{width:6.5rem;}.wt,[class~=tgi]{height:3rem;}[class~=tgi],.wt{z-index:999;}.wt{right:-8.8%;}.wt{margin-bottom:14.7rem;}.wt{margin-top:14.7rem;}[class~=custom-buttonW]{width:100%;}[class~=custom-buttonW]{max-width:3.645833333in;}[class~=custom-buttonW]{height:1.875pc;}[class~=custom-buttonW]{border-left-width:.010416667in;}[class~=custom-buttonW]{border-bottom-width:.010416667in;}[class~=custom-buttonW]{border-right-width:.010416667in;}[class~=custom-buttonW]{border-top-width:.010416667in;}[class~=custom-buttonW]{border-left-style:solid;}[class~=custom-buttonW]{border-bottom-style:solid;}[class~=custom-buttonW]{border-right-style:solid;}[class~=custom-buttonW]{border-top-style:solid;}[class~=custom-buttonW]{border-left-color:#25d366;}[class~=custom-buttonW]{border-bottom-color:#25d366;}[class~=custom-buttonW]{border-right-color:#25d366;}[class~=custom-buttonW]{border-top-color:#25d366;}[class~=custom-buttonW]{border-image:none;}[class~=custom-buttonW]{border-radius:.260416667in;}[class~=custom-buttonW]{background-color:#fff;}[class~=custom-buttonW]{color:#25d366;}[class~=custom-buttonW]{font-size:11.25pt;}[class~=custom-buttonW]{font-weight:700;}[class~=tgi] img{width:63%;}.wt img{width:68%;}@media (max-width:768px){.custom-button{max-width:none}}[class~=app-item_dont_copy_created_by_allappstore_com]::before{counter-increment:app-counter;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{content:counter(app-counter) ".";}[class~=app-item_dont_copy_created_by_allappstore_com]::before{font-weight:bold;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{font-size:1em;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{margin-right:.010416667in;}[class~=app-item_dont_copy_created_by_allappstore_com]::before{color:#899499;}[class~=telegram-card]{animation:telegram-border-animation 1s infinite;}@keyframes telegram-border-animation{0%{border-color:transparent;}50%{border-color:#004f7a;}100%{border-color:transparent;}}[class~=answer8262]::before{content:"Answer. ";}[class~=seoquake-nofollow]{display:inline-flex;}[class~=seoquake-nofollow]{align-items:center;}[class~=seoquake-nofollow],[class~=answer8262]::before{font-weight:bold;}[class~=seoquake-nofollow]{justify-content:center;}[class~=seoquake-nofollow]{font-size:1rem;}#iTable{border-collapse:collapse;}h2.relatedapps{font-size:.208333333in;}#iTable{width:94%;}h2{padding-left:.4375pc;}#iTable{margin-left:auto;}[class~=seoquake-nofollow]{text-decoration:none;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{width:20%;}h2{padding-bottom:.4375pc;}[class~=seoquake-nofollow]{padding-left:1.25pc;}.AllAppStore_Com_Slider .AllAppStore_ticker .title,h2.relatedapps{text-align:center;}h2.relatedapps{padding-left:1.5625pc;}#iTable td:not(:last-child){border-right-width:.020833333in;}h2.relatedapps,#iTable td:not(:last-child){border-right-style:solid;}[class~=seoquake-nofollow]{padding-bottom:3.75pt;}h2{padding-right:.4375pc;}[class~=seoquake-nofollow]{padding-right:1.25pc;}h2.relatedapps{color:white;}h2.relatedapps{background:radial-gradient(circle at 10% 20%,#005d85 0%,#00b595 90%);}h2.relatedapps{border-left-width:.1875pc;}[class~=seoquake-nofollow]{padding-top:3.75pt;}#iTable{margin-bottom:0;}[class~=seoquake-nofollow]{border-radius:.125pc;}h2.relatedapps{border-bottom-width:.1875pc;}[class~=seoquake-nofollow]{flex-shrink:0;}[class~=seoquake-nofollow]{transition:all .3s ease-in-out;}h2.relatedapps{border-right-width:.1875pc;}[class~=seoquake-nofollow]{color:white !important;}#iTable{margin-right:auto;}h2{padding-top:.4375pc;}.ul{font-size:11.25pt;}h2{text-align:left;}h2{border-bottom-width:.125pc;}.ul{padding-top:6%;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{font-size:.3rem;}h2.relatedapps{border-top-width:.1875pc;}.ul{padding-right:5%;}.AllAppStore_Com_Slider .AllAppStore_ticker .title p{font-size:.135416667in;}#iTable td:not(:last-child){border-right-color:#ddd;}h2,h2.relatedapps{border-bottom-style:solid;}.ul{padding-bottom:6%;}.ul{padding-left:5%;}h2.relatedapps{border-left-style:solid;}[class~=image2]{position:absolute;}h2.relatedapps{border-top-style:solid;}#iTable{margin-top:0;}[class~=parent],[class~=question8262]{position:relative;}.red-disclaimer-box{border-radius:3pt;}h2.relatedapps{border-left-color:black;}.red-disclaimer-box{color:black;}#iTable{border-radius:7.5pt;}h2.relatedapps{border-bottom-color:black;}.red-disclaimer-box{font-family:"Arial",sans-serif;}h2.relatedapps{border-right-color:black;}.red-disclaimer-box{font-size:8.25pt;}h2.relatedapps{border-top-color:black;}h2{border-bottom-color:#dedede;}h2,#iTable td:not(:last-child),h2.relatedapps{border-image:none;}.red-disclaimer-box{line-height:1.5;}h2{border-left-width:.0625pc;}[class~=question8262],[class~=mr193]{font-size:1pc;}[class~=question8262]{color:#fff;}#iTable{background:linear-gradient(to right,#e0e0e0,#f9f9f9);}.AllAppStore_Com_Slider .AllAppStore_ticker .title p{line-height:.4rem;}[class~=question8262]{background-color:#3f51b5;}.AllAppStore_Com_Slider .AllAppStore_ticker .title p,[class~=mr193]{font-weight:bold;}[class~=question8262]{padding-left:9px;}[class~=question8262]{padding-right:17.25pt;}[class~=question8262]{padding-top:9px;}#iTable tr:nth-child(even){background-color:#f9f9f9;}h2{border-left-style:solid;}[class~=question8262]{padding-bottom:.5625pc;}h2{border-left-color:#00f;}[class~=question8262]{border-radius:.052083333in;}[class~=question8262]{margin-bottom:.09375in;}h2{font-size:.25in;}[class~=mr193]{text-align:center;}[class~=mr193]{color:#00c700;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{background-color:#0013a4;}.AllAppStore_Com_Slider .AllAppStore_ticker .title{color:#ff0;}*,body{margin:0}.center-text,.small-center-text{line-height:1.5;text-align:center}.footer-link,.link-style{text-decoration-line:underline}.center .downBtn,.center-text,.hed,.menu-container,.navbar a,.popup-content,.small-center-text{text-align:center}.footbtn,.hed1,.menu-item{box-sizing:border-box}.app-info,.bodylook,.navbar a,body{font-family:Arial,sans-serif}.close-btn,.custom-image,.icon,.popup-trigger,.tabs .tab{cursor:pointer}#iTable a,.close-button,.header-text,.navbar a,a{text-decoration:none}.container{width:90%;max-width:1200px;margin:0 auto;padding:20px}@media only screen and (max-width:768px){.container{padding:10px}}@media only screen and (max-width:480px){.container{padding:5px}}h3,h4,p{padding:9px}li{padding-left:18px;paddin-right:18px;padding-top:3px;padding-bottom:3px;font-size:15px}ul{padding:18px}ol{padding-left:11px;paddin-right:11px}h2{color:red;border-left-width:6px;padding-block:10px;margin-top:0}table,td,th{border:1px solid;padding:3px}.allappstore_img{border:1px solid #ddd;border-radius:4px;padding:5px;width:90%;display:block;margin:10px auto}*,.note{padding:0}*{list-style:none}.note{color:#c9c3b5;font-size:.24rem}.bodylook{background-color:#fff;border:5px solid #000;padding:2%}.footbtn a img,.top img{width:100%;display:block}.center .downBtn{width:125%;padding-top:0;margin:120% 24% 37% -12%}.center .downBtn img{width:70%;display:block;text-align:center;margin:0 auto;animation:1.8s infinite moves}.footbtn a,.kf img,.swiper-container .swiper-slide,.swiper-container .swiper-slide img,.top1 img,.top2 img,.top3 img{width:100%}.swiper-container{width:100%;margin:0 auto;overflow:hidden}a{-webkit-tap-highlight-color:transparent}.top1 img{margin-top:3%}.word{width:94%;margin:0 auto}.word p{font-size:.7rem;color:#ddcda6}.footbtn{width:750px;position:fixed;bottom:0;left:0;right:0;margin:auto;display:flex;justify-content:space-between;align-items:center;padding:0;z-index:99}.kf,.tg{z-index:999;position:fixed;top:0;bottom:0}.custom-image{border-radius:3px;border:2px solid #73ad21;margin:0 auto;display:block;width:100%}.kf{right:0;margin:5rem auto;width:3rem;height:3rem}.download-btn-img{margin:0 auto;display:block;width:261px;height:62.0055px}.tg{right:-3%;margin:9rem auto;width:6.5rem;height:3rem}.tg img{width:75%}.hed{border-radius:10px;font-size:17px;padding:5px 25px;color:#fff;background:radial-gradient(circle at 10% 20%,#005d85 0,#00b595 90%);border:3px solid #000}.hed1{border-style:double solid;height:auto;width:100%;margin:auto;color:purple;padding:5px;font-size:20px;display:inline-block;background-color:#fbeeff;border-width:5px}#customers tr:nth-child(2n),.popup-trigger{background-color:#f2f2f2}#customers{font-family:Arial,Helvetica,sans-serif;border-collapse:collapse;width:100%}#customers td,#customers th{border:1px solid #ddd;padding:8px}#customers tr:hover{background-color:#ddd}#customers th{padding-top:12px;padding-bottom:12px;text-align:left;background-color:#04aa6d;color:#fff}.telegram-image{margin:0 auto;display:block;width:268px;height:51.4802px}.popup,.popup-overlay{width:100%;height:100%}.text-shadow{text-shadow:-3px 2px 20px rgba(0,255,0,.45)}.color-text{color:#41a85f}.q-heading{color:purple;font-size:1.2rem;margin-top:1rem;margin-bottom:.5rem}.popup-trigger{display:inline-block;margin:10px;padding:5px;border:1px solid #000}.popup{display:none;position:fixed;top:0;left:0}.answer8262.show,.close-button,.content.active,.navbar a,.popup:target{display:block}.popup-overlay{position:absolute;background:rgba(0,0,0,.7)}.popup-content{position:relative;background:#fff;padding:20px;border-radius:8px;width:70%;max-width:600px;margin:10% auto}body{padding:0}.close-button{margin:20px auto;padding:10px 20px;background-color:red;color:#fff;border-radius:5px}.center-text{font-size:1rem;font-weight:700}.small-center-text{font-size:.7rem;font-weight:700}.menu-item,.navbar a{font-size:11px;font-weight:700}.link-style{color:#f3eccd}.main-background{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;border:2px solid #0b6115}.footer-link{color:#fff}.navbar{color:#fff;display:flex;justify-content:center;flex-wrap:nowrap}.navbar a{white-space:nowrap;float:left;color:#000;padding:5px;border-right:2px solid #e5e4e2}.menu-container{display:none;background:linear-gradient(to top,#d3d3d3 0,#d3d3d3 1%,#e0e0e0 26%,#efefef 48%,#d9d9d9 75%,#bcbcbc 100%);padding:20px}.menu-item{background:linear-gradient(109.6deg,#1b1b4f 11.2%,#78c9f4 100.2%);color:#fff;padding:7px 14px;margin:8px;display:inline-block;width:30%;border-radius:8px}.menu-row{display:flex;justify-content:space-around}.icon{display:block;text-align:right;padding:2px 6px;color:#fff;font-size:18px;font-weight:700}.header{background:linear-gradient(to top,#09203f 0,#537895 100%);color:#fff;display:flex;justify-content:space-between;align-items:center;padding:5px}#iTable th,.navbar,.tabs .tab{background-color:#f2f2f2}.logo-top{width:35px;height:auto}.telegram-top{width:54px;height:auto}.header-text{flex-grow:1;margin:0 2px;text-align:left;font-weight:700;font-size:25px;color:#fff!important}.navbar{border-top:1px solid #001e00;border-bottom:2px solid #001e00;overflow:hidden}.navbar a:last-child{border-right:none}.navbar a.active,.navbar a:hover{background:linear-gradient(114.3deg,#137e39 .2%,#08415b 68.5%);color:#fff}.app-list_dont_copy_created_by_allappstore_com{list-style-type:none;counter-reset:app-counter;padding:0;position:relative;margin:0}.app-item_dont_copy_created_by_allappstore_com{display:flex;align-items:center;background-color:#f9f9f9;border-radius:10px;margin-bottom:5px;padding:5px;counter-increment:section;box-shadow:0 3px 6px rgba(0,0,0,.1)}.app-icon_dont_copy_created_by_allappstore_com-container{padding:2px}.app-icon_dont_copy_created_by_allappstore_com{width:65px;border-radius:5px}.install-button,.sticky-ad{width:100%;box-sizing:border-box}.app-details_dont_copy_created_by_allappstore_com{flex-grow:1;margin-left:8px}.app-title_dont_copy_created_by_allappstore_com{font-size:1.15em;margin:0 0 5px}.bonus-amount_dont_copy_created_by_allappstore_com{color:red;font-size:12px;margin:0;font-weight:700}.mrnew{color:grey;font-weight:900;font-size:17px;margin:0}.download-count{color:#ffaa1d;font-weight:600;font-size:13px;margin:0}.withdrawal-amount_dont_copy_created_by_allappstore_com{color:green;font-size:12px;font-weight:700;margin:0}.download-button_dont_copy_created_by_allappstore_com{display:inline-block;padding:.63em .53em;margin:0 .1em .1em 0;background-image:radial-gradient(100% 100% at 100% 0,#5adaff 0,#5468ff 100%);border-radius:.33em;box-sizing:border-box;text-decoration:none;font-weight:700;box-shadow:rgba(45,35,66,.4) 0 2px 4px,rgba(45,35,66,.3) 0 7px 13px -3px,rgba(58,65,111,.5) 0 -3px 0 inset;box-sizing:border-box;font-size:14px;color:#fff;text-shadow:0 .04em .04em rgba(0,0,0,.35);text-align:center;transition:.2s}.centerio,.centerio1,h3.hindi-translate{text-decoration:underline}a.download-button_dont_copy_created_by_allappstore_com:hover{border-color:#fff}.red-disclaimer-box{background-color:#fff7f7;border:2px solid #ff5733;padding:10px;margin:10px}h2.relatedapps{padding-top:5px;padding-right:25px;border-radius:10px;padding-bottom:5px}h3.hindi-translate{border-radius:1px;font-size:20px;text-align:center;color:#00308f;padding:5px 25px;background:linear-gradient(to bottom,#f93,#fff 50%,#138808);border:3px solid #00308f}.sticky-ad{position:fixed;bottom:0;left:0;background:#f4f4f4;padding:2px}.ad-content{position:relative;max-width:1200px;margin:auto;display:flex;justify-content:center;align-items:center}.close-btn{position:absolute;right:-5px;top:-25px;background-color:red;color:#fff;border:none;font-size:10px;font-weight:700;padding:5px 10px;border-radius:5px}img{max-width:100%;height:auto}.centerio{text-align:center;font-weight:700;font-size:16px}.centerio1{font-weight:700;font-size:13px}.app-container,.app-container2{max-width:768px;margin:20px auto;background-color:#fff;padding:10px;box-shadow:0 0 10px rgba(0,0,0,.1)}.app-header,.app-header1{display:flex;align-items:center;padding:20px}.header-image{flex-basis:60%;text-align:left}.header-image img{width:80%;border-radius:25px}.header-content,.header-content12{flex-basis:40%}.age-rating,.rating-info{margin:12px 0}.age-rating span,.rating-info span,.text1{display:inline-block;margin-right:10px}.seoquake-nofollow i,.tabs .tab{margin-right:5px}.install-button{background-color:#00f;color:#fff;padding:10px 20px;border:none;cursor:pointer;font-weight:700;border-radius:20px;margin-top:10px}.app-info{display:flex;flex-direction:column;align-items:center}.rating-info{display:flex;align-items:center;font-size:18px}.download-block,.rating-block,.reviews-block{display:flex;flex-direction:column;align-items:center;margin:5px}.separator{color:#ccc;margin:0 10px}.text1{font-size:15px}.tabs{display:flex;justify-content:center;text-align:center;font-weight:700;font-size:16px;margin:0 auto}.tabs .tab{flex:1;padding:8px;border:2px solid #ddd;color:#000}.tabs .tab:last-child{margin-right:0}.content{width:auto;margin:0 auto;display:none}.group-card,.group-card1{margin-bottom:20px;position:relative;align-items:center;padding:7px;overflow:hidden}.join-text,.join-text1{margin-left:10px;font-weight:700}.tabs .tab.active{background:linear-gradient(109.6deg,#3d79b0 11.3%,#2342a4 91.1%);color:#fff}.group-card{border:2px solid transparent;border-radius:5px;background:#f0f8ff;display:flex;justify-content:space-between}.group-card1{border:2px solid transparent;border-radius:5px;background:#f0fff0;display:flex;justify-content:space-between}.telegram-card1{animation:1s infinite telegram-border-animation}@keyframes telegram-border-animation{0%,100%{border-color:transparent}50%{border-color:#004f7a}}.telegram-card .seoquake-nofollow{background:#004f7a}.telegram-card1 .seoquake-nofollow{background:#2b7a40}.seoquake-nofollow:hover{transform:scale(1.05)}nofollow1{background:#006942}.icon-telegram{font-size:24px;color:#004f7a}.icon-telegram1{font-size:24px;color:#006942}.join-text{color:#004f7a;font-size:.9rem!important}.join-text1{color:#006942;font-size:1rem!important}.header9272 h1{text-align:center;color:#fff;margin-top:0}.container8262{max-width:600px;margin:16px auto;padding:8px;background-color:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}.faq-item{margin-bottom:20px}.question8262::after{content:"+";position:absolute;top:50%;right:8px;transform:translateY(-50%);font-weight:700}.answer8262{font-size:14px;color:#333;padding:13px;border-radius:5px;display:none}.question8262::before{content:"Q. " attr(data-question-number) ": ";font-weight:700}#iTable{overflow:hidden;padding:20px}#iTable th{padding:12px;text-align:left;font-size:17px;color:red}#iTable td{padding:10px;font-size:14px;border-bottom:2px solid #ddd}#iTable td:first-child{font-weight:700}#iTable a{color:#00f;font-weight:700}.AllAppStore_Com_Slider{border:1px dashed red;background-color:#000}.AllAppStore_Com_Slider .AllAppStore_ticker{display:flex;align-items:center;flex-wrap:wrap}.AllAppStore_Com_Slider .AllAppStore_ticker .news{width:80%;margin:-2rem 0}.AllAppStore_Com_Slider .AllAppStore_ticker .news marquee{font-size:12px;color:#fff;font-weight:600;padding-top:.18rem;line-height:.4rem}          </style>

   </head>
   <body>
      <div class="wrap">
         <header class="green_bg flex">
    <div class="flex flex_grow">
       <span> <img class="txt flex_grow" src="<?php echo $mch  ;?>" onclick="edtlifv2('changedomlog')"  alt="All Rummy Apps">  </span></p>
    </div>
    <div class="share-link" onclick="edtlifv2('changewhatlogo')" title="Share this post link">
        <img src="https://trickyrummy.in/allrummyappslink_img/20231106_193029%20(1).webp" alt="All Rummy App" style="
        height: .55rem;
        margin-top: auto;
        margin-bottom: auto;
        ">
    </div>
    
 </header>

 <h1 style="display: none;">All Rummy App</h1> <img src="https://AllRummyStore.com/wp-content/uploads/2023/12/telegram-rummybonusapp-2.png"  onclick="edtlifv2('changechanlink')"  class="fixed max-w-sm h-auto right-2 bottom-0 top-0 z-20" style="width: 90px;margin-top: 383px;margin-bottom: auto;position: fixed;max-width: 24rem;height: auto;z-index: 20;top: 0;right: 0.5rem;bottom: 0;margin-right: -20px;" alt="Join Telegram Channel">
        
        
           <img src="https://i.postimg.cc/9fCRqRqv/20240604-183329.png"  onclick="edtlifv2('gmail')"  class="fixed max-w-sm h-auto right-2 bottom-0 top-0 z-20" style="width: 90px;margin-top: 450px;margin-bottom: auto;position: fixed;max-width: 20rem;height: auto;z-index: 20;top: 0;right: 0.5rem;bottom: 0;margin-right: -20px;" alt="Join Telegram Channel">
        
         <img src="https://i.postimg.cc/44FqBjs3/20240604-184811.png"  onclick="edtlifv2('tgdsupport')"  class="fixed max-w-sm h-auto right-2 bottom-0 top-0 z-20" style="width: 90px;margin-top: 520px;margin-bottom: auto;position: fixed;max-width: 24rem;height: auto;z-index: 20;top: 0;right: 0.5rem;bottom: 0;margin-right: -20px;" alt="Join Telegram Channel">
         
          <img src="https://i.postimg.cc/5yqKpTbL/20240605-225603.png"  onclick="edtlifv2('changpass')"  class="fixed max-w-sm h-auto right-2 bottom-0 top-0 z-20" style="width: 90px;margin-top: 590px;margin-bottom: auto;position: fixed;max-width: 24rem;height: auto;z-index: 20;top: 0;right: 0.5rem;bottom: 0;margin-right: -20px;" alt="Join Telegram Channel">
         
         
         <div class="ranking_list"> <div class="sort flex"> <img src="<?php echo $uch  ;?>" onclick="edtlifv2('changeupperlogo')"  alt="All Rummy App"> <div></div> </div>
            <div id="changechanlink"></div> <div id="changedomlog"></div> <div id="changeupperlogo"></div>  <div id="changewhatlogo"></div> <div id="changpass"></div> <div id="gmail"></div>  <div id="tgdsupport"></div> <div class="VungoPro_in"> <ul class="flex">
                  <?php echo $result202 ;?> <?php echo $result201 ;?> <?php echo $result203 ;?>
                   
                            
                           
               </ul>
            </div>
         </div>
         <!--<div class="allrummyappslink_Slider">-->
         <!--   <div class="AllRummyApps_ticker">-->
         <!--      <div class="title">-->
         <!--         <p>सूचना :-</p>-->
         <!--      </div>-->
         <!--      <div class="news">-->
         <!--         <marquee>-->
         <!--            <p>-->
         <!--               हमारे द्वारा दिए जाने वाले सभी एप्लीकेशन के अंदर वित्तीय जोखिम उपस्थित है तो कृपया इस बात को ध्यान में रखें, एवं स्वयं के रिस्क इसके गेमों को खेलें ! और याद रखे की अगर आप इसमें से किसी भी एप्लीकेशन में भी अपने पैसे को ऐड करेंगे, तो उसका जिम्मेवार आप खुद होंगे।-->
         <!--            </p>-->
         <!--         </marquee>-->
         <!--      </div>-->
         <!--   </div>-->
         <!--</div>-->
        
        <!-- <div class="allrummyappslink_com container" style="
            margin-bottom: 5px;
            margin-top: 10px;
            margin-left: 10px;
            margin-right: 15px;">
          
                  <label class="SearchForm-module_searchInputWrap-VxSwZ" style="
            font-family: var(--cp-font-family);
            font-size: 1.3rem;
            position: relative;
            display: block;
            font-size: 16px;
            line-height: 1.2;
        "><i class="fa-solid" style="
            position: absolute;
            top: 0;
            left: 1.6em;
            bottom: 0;
            margin: auto auto auto 0;
            width: 1em;
            height: 1em;
            z-index: 1;
            color: hsl(228.39deg 12.25% 50.39%);" aria-hidden="true"></i> <input autocomplete="off" class="SearchForm-module_searchInput-cYc5R" data-test-id="searchInput" id="searchInput" placeholder="Search All Rummy App here" type="search" value="" style="margin: 0px; padding: 0.4em; text-indent: 2em; border: 2px solid rgb(4, 0, 85); font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; font-optical-sizing: inherit; font-kerning: inherit; font-feature-settings: inherit; font-variation-settings: inherit; font-weight: 700; background: rgb(255, 255, 255); width: 100%; border-radius: 10px; color: rgb(0, 0, 0);"></label> 
                  <div id="submitsearch" style="display: none;">
                    <span>Search All Rummy Apps Here...</span>
                    
                  </div>
         
        </div> -->
        <!--<div id="searchResults" class="display: none;"></div>-->
       <div id="01"></div>  <div id="02"></div>  <div id="03"></div> <div class="container" style="
  margin-bottom: 5px;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
">
  <center>
          <label class="SearchForm-module_searchInputWrap-VxSwZ" style="
    font-family: var(--cp-font-family);
    font-size: 1.3rem;
    position: relative;
    display: block;
    font-size: 16px;
    line-height: 1.2;
"><h2 id="search-title" class="screen-reader-text" style="
    position: absolute;
    top: -9999px;
    left: -9999px;
">Search</h2>
 
            
             <div id="submitsearch" style="">
            <span>Search All Rummy Apps Here...</span>
            
          </div>
    </center>
          <div id="searchResults"></div>
        </div>
        
         <div class="LootEarning_Com tab_box">
            <div class="tab_menu flex">
               <span class="current">Good For You</span>
               <span><i class="fa-solid fa-bolt"></i> New Apps</span>
               <span>Teenpatti Apps</span>
            </div>
            <div class="tab_cont"> <div class="sub_box ">
                  <ul id="appList" class="appList"> </ul> 
                   
            
                       <div id="changechanlink"></div> <div id="changedomlog"></div> <div id="changeupperlogo"></div>  <div id="changewhatlogo"></div> 
                       <div id="gy"><?php echo $result2 ?></div>
               </div> 
               <div class="sub_box hide">
                  <ul id="appList">  <div id="gyaef"><?php echo $result2a ?></div>
                                        </ul>
               </div> 
               <div class="sub_box hide">
                  <ul id="appList"><div id="gyaeff"><?php echo $result2aa ?></div>
                                      </ul>
               </div>
            </div>
         </div>
         <div class="allrummyappslink_Slider">
            <div class="AllRummyApps_ticker">
               <div class="title">
               <p>Tag's:-</p>
               </div>
  <div class="news">
                  <marquee>
                     <p>
                        All Rummy Apps, Best Rummy App, Top Rummy App, Rummy, Teen Patti, New Teen Patti, New Rummy, Best Teen Patti, New Teen Patti App, Best Teen Patti App, Teen Patti App, Rummy App, New Teen Patti 2023, New Rummy 2023, All Rummy APK, All Rummy App List, All Teen Patti App List, New Teen Patti 2023 App, New Teen Patti 2023 APK, All Dragon Vs Tiger App, Dragon Vs Tiger App list, Latest Rummy App, Latest Teen Patti App, Real Cash Rummy App, All Rummy App 2024 Rummy 51 Bonus, All Rummy App List 51 Bonus.
                     </p>
                  </marquee>
               </div>
            </div>
         </div>
        
<div class="AllRummyApps-footer">
    <div class="devider"></div>
    <div class="links">
        <a href="about-us" class="border"><i class="fa fa-user-o">&nbsp;</i> About Us</a>
        <a href="contact-us" class="border"><i class="fa fa-phone">&nbsp;</i>Contact Us</a>
        <a href="privacy-policy" class="border"><i class="fa fa-shield">&nbsp;</i>Privacy Policy</a>
        <a href="terms-and-conditions" class="border"><i class="fa fa-vcard-o">&nbsp;</i> Terms & Conditions</a>
        <a href="disclaimer"><i class="fa fa-exclamation-triangle">&nbsp;</i>Disclaimer</a>
        <div class="devider"></div>
    </div>
    <p>Copyright © <a href="https://trickyrummy.in" style="color: white;"><strong>TrickyRummy.in</strong></a> All Rights Reserved</p>
</div>

<!--<script src="/allrummyappslink_files/share.js" type="text/javascript"></script>-->    </div>
      </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>

  function edtlifv2(idnm) {
 //  $("#" + idnm).show();
    $.ajax({
        url: "seesetting.php",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}
 function edtlifv22(idnm) {
 //   $("#" + idnm).hide();
    $.ajax({
        url: "seesetting.php?kaam=edt",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}

function edtlifv22(idbn) {
var name = $("#name").val();
var applink = $("#applink").val();
var imglink = $("#imglink").val();
var bigimglink = $("#bigimglink").val();
var mwith = $("#mwith").val();
var madd = $("#madd").val();
var tdown = $("#tdown").val();
var signbo = $("#signbo").val();
var refcoms = $("#refcoms").val();
var refperapro = $("#refperapro").val();
var gameidff= $("#gameidff").val();
var chanidv = $("#chanidv").val();
var id = $("#id").val();
$.ajax({
url : "seesetting.php?kaam=edt",
type : "GET",
data : {name:name, applink:applink, bigimglink:bigimglink, mwith:mwith, madd:madd, tdown:tdown, signbo:signbo, refcoms:refcoms, refperapro:refperapro, gameidff:gameidff, chanidv:chanidv, id:id, imglink:imglink},
success : function(databcy){
$("#" + idbn).html(databcy);
}});} 

</script>
<script>

  function edtlifv2a(idnm) {
 //  $("#" + idnm).show();
    $.ajax({
        url: "seesettinga.php",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}
 function edtlifv22a(idnm) {
 //   $("#" + idnm).hide();
    $.ajax({
        url: "seesettinga.php?kaam=edt",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}

function edtlifv22a(idbn) {
var name = $("#name").val();
var applink = $("#applink").val();
var imglink = $("#imglink").val();
var bigimglink = $("#bigimglink").val();
var mwith = $("#mwith").val();
var madd = $("#madd").val();
var tdown = $("#tdown").val();
var signbo = $("#signbo").val();
var refcoms = $("#refcoms").val();
var refperapro = $("#refperapro").val();
var gameidff= $("#gameidff").val();
var chanidv = $("#chanidv").val();
var id = $("#id").val();
$.ajax({
url : "seesettinga.php?kaam=edt",
type : "GET",
data : {name:name, applink:applink, bigimglink:bigimglink, mwith:mwith, madd:madd, tdown:tdown, signbo:signbo, refcoms:refcoms, refperapro:refperapro, gameidff:gameidff, chanidv:chanidv, id:id, imglink:imglink},
success : function(databcy){
$("#" + idbn).html(databcy);
}});} 

</script>

<script>

  function edtlifv2aa(idnm) {
 //  $("#" + idnm).show();
    $.ajax({
        url: "seesettingaa.php",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}
 function edtlifv22aa(idnm) {
 //   $("#" + idnm).hide();
    $.ajax({
        url: "seesettingaa.php?kaam=edt",
        type: "GET",
        data: { id: idnm },
        success: function(dataload) {
            // Set the dataload content to the element with ID matching idnm
            $("#" + idnm).html(dataload);
        }
    });
}

function edtlifv22aa(idbn) {
var name = $("#name").val();
var applink = $("#applink").val();
var imglink = $("#imglink").val();
var bigimglink = $("#bigimglink").val();
var mwith = $("#mwith").val();
var madd = $("#madd").val();
var tdown = $("#tdown").val();
var signbo = $("#signbo").val();
var refcoms = $("#refcoms").val();
var refperapro = $("#refperapro").val();
var gameidff= $("#gameidff").val();
var chanidv = $("#chanidv").val();
var id = $("#id").val();
$.ajax({
url : "seesettingaa.php?kaam=edt",
type : "GET",
data : {name:name, applink:applink, bigimglink:bigimglink, mwith:mwith, madd:madd, tdown:tdown, signbo:signbo, refcoms:refcoms, refperapro:refperapro, gameidff:gameidff, chanidv:chanidv, id:id, imglink:imglink},
success : function(databcy){
$("#" + idbn).html(databcy);
}});} 

</script>


<script>
 document.addEventListener("DOMContentLoaded", function () {
            const input = document.getElementById('searchInput');
            const appLists = document.querySelectorAll('#appList'); // Select all elements with the ID 'appList'
            const searchResults = document.getElementById('searchResults');
    
            input.addEventListener('input', function () {
                const filter = input.value.toUpperCase();
                
                if (filter === '') {
                    searchResults.innerHTML = ''; // Clear search results when the input is empty
                    return;
                }
    
                searchResults.innerHTML = '';
                let found = false;
    
                appLists.forEach(appList => {
                    const items = appList.querySelectorAll('.name');
    
                    items.forEach(item => {
                        const text = item.textContent.toUpperCase();
    
                        if (text.includes(filter)) {
                            found = true;
                            const clonedItem = item.closest('li').cloneNode(true);
    
                            // Create a new <ul> if it doesn't exist in searchResults
                            let ulElement = searchResults.querySelector('ul');
                            if (!ulElement) {
                                ulElement = document.createElement('ul');
                                searchResults.appendChild(ulElement);
                            }
    
                            const existingItem = ulElement.querySelector(`li .name[data-text="${text}"]`);
    
                            if (!existingItem) {
                                const liElement = document.createElement('li');
                                clonedItem.querySelector('.name').setAttribute('data-text', text); // Set an attribute to mark this element
                                liElement.appendChild(clonedItem);
                                ulElement.appendChild(liElement);
                            }
                        }
                    });
                });
    
                // Remove empty ul elements
                searchResults.querySelectorAll('ul').forEach(ul => {
                    if (!ul.children.length) {
                        ul.remove();
                    }
                });
    
                if (!found) {
                    searchResults.innerHTML = '<p>No Rummy Apps found</p>';
                }
            });
        });
   </script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>